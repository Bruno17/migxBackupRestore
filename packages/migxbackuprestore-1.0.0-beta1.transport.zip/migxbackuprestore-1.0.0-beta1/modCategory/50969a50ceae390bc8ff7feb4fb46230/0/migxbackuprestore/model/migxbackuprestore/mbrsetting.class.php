<?php
class mbrSetting extends xPDOSimpleObject {}
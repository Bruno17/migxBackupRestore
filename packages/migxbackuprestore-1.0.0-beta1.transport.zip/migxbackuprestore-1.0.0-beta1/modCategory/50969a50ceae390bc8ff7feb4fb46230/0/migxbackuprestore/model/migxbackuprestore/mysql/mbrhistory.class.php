<?php
require_once (dirname(dirname(__FILE__)) . '/mbrhistory.class.php');
class mbrHistory_mysql extends mbrHistory {}
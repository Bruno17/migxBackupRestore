<?php
require_once (dirname(dirname(__FILE__)) . '/mbrsetting.class.php');
class mbrSetting_mysql extends mbrSetting {}
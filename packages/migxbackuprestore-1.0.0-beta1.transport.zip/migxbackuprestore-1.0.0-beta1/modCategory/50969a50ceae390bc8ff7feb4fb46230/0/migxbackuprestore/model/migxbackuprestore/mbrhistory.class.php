<?php
class mbrHistory extends xPDOSimpleObject {}
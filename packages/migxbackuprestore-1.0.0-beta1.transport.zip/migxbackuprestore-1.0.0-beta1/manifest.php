<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxbackuprestore-1.0.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'efd9b4c8cefadd797171c0a9c8b67585',
      'native_key' => 'migxbackuprestore',
      'filename' => 'modNamespace/d97c258dfafd2216dbeaf3e868f561ea.vehicle',
      'namespace' => 'migxbackuprestore',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2c98afb6f7a2b090b5b466cbdab47192',
      'native_key' => 1,
      'filename' => 'modCategory/50969a50ceae390bc8ff7feb4fb46230.vehicle',
      'namespace' => 'migxbackuprestore',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f0f7b6c47c4ab1eb0ebe8b4ff01fde47',
      'native_key' => 'Site Backup',
      'filename' => 'modMenu/866d6302878014e501f8d5bf7c2c8a72.vehicle',
      'namespace' => 'migxbackuprestore',
    ),
  ),
);
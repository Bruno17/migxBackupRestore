<?php
// http://www.phpclasses.org/browse/file/33388.html

$path = $modx->getOption('core_path') . 'components/migxbackuprestore/';
// version 5.3+
require_once $path . 'model/mysql/dbbackup.class.php';
// require_once $path.'model/mysql/dbbackup5.2.class.php';

$output = '';
// back up my modx database:
$data_folder = $modx->getOption('dataFolder', $scriptProperties, $modx->getOption('databackup.folder', null, $path . 'dumps' . DIRECTORY_SEPARATOR));

// added 1.7
$temp_folder = $modx->getOption('tempFolder', $scriptProperties, $modx->getOption('databackup.temp', null, $data_folder . 'temp' . DIRECTORY_SEPARATOR));

$purge = $modx->getOption('purge', $scriptProperties, $modx->getOption('databackup.purge', null, 1814400));
// includeTables should be a comma separtaed list
$includeTables = $modx->getOption('includeTables', $scriptProperties, null);
// excludeTables should be a comma separtaed list
$excludeTables = $modx->getOption('excludeTables', $scriptProperties, null);

$write_file = $modx->getOption('writeFile', $scriptProperties, true);
if ($write_file === 'false') {
    $write_file = false;
    $output .= ' <br>Do not write main file<br>';
}
$write_table_files = $modx->getOption('writeTableFiles', $scriptProperties, true);
if ($write_table_files === 'false') {
    $write_table_files = false;
    $output .= ' <br>Do not write table files<br>';
}
// these are to change how the data file is written
$comment_prefix = $modx->getOption('commentPrefix', $scriptProperties, '-- ');
$comment_suffix = $modx->getOption('commentSuffix', $scriptProperties, '');
$new_line = $modx->getOption('newLine', $scriptProperties, "\n");
// use the sql drop command
$use_drop = $modx->getOption('useDrop', $scriptProperties, true);
if ($use_drop === 'false') {
    $use_drop = false;
}
$database = $modx->getOption('database', $scriptProperties, $modx->getOption('dbname'));
// use the sql create database command
$create_database = $modx->getOption('createDatabase', $scriptProperties, false);
if ($create_database === 'false') {
    $create_database = false;
}

$return = $modx->getOption('return', $scriptProperties, '');
$outputSeparator = $modx->getOption('outputSeparator', $scriptProperties, '||');
$custom_autoinc = $modx->getOption('custom_autoinc', $scriptProperties, 0);
$filename = $modx->getOption('filename', $scriptProperties, 'complete_db_backup.sql');

$db = new DBBackup($modx, array(
    'comment_prefix' => $comment_prefix,
    'comment_suffix' => $comment_suffix,
    'new_line' => $new_line,
    'base_path' => $data_folder,
    'temp_path' => $temp_folder,
    'write_file' => $write_file,
    'write_table_files' => $write_table_files,
    'use_drop' => $use_drop,
    'database' => $database,
    'create_database' => $create_database,
    'includeTables' => $includeTables,
    'excludeTables' => $excludeTables,
    'custom_autoinc' => $custom_autoinc,
    'filename' => $filename,
    ));

switch ($return) {
    case 'tables':
        $output = '';
        $tables = $db->getTables();
        if (is_array($tables)) {
            $output = implode($outputSeparator, $tables);
        }
        break;
    default:
        $backup = $db->backup();
        if ($backup) {
            if ($return == 'folder' && $folder = $db->folderPath() ){
                $output = $folder;
            }else{
                $output .= 'The MODX data has been backed up';  
            }
            
        } else {
            $output .= 'An error has ocurred and MODX did not get backed up correctly: ' . $db->getErrors();
        }
        if ($purge > 0) {
            $db->purge($purge);
        }
        break;
}


return $output;

// restore: http://efreedom.com/Question/1-898440/PDO-SQL-Server-RESTORE-DATABASE-Query-Wait-Finished
// $pdo->exec('RESTORE DATABASE [blah] FROM DISK = \'c:\blah.bak\' WITH NOUNLOAD');
<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxbackuprestore-1.0.0-beta4/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '25818714cdf36ce2a91a18f9fcc517f7',
      'native_key' => 'migxbackuprestore',
      'filename' => 'modNamespace/eccc3694e282e9df934044f642d30538.vehicle',
      'namespace' => 'migxbackuprestore',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '45c53ef8cd5db0fed91631a77667f304',
      'native_key' => 1,
      'filename' => 'modCategory/d37cde6e9f4a49152953f6ab5290b4cd.vehicle',
      'namespace' => 'migxbackuprestore',
    ),
  ),
);
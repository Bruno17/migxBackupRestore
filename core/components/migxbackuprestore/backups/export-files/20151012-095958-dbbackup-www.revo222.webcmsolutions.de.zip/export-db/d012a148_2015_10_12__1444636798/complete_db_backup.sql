-- RESTORING TABLES d012a148 
-- CREATING TABLE modx_site_htmlsnippets
DROP TABLE IF EXISTS `modx_site_htmlsnippets`;

CREATE TABLE `modx_site_htmlsnippets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` int(10) unsigned NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `category` (`category`),
  KEY `locked` (`locked`),
  KEY `static` (`static`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- INSERTING DATA INTO modx_site_htmlsnippets
INSERT INTO `modx_site_htmlsnippets` VALUES ( '1', '0', '0', 'chunkABtest', '', '0', '0', '0', 'chunkA', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '2', '0', '0', 'chunkB x', '', '0', '0', '0', 'chunk B', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '3', '0', '0', 'chunkC', '', '0', '0', '0', 'chunk C', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '4', '0', '0', 'debug', '', '0', '0', '0', '', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '212', '0', '0', 'npFieldErrorTpl', 'Tpl chunk used to display field-specific errors above each NewsPublisher field', '0', '85', '0', '    <span class = \"fielderrormessage\">[[+np.error]]</span>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '213', '0', '0', 'npTabsJsTpl', 'Tpl chunk with JavaScript for NewsPublisher Tabs', '0', '85', '0', '<script type=\"text/javascript\">
$(document).ready(function(){

    /* Original code by Gregor Šekoranja */

    var activeButton = \'[[+activeButton]]\'.toLowerCase();

    /* JSON is validated in snippet */
    var buttonsJsonStr = JSON.stringify([[+buttonsJson]]);
    var buttonsJson = (buttonsJsonStr) ? $.parseJSON(buttonsJsonStr) : null;



  /* CONTINUE if JSON IS not null and IS object */
  if ( (buttonsJson != null) && (typeof buttonsJson == \'object\') ){


    /* html for filter buttons */
    var htmlButtons = \'\';


    /* *************
     CLASSES AND IDS
    ************** */

    /* id for container of filter buttons */
    var filterId = \'filters\';

    /* buttons classes */
    var buttonPrefixClass = \'btn-\';
    var filterSelected = \'filterSelected\';

    /* items classes
       items (having this class) to be shown or hide on filter button click */
    var filterItemClass = \'filter-item\';
    var npHiddenClass = \'np-hidden\'; /* hidden class */


    /* *************
     JQ SELECTORS
    ************** */
    /* ignore NewsPublisher\'s own form inputs */
    var excludeItems = $(\'.buttons, [name=\"np_existing\"], [name=\"np_doc_id\"], #hidSubmit\');
    /* the main container - the NewsPublisher form */
    var form = $(\'form#newspublisherForm\');
     /* element after which buttons will be inserted */
    var insertAfterElement = $(\'h2#newspublisherHeader\').eq(0);


    /* *************
     the code
    ************** */

    /* by default no filter button is selected */
    var jsonFieldsCount = 0; /* used to determine if \"Other\" option is shown */
    var hasFilterSelected = false;

    $.each(buttonsJson, function(buttonName, aFields) {
       var buttonClass = buttonPrefixClass + buttonName; /* criterion for filtering items */
       var aClass = \'\';
       if (activeButton==buttonName.toLowerCase()){ /* if button label matches to activeButton property */
         aClass = filterSelected;
         hasFilterSelected = true;
       }
       htmlButtons += \'<li id=\"np-buttons\"><a class=\"\' +  aClass  + \'\" data-filter=\".\' + buttonClass + \'\" href=\"#\">\' + buttonName + \'</a></li>\';
       $.each(aFields, function(index, fieldName) {
        /* find that element by name (name can be fieldName or fieldName[]) */
        var field = $(\'[name^=\"\' + fieldName + \'\"]:last\');
        if (field.length > 0){
          /* OK, got it */
          var parent = field;
          while ( parent.parent().get(0).nodeName.toLowerCase() != \'form\') {
            parent = parent.parent();

          }
          jsonFieldsCount++;
          parent.addClass(filterItemClass);
          parent.addClass(buttonClass);
          /* console.log(\'class added to: \' + parent.attr(\'id\')); */
        } else {
          /* warn user */
          alert(\'[[%np_could_not_find_tab_field]]\' + fieldName);
        }

       });
    });

    htmlButtons =   \'<section id=\"np-tabs\" class=\"clearfix\">\' +
                       \'<ul id=\"\' + filterId + \'\">\' +
                          htmlButtons +
                    \'<li id=\"other-filter\"><a data-filter=\"!*\" href=\"#\">[[%np_tabs_other]]</a></li>\' +
                    \'<li class=\"data-filter\"><a data-filter=\"*\" href=\"#\" class=\"\' + (hasFilterSelected ? \'\' : filterSelected) + \'\">[[%np_tabs_show_all]]</a></li>\' +
                        \'</ul>\' +
                    \'</section>\';

    /* ****************************
    /* insert filter buttons
    /******************************/

    /* insert filter buttons after insertAfterElement element */
    $(htmlButtons).insertAfter(insertAfterElement);

    /* ****************************
    /* apply filter
    /******************************/

    var filterItems = form.find(\'.\' + filterItemClass);
    /* console.log(\'filter-items length: \' + filterItems.length);
    console.log(filterItems); */

    /* all form children (tabs property might not have all from elements included) */
    var formChildren = form.children().not(excludeItems);

    var filters_a = $(\'#\' + filterId + \' a\');
    filters_a.click(function(){
      var selector = $(this).data(\'filter\');
      console.log(selector);

      if (selector == \'*\') { /* Show All */
          formChildren.removeClass(\'np-hidden\');
      }
      else if (selector == \'!*\') { /* uncategorized/other tab */
        formChildren.addClass(npHiddenClass);
        formChildren.not(\'.\' + filterItemClass).removeClass(npHiddenClass);
      }
      else { /* custom button /class */
        formChildren.addClass(npHiddenClass);
        formChildren.filter(selector).removeClass(npHiddenClass);
      }

      $(\'#\' + filterId + \' a.\' + filterSelected).removeClass(filterSelected);
      $(this).addClass(filterSelected);
      return false;
    });
    /* hide \"Other\" btn if no need to show it */
    /* alert (\'Children: \' + formChildren.length + \' --- FieldsCount: \'  + jsonFieldsCount); */
     if (formChildren.length == jsonFieldsCount){
        $(\'#other-filter\').addClass(\'np-hidden\');
}
    /* trigger click on active button */
    if (hasFilterSelected){
      filters_a.filter(\'.\' + filterSelected).eq(0).trigger(\'click\');
    }

  } else {
      alert(\'[[%np_invalid_tabs]]\');
  }


});
</script>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '214', '0', '0', 'npErrorTpl', 'Tpl chunk for use in displaying errors listed at the top of the NewsPublisher form.', '0', '85', '0', '<span class = \"errormessage\">[[+np.error]]</span>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '215', '0', '0', 'npTabsJsMinTpl', 'Tpl chunk with Minimized JavaScript for NewsPublisher Tabs', '0', '85', '0', '<script type=\"text/javascript\">$(document).ready(function(){var activeButton=\'[[+activeButton]]\'.toLowerCase();var buttonsJsonStr=JSON.stringify([[+buttonsJson]]);var buttonsJson=(buttonsJsonStr)?$.parseJSON(buttonsJsonStr):null;if((buttonsJson!=null)&&(typeof buttonsJson==\'object\')){var htmlButtons=\'\';var filterId=\'filters\';var buttonPrefixClass=\'btn-\';var filterSelected=\'filterSelected\';var filterItemClass=\'filter-item\';var npHiddenClass=\'np-hidden\';var excludeItems=$(\'.buttons, [name=\"np_existing\"], [name=\"np_doc_id\"], #hidSubmit\');var form=$(\'form#newspublisherForm\');var insertAfterElement=$(\'h2#newspublisherHeader\').eq(0);var jsonFieldsCount=0;var hasFilterSelected=false;$.each(buttonsJson,function(buttonName,aFields){var buttonClass=buttonPrefixClass+buttonName;var aClass=\'\';if(activeButton==buttonName.toLowerCase()){aClass=filterSelected;hasFilterSelected=true}htmlButtons+=\'<li id=\"np-buttons\"><a class=\"\'+aClass+\'\" data-filter=\".\'+buttonClass+\'\" href=\"#\">\'+buttonName+\'</a></li>\';$.each(aFields,function(index,fieldName){var field=$(\'[name^=\"\'+fieldName+\'\"]:last\');if(field.length>0){var parent=field;while(parent.parent().get(0).nodeName.toLowerCase()!=\'form\'){parent=parent.parent()}jsonFieldsCount++;parent.addClass(filterItemClass);parent.addClass(buttonClass)}else{alert(\'[[%np_could_not_find_tab_field]]\'+fieldName)}})});htmlButtons=\'<section id=\"np-tabs\" class=\"clearfix\">\'+\'<ul id=\"\'+filterId+\'\">\'+htmlButtons+\'<li id=\"other-filter\"><a data-filter=\"!*\" href=\"#\">[[%np_tabs_other]]</a></li>\'+\'<li class=\"data-filter\"><a data-filter=\"*\" href=\"#\" class=\"\'+(hasFilterSelected?\'\':filterSelected)+\'\">[[%np_tabs_show_all]]</a></li>\'+\'</ul>\'+\'</section>\';$(htmlButtons).insertAfter(insertAfterElement);var filterItems=form.find(\'.\'+filterItemClass);var formChildren=form.children().not(excludeItems);var filters_a=$(\'#\'+filterId+\' a\');filters_a.click(function(){var selector=$(this).data(\'filter\');console.log(selector);if(selector==\'*\'){formChildren.removeClass(\'np-hidden\')}else if(selector==\'!*\'){formChildren.addClass(npHiddenClass);formChildren.not(\'.\'+filterItemClass).removeClass(npHiddenClass)}else{formChildren.addClass(npHiddenClass);formChildren.filter(selector).removeClass(npHiddenClass)}$(\'#\'+filterId+\' a.\'+filterSelected).removeClass(filterSelected);$(this).addClass(filterSelected);return false});if(formChildren.length==jsonFieldsCount){$(\'#other-filter\').addClass(\'np-hidden\')}if(hasFilterSelected){filters_a.filter(\'.\'+filterSelected).eq(0).trigger(\'click\')}}else{alert(\'[[%np_invalid_tabs]]\')}});</script>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '216', '0', '0', 'npImageTpl', 'Tpl chunk for NewsPublisher image TVs', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-image\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel\" for=\"np-[[+npx.fieldName]]\" title=\"[[+npx.help]]\">[[+npx.caption]]: </label>
        <input name=\"[[+npx.fieldName]]\" class=\"image\" id=\"np-[[+npx.fieldName]]\" onchange=\"[[+npx.fieldName]]_preview(this.value)\" type=\"text\"  value=\"[[+np.[[+npx.fieldName]]]]\" />
        <button type=\"button\" onclick=\"var popup=window.open(\'[[+npx.browserUrl]]\', \'Select image...\', \'width=\' + Math.min(screen.availWidth,1000) + \',height=\' + Math.min(screen.availHeight*0.9,700) + \'status=no,location=no,toolbar=no,menubar=no\');popup.focus();browserPathInput=getElementById(\'np-[[+npx.fieldName]]\');\">[[%np_launch_image_browser]]</button>
        <div id=\"[[+npx.fieldName]]_preview_container\"></div>
        
        <script type=\"text/javascript\">
            function [[+npx.fieldName]]_preview(rel_image_url) {
                var img = document.getElementById(\'[[+npx.fieldName]]_thumb\');
                if (rel_image_url != \'\') {
                    if (!img) {
                      img = document.createElement(\'img\');
                      img.id=\'[[+npx.fieldName]]_thumb\';
                      document.getElementById(\'[[+npx.fieldName]]_preview_container\').appendChild(img);
                    }
                    // generate the thumbail
                    img.src=\'[[+npx.phpthumbBaseUrl]]&src=\' + rel_image_url + \'&w=120&h=120\';
                } else if (img) {
                    document.getElementById(\'[[+npx.fieldName]]_preview_container\').removeChild(img);
                }
            }
            
            // ensure image is shown on page loading
            [[+npx.fieldName]]_preview(document.getElementById(\'np-[[+npx.fieldName]]\').value);
              
          </script>
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '217', '0', '0', 'npFileTpl', 'Tpl chunk for NewsPublisher file TVs', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-file\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel\" for=\"np-[[+npx.fieldName]]\" title=\"[[+npx.help]]\">[[+npx.caption]]: </label>
        <input name=\"[[+npx.fieldName]]\" class=\"file\" id=\"np-[[+npx.fieldName]]\" type=\"text\"  value=\"[[+np.[[+npx.fieldName]]]]\" />
        <button type=\"button\" onclick=\"var popup=window.open(\'[[+npx.browserUrl]]\', \'Select file...\', \'width=\' + Math.min(screen.availWidth,1000) + \',height=\' + Math.min(screen.availHeight*0.9,700) + \'status=no,location=no,toolbar=no,menubar=no\');popup.focus();browserPathInput=getElementById(\'np-[[+npx.fieldName]]\');\">[[%np_launch_file_browser]]</button>
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '218', '0', '0', 'npIntTpl', 'Tpl chunk for NewsPublisher integer fields', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-integer\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel intfield\" for=\"np-[[+npx.fieldName]]\" title=\"[[+npx.help]]\">[[+npx.caption]]: </label>
        <input name=\"[[+npx.fieldName]]\" [[+npx.readonly]] class=\"int\" id=\"np-[[+npx.fieldName]]\" type=\"text\"  value=\"[[+np.[[+npx.fieldName]]]]\" maxlength=\"[[+npx.maxlength]]\" />
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '219', '0', '0', 'npListOuterTpl', 'Outer Tpl chunk for NewsPublisher listbox TVs', '0', '85', '0', '    [[+np.error_[[+npx.fieldName]]]]
    <fieldset  id=\"np-[[+npx.fieldName]]-container\" class=\"[[+npx.class]]\" title=\"[[+npx.help]]\"><legend>[[+npx.caption]]</legend>
      <select name=\"[[+npx.name]]\" size=\"[[+npx.size]]\" [[+npx.multiple]]>
        [[+npx.options]]
      </select>
    </fieldset>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '220', '0', '0', 'npListOptionTpl', 'Inner Tpl chunk for NewsPublisher listbox TVs (used for each option)', '0', '85', '0', '            <option class=\"listoption\" value=\"[[+npx.value]]\" [[+npx.selected]]>[[+npx.text]]</option>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '221', '0', '0', 'npTextAreaTpl', 'Tpl chunk for NewsPublisher textarea and richtext fields and TVs', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-textarea\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel\" for=\"np-[[+npx.fieldName]]\" title=\"[[+npx.help]]\">[[+npx.caption]]:</label>
        <textarea rows=\"[[+npx.rows]]\" cols=\"[[+npx.cols]]\" class=\"[[+npx.class]]\" name=\"[[+npx.fieldName]]\" id=\"np-[[+npx.fieldName]]\">[[+np.[[+npx.fieldName]]]]</textarea>
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '222', '0', '0', 'npTextTpl', 'Tpl chunk for NewsPublisher one-line text fields and TVs; also used as a default tpl for unhandled TV types', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-text\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel\" for=\"np-[[+npx.fieldName]]\" [[+npx.readonly]] title=\"[[+npx.help]]\">[[+npx.caption]]: </label>
        <input name=\"[[+npx.fieldName]]\" class=\"text\" id=\"np-[[+npx.fieldName]]\" type=\"text\"  value=\"[[+np.[[+npx.fieldName]]]]\" maxlength=\"[[+npx.maxlength]]\" />
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '223', '0', '0', 'npBoolTpl', 'Tpl chunk for NewsPublisher boolean (Yes/No) fields', '0', '85', '0', '
    <fieldset id=\"np-[[+npx.fieldName]]-container\" class=\"np-checkbox\" title=\"[[+npx.help]]\"><legend>[[+npx.caption]]</legend>
        <input type=\"hidden\" name=\"[[+npx.fieldName]]\" value = \"\" />
        <span class=\"option\"><input class=\"checkbox\" type=\"checkbox\" name=\"[[+npx.fieldName]]\" id=\"np-[[+npx.fieldName]]\" value=\"1\" [[+npx.checked]]/></span>
    </fieldset>
', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '224', '0', '0', 'npDateTpl', 'Tpl chunk for NewsPublisher date fields and date TVs', '0', '85', '0', '    <div id=\"np-[[+npx.fieldName]]-container\" class=\"np-date\">
        [[+np.error_[[+npx.fieldName]]]]
        <label class=\"fieldlabel\" for=\"[[+npx.fieldName]]\" title=\"[[+npx.help]]\">[[+npx.caption]]:</label>
        <div class = \"np-date-hints\"><span class = \"np-date-hint\"> [[%np_date_hint]]</span><span class =\"np-time-hint\">[[%np_time_hint]]</span></div>
        <input type=\"text\" id=\"[[+npx.fieldName]]\" name=\"[[+npx.fieldName]]\" maxlength=\"10\" value=\"[[+np.[[+npx.fieldName]]]]\" onblur=\"check_[[+npx.fieldName]]()\" />
        <input type=\"text\" class=\"[[+npx.fieldName]]_time\" name=\"[[+npx.fieldName]]_time\" id=\"[[+npx.fieldName]]_time\" maxlength=\"10\" value=\"[[+np.[[+npx.fieldName]]_time]]\" />
        <div class=\"invalid_date\" id=\"[[+npx.fieldName]]_date_error\" style=\"visibility:hidden\">[[%np_invalid_date]]</div>
      
        <script type=\"text/javascript\">
          function check_[[+npx.fieldName]]() {
            if (datePickerController.getSelectedDate(\'[[+npx.fieldName]]\')) {
              document.getElementById(\'[[+npx.fieldName]]\').style.color=\'inherit\';
              document.getElementById(\'[[+npx.fieldName]]_date_error\').style.visibility=\'hidden\';
            } else {
              var input = document.getElementById(\'[[+npx.fieldName]]\');
              if (input.value != \'\') {
                input.style.color=\'red\';
                document.getElementById(\'[[+npx.fieldName]]_date_error\').style.visibility=\'visible\';
              }
            }
          }
          datePickerController.createDatePicker({
            formElements:{\"[[+npx.fieldName]]\":\"[[%np_date_format]]\"},
            callbackFunctions:{\"dateset\":[ check_[[+npx.fieldName]] ]},
            noFadeEffect:true,
          [[+npx.disabledDates]]
          });
        </script>
    </div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '225', '0', '0', 'npOptionTpl', 'Inner Tpl chunk for NewsPublisher checkbox and radio TVs (used for each option)', '0', '85', '0', '        <span class=\"option\">
            <input id=\"[[+npx.fieldName]]_[[+npx.idx]]\" class=\"[[+npx.class]]\" type=\"[[+npx.type]]\" name=\"[[+npx.name]]\" value=\"[[+npx.value]]\" [[+npx.selected]][[+npx.multiple]]/><label for=\"[[+npx.fieldName]]_[[+npx.idx]]\" class=\"optionlabel\">[[+npx.text]]</label>
        </span>

', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '226', '0', '0', 'npOptionOuterTpl', 'Outer Tpl chunk for NewsPublisher checkbox and radio TVs', '0', '85', '0', '    [[+np.error_[[+npx.fieldName]]]]
    <fieldset id=\"np-[[+npx.fieldName]]-container\" class=\"[[+npx.class]]\" title=\"[[+npx.help]]\"><legend>[[+npx.caption]]</legend>
        [[+npx.hidden]]
            [[+npx.options]]
    </fieldset>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '227', '0', '0', 'npOuterTpl', 'Outer Tpl chunk for entire NewsPublisher form', '0', '85', '0', '<div class=\"newspublisher\">
        <h2 id=\"newspublisherHeader\">[[%np_main_header]]</h2>
        [[!+np.error_header:ifnotempty=`<h3>[[!+np.error_header]]</h3>`]]
        [[!+np.errors_presubmit:ifnotempty=`[[!+np.errors_presubmit]]`]]
        [[!+np.errors_submit:ifnotempty=`[[!+np.errors_submit]]`]]
        [[!+np.errors:ifnotempty=`[[!+np.errors]]`]]
  <form id=\"newspublisherForm\" action=\"[[~[[*id]]]]\" method=\"post\">
            <input name=\"hidSubmit\" type=\"hidden\" id=\"hidSubmit\" value=\"true\" />
        [[+npx.insert]]
         <span class = \"buttons\">
             <input class=\"submit\" type=\"submit\" name=\"Submit\" value=\"Submit\" />
             <input type=\"button\" class=\"cancel\" name=\"Cancel\" value=\"Cancel\" onclick=\"window.location = \'[[+np.cancel_url]]\' \" />
         </span>
        [[+np.post_stuff]]
  </form>
</div>', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '228', '0', '0', 'runnersform', '', '0', '0', '0', '<h3>Additional Runner [[+rnr_idx]]</h3>

 <div class=\"ten columns\"> 
      <div class=\"form-group[[+error.rnr-add[[+rnr_idx]]:notempty=` error`]]\">
        <label for=\"rnr-add[[+rnr_idx]]\">Runners Name <span class=\"error\">[[+error.rnr-add[[+rnr_idx]]]]</span></label>
        <input type=\"text\" name=\"rnr-add[[+rnr_idx]]\" id=\"rnr-add[[+rnr_idx]]\" value=\"[[!+fi.rnr-add[[+rnr_idx]]]]\" />
      </div>
       
       <div class=\"form-group[[+error.rnr-age:notempty=` error`]]\">
        <label for=\"rnr-age[[+rnr_idx]]\">Runners Age <span class=\"error\">[[+error.rnr-age[[+rnr_idx]]]]</span></label>
        <input type=\"text\" name=\"rnr-age[[+rnr_idx]]\" id=\"rnr-age[[+rnr_idx]]\" value=\"[[!+fi.rnr-age[[+rnr_idx]]]]\" />
      </div>
       
      <div class=\"form-group[[+error.rnr-sex[[+rnr_idx]]:notempty=` error`]]\">
        <label for=\"rnr-sex[[+rnr_idx]]\">Gender<span>[[+error.rnr-sex[[+rnr_idx]]]]</span> </label>
        <select name=\"rnr-sex[[+rnr_idx]]\" value=\"\">
          <option value=\"\"[[!+fi.rnr-sex[[+rnr_idx]]:FormItIsSelected=``]] >Select One</option>
          <option value=\"Male\" [[!+fi.rnr-sex[[+rnr_idx]]:FormItIsSelected=`Male`]]>Male</option>
          <option value=\"Female\" [[!+fi.rnr-sex[[+rnr_idx]]:FormItIsSelected=`Female`]]>Female</option>
        </select>
      </div>
       
      <div class=\"form-group[[+error.runname[[+rnr_idx]]:notempty=` error`]]\">
        <label for=\"runname[[+rnr_idx]]\">Run Name <span class=\"error\">[[+error.runname[[+rnr_idx]]]]</span></label>
        <input type=\"text\" name=\"runname[[+rnr_idx]]\" id=\"runname[[+rnr_idx]]\" value=\"[[*pagetitle]]\" />
      </div>
       
      <div class=\"form-group[[+error.rnr-dist[[+rnr_idx]]:notempty=` error`]]\">
        <label for=\"rnr-dist[[+rnr_idx]]\">Run Distance<span>[[+error.rnr-dist[[+rnr_idx]]]]</span> </label>
        <select name=\"rnr-dist[[+rnr_idx]]\">
          <option value=\"\" [[!+fi.rnr-dist[[+rnr_idx]]:FormItIsSelected=``]] >Select One</option>
          <option value=\"15k\" [[!+fi.rnr-dist[[+rnr_idx]]:FormItIsSelected=`15k`]] >15k</option>
          <option value=\"5k\" [[!+fi.rnr-dist[[+rnr_idx]]:FormItIsSelected=`5k`]] >5k</option>
        </select>
      </div>
 
      <div class=\"form-group[[+error.rnr-swag[[+rnr_idx]]:notempty=` error`]]\">
        <label for=\"rnr-swag[[+rnr_idx]]\">Swag<span>[[+error.rnr-swag[[+rnr_idx]]]]</span> </label>
        <select name=\"rnr-swag[[+rnr_idx]]\">
          <option value=\"\" [[!+fi.rnr-swag[[+rnr_idx]]:FormItIsSelected=``]] >Select One</option>
          <option value=\"t-lg\" [[!+fi.rnr-swag[[+rnr_idx]]:FormItIsSelected=`t-lg`]] >T-Shirt Large</option>
          <option value=\"t-sm\" [[!+fi.rnr-swag[[+rnr_idx]]:FormItIsSelected=`t-sm`]] >T-Shirt Small</option>
        </select>
      </div>
       
      <div class=\"form-group[[+error.rnr-price:notempty=` error`]]\">
        <label for=\"rnr-price[[+rnr_idx]]\">Run Price<span class=\"error\">[[+error.rnr-price[[+rnr_idx]]]]</span></label>
        <input type=\"text\" name=\"rnr-price[[+rnr_idx]]\" id=\"rnr-price[[+rnr_idx]]\" value=\"[[*prodPrice]]\" readonly />
      </div>
</div>      ', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '229', '0', '0', 'tvname_test', '', '0', '0', '0', '<h1>tvname-test</h1>
[[+tvname]]', '0', 'a:1:{s:6:\"tvname\";a:7:{s:4:\"name\";s:6:\"tvname\";s:4:\"desc\";s:0:\"\";s:4:\"type\";s:9:\"textfield\";s:7:\"options\";a:0:{}s:5:\"value\";s:11:\"[[+tvname]]\";s:7:\"lexicon\";N;s:4:\"area\";s:0:\"\";}}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '230', '0', '0', 'mnn_example', '', '0', '95', '0', 'Create a migxdb-TV with configs = mnn_resourcenodes.<br/>
Get the results:<br/>


[[migxLoopCollection?
&packageName=`migxnestednodes`
&classname=`mnnNodeNodeSelection`
&joins=`[{\"alias\":\"Node\"},{\"alias\":\"Child\"}]`
&where=`{\"resource_id\":\"[[*id]]\"}`
&tpl=`@CODE:[[+Node_name]]:[[+Child_name]]<br/>`
&sortConfig=`[{\"sortby\":\"Node.name\"}]`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '231', '0', '0', 'ImagePlus.demo', 'Demo chunk for Image+ template variable output.', '0', '96', '0', '<div>
    <h3>Image+ Demo Chunk</h3>
    <table>
        <thead>
        <tr>
            <th>Description</th>
            <th>Current Value</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>[[%imageplus.placeholder.url? &namespace=`imageplus`]]</td>
            <td>[[+url]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.alt? &namespace=`imageplus`]]</td>
            <td>[[+alt]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.width? &namespace=`imageplus`]]</td>
            <td>[[+width]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.height? &namespace=`imageplus`]]</td>
            <td>[[+height]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.source.src? &namespace=`imageplus`]]</td>
            <td>[[+source.src]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.source.width? &namespace=`imageplus`]]</td>
            <td>[[+source.width]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.source.height? &namespace=`imageplus`]]</td>
            <td>[[+source.height]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.crop.width? &namespace=`imageplus`]]</td>
            <td>[[+crop.width]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.crop.height? &namespace=`imageplus`]]</td>
            <td>[[+crop.height]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.crop.x? &namespace=`imageplus`]]</td>
            <td>[[+crop.x]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.crop.y? &namespace=`imageplus`]]</td>
            <td>[[+crop.y]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.options? &namespace=`imageplus`]]</td>
            <td>[[+options]]</td>
        </tr>
        <tr>
            <td>[[%imageplus.placeholder.crop.options? &namespace=`imageplus`]]</td>
            <td>[[+crop.options]]</td>
        </tr>
        </tbody>
    </table>

    <h4>Default image output</h4>

    <p>
        <img src=\"[[+url]]\" alt=\"[[+alt]]\"/>
    </p>

    <h4>Responsive image output (different crops for different viewports)</h4>

    <p>
        <picture>
            <source media=\"(min-width: 36em)\"
                    srcset=\"[[+source.src:pthumb=`w=1024`]] 1024w,
                        [[+source.src:pthumb=`w=640`]] 640w,
                        [[+source.src:pthumb=`w=320`]] 320w\"
                    sizes=\"33.3vw\"/>
            <source srcset=\"[[+source.src:pthumb=`[[+crop.options]]&w=640`]] 2x,
                        [[+source.src:pthumb=`[[+crop.options]]&w=320`]] 1x\"/>
            <img src=\"[[+url]]\"/>
        </picture>
    </p>
</div>', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '232', '0', '0', 'ImagePlus.image', 'Demo chunk for Image+ snippet output.', '0', '96', '0', '<img src=\"[[+url]]\" alt=\"[[+alt]]\"/>', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '233', '0', '0', 'gallery.gallery.tpl', '', '0', '0', '0', '<h3>[[+pagetitle]]</h3>
[[getImageList? 
    &tvname=`resourcealbum` 
    &tpl=`@CODE:[[+image]]`
    &limit=`1`
    &where=`{\"published\":\"1\"}`
    &docid=`[[+id]]`
    &pagetitle=`[[+pagetitle]]`
    &processTVs=`0`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '234', '0', '0', 'TinymceWrapperTVs', 'Takes care of all RichTextarea TVs', '0', '97', '0', 'tinymce.init({
mode : \"specific_textareas\", //DO NOT TOUCH
editor_selector : \"modx-richtext\", //DO NOT TOUCH
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
statusbar : false,
plugins:\"autoresize,preview,paste,contextmenu,image,wordcount,fullscreen,code,link,charmap,searchreplace,textpattern,emoticons,insertdatetime\",
link_list:[
[[-$TinymceWrapperLinkList]]
],
paste_data_images: true,
textpattern_patterns: [
         {start: \'*\', end: \'*\', format: \'italic\'},
         {start: \'**\', end: \'**\', format: \'bold\'},
         {start: \'#\', format: \'h1\'},
         {start: \'##\', format: \'h2\'},
         {start: \'###\', format: \'h3\'},
         {start: \'####\', format: \'h4\'},
         {start: \'#####\', format: \'h5\'},
         {start: \'######\', format: \'h6\'},
         {start: \'1. \', cmd: \'InsertOrderedList\'},
         {start: \'* \', cmd: \'InsertUnorderedList\'},
         {start: \'- \', cmd: \'InsertUnorderedList\'}
    ],
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"a,div,b,strong,i,em,h1,h2,h3,p,blockquote,ol,ul,pre\",
valid_elements: \"iframe[*],object[*],audio[*],-span[!title|!class<test test2],a[href|target|class|rel|title|data-ajax|data-iframe],strong,b,-p[class<text-align-left?text-align-center?text-align-right],br,-h1[class|data-ajax|data-iframe],-h2[class|data-ajax|data-iframe],-h3[class|data-ajax|data-iframe],-img[!src|!alt|!class=round_img|data-ajax|data-iframe],em,-blockquote,pre[class],-ol,-ul,-li,-code[class]\",
valid_children: \"-li[ul],-li[ol],-li[div],-strong[*],-em[*],-h1[*],-h2[*],-h3[*],-a[strong|em|h1|h2|h3|p|div],blockquote[p|ol|ul],pre[code],div[pre]\",
menubar:false,
relative_urls: false,
resize:true,
autoresize_min_height:100,
autoresize_max_height:400,
toolbar: \"newdocument | fullscreen preview | undo redo | blockquote | bold | italic | aligncenter | bullist numlist | link unlink | image responsivefilemanager | styleselect | charmap emoticons insertdatetime | searchreplace\",
image_advtab: true,
external_filemanager_path: extFilemanagerPath,
filemanager_title: \"Responsive Filemanager 9.9.3 For MODx Revo 2.3+\",
external_plugins: {
      filemanager: extPluginsFilemanager,
      responsivefilemanager: extPluginsResponsivefilemanager
    },
contextmenu: \"removeformat | link | image responsivefilemanager | code\",
setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '235', '0', '0', 'TinymceWrapperIntrotext', '//E.g.
tinymce.init({selector : \"#modx-resource-introtext\"});', '0', '97', '0', 'tinymce.init({
selector : \"#modx-resource-introtext\",
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
plugins: \"contextmenu,charmap,paste,link,preview,code,insertdatetime\",
toolbar: \"undo redo | newdocument | preview code | styleselect | blockquote | bold | italic | bullist numlist | link unlink | charmap | insertdatetime\",
contextmenu:\"link,code,styleselect\",
resize:true,
forced_root_block : \'\',
force_br_newlines : true,
force_p_newlines : false,
valid_elements:\"div,h1,h2,h3,h4,h5,h6,strong,b,i,em,span[*],blockquote,ol,ul,li,a\",
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"div,h1,h2,h3,h4,h5,h6,strong,b,i,em,span,blockquote,ol,ul,li,a\",
//statusbar : false,
elementpath: false,
menubar:false,
setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '236', '0', '0', 'TinymceWrapperContent', '//E.g.
tinymce.init({selector : \"#ta\"});', '0', '97', '0', 'tinymce.init({
selector : \"#ta\",
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
//statusbar : false,
plugins:\"autoresize,preview,paste,contextmenu,image,wordcount,fullscreen,code,link,charmap,searchreplace,textpattern,emoticons,insertdatetime\",
link_list:[
[[$TinymceWrapperLinkList]]
],
textpattern_patterns: [
         {start: \'*\', end: \'*\', format: \'italic\'},
         {start: \'**\', end: \'**\', format: \'bold\'},
         {start: \'#\', format: \'h1\'},
         {start: \'##\', format: \'h2\'},
         {start: \'###\', format: \'h3\'},
         {start: \'####\', format: \'h4\'},
         {start: \'#####\', format: \'h5\'},
         {start: \'######\', format: \'h6\'},
         {start: \'1. \', cmd: \'InsertOrderedList\'},
         {start: \'* \', cmd: \'InsertUnorderedList\'},
         {start: \'- \', cmd: \'InsertUnorderedList\'}
    ],
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"a,div,b,strong,i,em,h1,h2,h3,p,blockquote,ol,ul,pre\",
valid_elements: \"iframe[*],object[*],audio[*],-span[!title|!class<test test2],a[href|target|class|rel|title|data-ajax|data-iframe],strong,b,-p[class<text-align-left?text-align-center?text-align-right],br,-h1[class|data-ajax|data-iframe],-h2[class|data-ajax|data-iframe],-h3[class|data-ajax|data-iframe],-img[!src|!alt|!class=round_img|data-ajax|data-iframe],em,-blockquote,pre[class],-ol,-ul,-li,-code[class]\",
valid_children: \"-li[ul],-li[ol],-li[div],-strong[*],-em[*],-h1[*],-h2[*],-h3[*],-a[strong|em|h1|h2|h3|p|div],blockquote[p|ol|ul],pre[code],div[pre]\",
menubar:false,
relative_urls: false,
resize:true,
autoresize_min_height:100,
toolbar: \"undo redo | newdocument | fullscreen preview | undo redo | blockquote | bold | italic | aligncenter | bullist numlist | link unlink | image responsivefilemanager | styleselect | charmap emoticons insertdatetime | searchreplace\",
image_advtab: true,
external_filemanager_path: extFilemanagerPath,
filemanager_title: \"Responsive Filemanager 9.9.3 For MODx Revo 2.3+\",
external_plugins: {
      filemanager: extPluginsFilemanager,
      responsivefilemanager: extPluginsResponsivefilemanager
    },
contextmenu: \"removeformat | link | image responsivefilemanager | code\",

 setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '237', '0', '0', 'TinymceWrapperDescription', '//E.g.
tinymce.init({selector : \"#modx-resource-description\"});', '0', '97', '0', 'tinymce.init({
selector : \"#modx-resource-description\",
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
plugins: \"contextmenu,charmap,paste,link,preview,code,insertdatetime\",
toolbar: \"undo redo | newdocument | preview code | styleselect | blockquote | bold | italic | bullist numlist | link unlink | charmap | insertdatetime\",
contextmenu:\"link,code,styleselect\",
resize:true,
forced_root_block : \'\',
force_br_newlines : true,
force_p_newlines : false,
valid_elements:\"div,h1,h2,h3,h4,h5,h6,strong,b,i,em,span[*],blockquote,ol,ul,li,a,br\",
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"div,h1,h2,h3,h4,h5,h6,strong,b,i,em,span,blockquote,ol,ul,li,a,br\",
//statusbar : false,
elementpath: false,
menubar:false,
setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '238', '0', '0', 'TinymceWrapperLinkList', 'So you want to select a MODx resource from within TInyMCE, but don\'t want to write your own PHP snippet huh? Okay here is a cheat....watch out for JSON trailing commas', '0', '97', '0', '[[-remove the pdoMenu dash prefix if you have pdoMenu installed]]
[[-pdoMenu?
    &parents=`0`
    &level=`100`
    &limit=`0`
    &showHidden =`1`
    &tplOuter=`@INLINE [[+wrapper]]`
    &tpl=`@INLINE {title: \"[[+menutitle]] - [ [~[[+id]] ] ]\", value: \'[[+link]]\'},`
    &tplParentRow=`@INLINE {title: \"[[+menutitle]] - [ [~[[+id]] ] ]\", value: \'[[+link]]\', menu:[ [[+wrapper]]  ]},`
    &sortby=`pagetitle`
    &sortdir=`ASC`
   &checkPermissions=`load,list,view`
]]', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '239', '0', '0', 'TinymceWrapperMIGX', 'Takes care of all RichTextarea TVs', '0', '97', '0', 'tinymce.init({
mode: \"exact\",
elements: \"tv[[+tv_id]]\",
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
statusbar : false,
plugins:\"autoresize,preview,paste,contextmenu,image,wordcount,fullscreen,code,link,charmap,searchreplace,textpattern,emoticons,insertdatetime\",
link_list:[
[[-$TinymceWrapperLinkList]]
],
paste_data_images: true,
textpattern_patterns: [
         {start: \'*\', end: \'*\', format: \'italic\'},
         {start: \'**\', end: \'**\', format: \'bold\'},
         {start: \'#\', format: \'h1\'},
         {start: \'##\', format: \'h2\'},
         {start: \'###\', format: \'h3\'},
         {start: \'####\', format: \'h4\'},
         {start: \'#####\', format: \'h5\'},
         {start: \'######\', format: \'h6\'},
         {start: \'1. \', cmd: \'InsertOrderedList\'},
         {start: \'* \', cmd: \'InsertUnorderedList\'},
         {start: \'- \', cmd: \'InsertUnorderedList\'}
    ],
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"a,div,b,strong,i,em,h1,h2,h3,p,blockquote,ol,ul,pre\",
valid_elements: \"iframe[*],object[*],audio[*],-span[!title|!class<test test2],a[href|target|class|rel|title|data-ajax|data-iframe],strong,b,-p[class<text-align-left?text-align-center?text-align-right],br,-h1[class|data-ajax|data-iframe],-h2[class|data-ajax|data-iframe],-h3[class|data-ajax|data-iframe],-img[!src|!alt|!class=round_img|data-ajax|data-iframe],em,-blockquote,pre[class],-ol,-ul,-li,-code[class]\",
valid_children: \"-li[ul],-li[ol],-li[div],-strong[*],-em[*],-h1[*],-h2[*],-h3[*],-a[strong|em|h1|h2|h3|p|div],blockquote[p|ol|ul],pre[code],div[pre]\",
menubar:false,
relative_urls: false,
resize:true,
autoresize_min_height:100,
autoresize_max_height:400,
toolbar: \"newdocument | fullscreen preview | undo redo | blockquote | bold | italic | aligncenter | bullist numlist | link unlink | image responsivefilemanager | styleselect | charmap emoticons insertdatetime | searchreplace\",
image_advtab: true,
external_filemanager_path: extFilemanagerPath,
filemanager_title: \"Responsive Filemanager 9.9.3 For MODx Revo 2.3+\",
external_plugins: {
      filemanager: extPluginsFilemanager,
      responsivefilemanager: extPluginsResponsivefilemanager
    },
contextmenu: \"removeformat | link | image responsivefilemanager | code\",
setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '240', '0', '0', 'TinymceWrapperMIGX_custom', 'Takes care of all RichTextarea TVs', '0', '97', '0', 'tinymce.init({
mode: \"exact\",
elements: \"tv[[+tv_id]]\",
skin_url:\"[[++assets_url]]components/tinymcewrapper/tinymceskins/fairOphelia\",
statusbar : false,
plugins:\"autoresize,preview,paste,contextmenu,image,wordcount,fullscreen,code,link,charmap,searchreplace,textpattern,insertdatetime\",
link_list:[
[[-$TinymceWrapperLinkList]]
],
paste_data_images: true,
textpattern_patterns: [
         {start: \'*\', end: \'*\', format: \'italic\'},
         {start: \'**\', end: \'**\', format: \'bold\'},
         {start: \'#\', format: \'h1\'},
         {start: \'##\', format: \'h2\'},
         {start: \'###\', format: \'h3\'},
         {start: \'####\', format: \'h4\'},
         {start: \'#####\', format: \'h5\'},
         {start: \'######\', format: \'h6\'},
         {start: \'1. \', cmd: \'InsertOrderedList\'},
         {start: \'* \', cmd: \'InsertUnorderedList\'},
         {start: \'- \', cmd: \'InsertUnorderedList\'}
    ],
browser_spellcheck: true,
gecko_spellcheck: true,
paste_data_images: false,
paste_word_valid_elements: \"a,div,b,strong,i,em,h1,h2,h3,p,blockquote,ol,ul,pre\",
valid_elements: \"iframe[*],object[*],audio[*],-span[!title|!class<test test2],a[href|target|class|rel|title|data-ajax|data-iframe],strong,b,-p[class<text-align-left?text-align-center?text-align-right],br,-h1[class|data-ajax|data-iframe],-h2[class|data-ajax|data-iframe],-h3[class|data-ajax|data-iframe],-img[!src|!alt|!class=round_img|data-ajax|data-iframe],em,-blockquote,pre[class],-ol,-ul,-li,-code[class]\",
valid_children: \"-li[ul],-li[ol],-li[div],-strong[*],-em[*],-h1[*],-h2[*],-h3[*],-a[strong|em|h1|h2|h3|p|div],blockquote[p|ol|ul],pre[code],div[pre]\",
menubar:false,
relative_urls: false,
resize:true,
autoresize_min_height:100,
autoresize_max_height:400,
toolbar: \"newdocument | fullscreen preview | undo redo | blockquote | bold | italic | aligncenter | bullist numlist | link unlink | image responsivefilemanager | styleselect | charmap emoticons insertdatetime | searchreplace\",
image_advtab: true,
external_filemanager_path: extFilemanagerPath,
filemanager_title: \"Responsive Filemanager 9.9.3 For MODx Revo 2.3+\",
external_plugins: {
      filemanager: extPluginsFilemanager,
      responsivefilemanager: extPluginsResponsivefilemanager
    },
contextmenu: \"removeformat | link | image responsivefilemanager | code\",
setup: function(editor) {
        editor.on(\'keydown\', function(evt) {
            if (evt.keyCode == 83 && evt.ctrlKey && !evt.shiftKey && !evt.altKey && !evt.metaKey) {
           evt.preventDefault();
           $(\'#modx-abtn-save button\').trigger(\"click\");
       }
        });
    }
});', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '241', '0', '0', 'migx_resourceoptions', '', '0', '0', '0', '[[migxLoopCollection? 
    &classname=`modResource`
    &selectfields=`id,pagetitle`
    &where=`{\"parent\":\"3\"}`
    &toJsonPlaceholder=`json` 
]]
[[+json]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '242', '0', '0', 'testchunk3', '', '0', '2', '0', '', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '243', '0', '0', 'inputoptions_test', '', '0', '0', '0', 'none==||a==1||b==2||c==3||d==4', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '8', '0', '0', 'ahcfeedback_emailTpl_de', '', '0', '2', '0', '[[+vorname]] [[+name]]<br />
<a href=\"[[+url]]\">zum Feedback Formular</a> ', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '5', '0', '0', 'events', '', '0', '0', '0', '<div style=\"float:left;clear:both;\" >


[[+date:strtotime:date=`%d.%m.%Y`]] - [[+name]] <br />

[[!getImageListx? &value=`[[+images]]`]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '6', '0', '0', 'ahcfeedback_questionTpl', '', '0', '2', '0', '<div class=\"frage\">
<h3>[[+idx]]. [[+content_[[*lang]]]]</h3>
<span style=\"color:red;\" class=\"error\">[[!+fi.error.antwort_[[+id]]]]</span><br />
[[+type:is=`textarea`:then=`
<input type=\"hidden\" name=\"ismc_[[+id]]\" value=\"0\" />
<textarea name=\"antwort_[[+id]]\" class=\"cft_textarea\">
</textarea>
`:else=``]]

[[+type:is=`text`:then=`
<input type=\"hidden\" name=\"ismc_[[+id]]\" value=\"0\" />
<input type=\"text\" name=\"antwort_[[+id]]\" class=\"cft_text\" />
`:else=``]]

[[+type:is=`radio`:then=`
<input type=\"hidden\" name=\"ismc_[[+id]]\" value=\"1\" />
[[!migxLoopCollection? 
&where=`{\"answerset_id\":\"[[+answerset_id]]\"}`
&q_id=`[[+id]]` 
&packageName=`ahcfeedback` 
&classname=`afMcAnswers` 
&tpl=`ahcfeedback_answerTpl`
&sortConfig=`[{\"sortby\":\"smiley_rank\",\"sortdir\":\"DESC\"}]`
]]
`:else=``]]
</div>', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '7', '0', '0', 'ahcfeedback_answerTpl', '', '0', '2', '0', '<input type=\"radio\" name=\"antwort_[[+property.q_id]]\" value=\"[[+id]]\" />[[+content_[[*lang]]]] <br />
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '9', '0', '0', 'Feedback_Form', '', '0', '2', '0', '[[!ahc? &action=`validateRequest`]]

[[!$Feedback_Form_[[+validateRequest.isvalid]]]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '10', '0', '0', 'ahcfeedback_emailTpl_en', '', '0', '2', '0', '[[+vorname]] [[+name]]<br />
<a href=\"[[+url]]\">goto the Feedback Formular</a> ', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '11', '0', '0', 'Feedback_Form_0', '', '0', '2', '0', '<h2>Ungültige Anfrage([[+validateRequest.invalid_reason]])</h2>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '12', '0', '0', 'Feedback_Form_1', '', '0', '2', '0', '[[!FormIt? 
&hooks=`ahcHooks,email`
&ahchooks=`feedback2db` 
&emailSubject=`Feedbackformular von info@ahc-surface.com` 
&emailTpl=`FeedbackFormEmail` 
&emailTo=`b.perner@gmx.de,b.davis@bdcreative-design.com` 
&validate=`[[!migxLoopCollection? &packageName=`ahcfeedback` &classname=`afQuestion` &tpl=`@CODE:antwort_[[+id]]:[[+validate]]` &outputSeparator=`,`]]` 
&successMessage=`[[%success? &topic=`cft` &namespace=`AHC-Templates` &language=`[[*lang]]`]]`
&validationErrorMessage=`[[%error? &topic=`cft` &namespace=`AHC-Templates` &language=`[[*lang]]`]]`
]]
[[!+fi.validation_error_message:notempty=`<h2>[[!+fi.validation_error_message]]</h2>`]]

[[!+fi.successMessage:isnot=``:then=`<h2>[[!+fi.successMessage ]]</h2>`:else=`
<form method=\"post\" action=\"[[~[[*id]]? &scheme=`full`]]\">
<input type=\"hidden\" name=\"uid\" value=\"[[!getReqParam? &type=`REQUEST` &name=`uid`]]\" />
<input type=\"hidden\" name=\"code\" value=\"[[!getReqParam? &type=`REQUEST` &name=`code`]]\" />
[[!migxLoopCollection? &packageName=`ahcfeedback` &classname=`afQuestion` &tpl=`ahcfeedback_questionTpl`]]
<input  type=\"submit\" id=\"cft_button\" value=\"[[%submit? &topic=`plz-kontaktform` &namespace=`AHC-Templates` &language=`[[*lang]]`]]\">
</form>
`]]', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '13', '0', '0', 'FeedbackFormEmail', '', '0', '2', '0', 'Sehr geehrte Damen und Herren, <br>
Das Feedbackformular wurde ausgefüllt.
<br><br>
Von [[+vorname]] [[+name]], [[+email]]
<br><br>
mit folgenden Antworten:
<br><br>
[[+rows.antwort]]
<br>
Mit freundlichen Grüßen, <br>
www.ahc-surface.com', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '14', '0', '0', 'FeedbackFormEmailAntwortTpl', '', '0', '2', '0', '<h3>[[+question]]</h3>
[[+answer]]
<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '15', '1', '0', 'sendFeedbackRequests', '', '0', '2', '0', '[[!ahc? &action=`sendFeedbackRequests`]]', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '23', '0', '0', 'runSnippet', '', '0', '0', '0', '[[[[+snippet]]]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '24', '0', '0', 'galAlbumRowTpl', '', '0', '9', '0', '<li[[+cls:notempty=` class=\"[[+cls]]\"`]]><a href=\"[[~[[*id]]? &[[+albumRequestVar]]=`[[+id]]`]]\">[[+showName:notempty=`[[+name]]`]]</a></li>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '25', '0', '0', 'galItemThumb', '', '0', '9', '0', '<div class=\"[[+cls]]\">
    <a href=\"[[+linkToImage:if=`[[+linkToImage]]`:is=`1`:then=`[[+image_absolute]]`:else=`[[~[[*id]]?
            &[[+imageGetParam]]=`[[+id]]`
            &[[+albumRequestVar]]=`[[+album]]`
            &[[+tagRequestVar]]=`[[+tag]]` ]]`]]\" title=\"[[+name]]\" [[+link_attributes]]>

        <img class=\"[[+imgCls]]\" src=\"[[+thumbnail]]\" alt=\"[[+name]]\" [[+image_attributes]] />
    </a>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '26', '0', '0', 'bloxtestrow', '', '0', '0', '0', '<h2>[[+pagetitle]]</h2>
[[!blox? &classname=`modTemplateVarResource` &debug=`1` &limit=`5` &tplsx=`row:bloxtesttvrow` &where=`{\"contentid\":\"[[+id]]\"}` ]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '27', '0', '0', 'sidechunkA', '', '0', '11', '0', '<h2>chunk A</h2>

[[+extra]]

<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '28', '0', '0', 'sidechunkB', '', '0', '11', '0', '<h2>chunk B</h2>

[[+extra]]

<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '29', '0', '0', 'sidechunkC', '', '0', '11', '0', '<h2>chunk C</h2>

[[+extra]]

<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '30', '0', '0', 'sidechunkD', '', '0', '11', '0', '<h2>chunk D</h2>

[[+extra]]

<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '31', '0', '0', 'sidechunkE', '', '0', '11', '0', '<h2>chunk E</h2>

[[+extra]]

<br/><br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '32', '0', '0', 'migxalbumimage', '', '0', '0', '0', 'thumb:
<img src=\"/assets/resourceimages/[[*pagetitle]]/thumbs/[[+image]]\"/>
<br />

middle:
<img src=\"/assets/resourceimages/[[*pagetitle]]/middle/[[+image]]\"/>
<br />

big:
<img src=\"/assets/resourceimages/[[*pagetitle]]/big/[[+image]]\"/>
<br />

<a href=\"[[~[[*id]]? &migx_id=`[[+MIGX_id]]`]]\">view details</a>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '16', '0', '0', 'starTpl', 'Star Rating Default Template', '0', '3', '0', '[[+rating]]<span class=\"totalvotes\">Votes: [[+vote_count]]</span>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '17', '0', '0', 'sample.ArticlesLatestPostTpl', 'The tpl row for the latest post. Duplicate this to override it.', '0', '7', '0', '<li>
  <a href=\"[[~[[+id]]]]\">[[+pagetitle]]</a>
  [[+publishedon:notempty=`<br /> - [[+publishedon:strtotime:date=`%b %d, %Y`]]`]]
</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '18', '0', '0', 'sample.ArticleRowTpl', 'The tpl row for each post when listed on the main Articles Container page. Duplicate this to override it.', '0', '7', '0', '<div class=\"post\">
    <h2 class=\"title\"><a href=\"[[~[[+id]]]]\">[[+pagetitle]]</a></h2>
    <p class=\"post-info\">[[%articles.posted_by]] <a href=\"[[~[[*id]]]]author/[[+createdby:userinfo=`username`]]\">[[+createdby:userinfo=`username`]]</a> [[+tv.articlestags:notempty=` | <span class=\"tags\">[[%articles.tags]]: [[!tolinks? &items=`[[+tv.articlestags]]` &target=`[[*id]]` &useTagsFurl=`1`]]</span>`]]</p>
    <div class=\"entry\">
	    <p>[[+introtext:default=`[[+content:ellipsis=`400`]]`]]</p>
    </div>
    <p class=\"postmeta\">
      <span class=\"links\">
        <a href=\"[[~[[+id]]]]\" class=\"readmore\">[[%articles.read_more]]</a>
        [[+comments_enabled:is=`1`:then=`| <a href=\"[[~[[+id]]]]#comments\" class=\"comments\">[[%articles.comments]] ([[!QuipCount? &thread=`article-b[[+parent]]-[[+id]]`]])</a>`]]
        | <span class=\"date\">[[+publishedon:strtotime:date=`%b %d, %Y`]]</span>
      </span>
    </p>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '19', '0', '0', 'sample.ArticlesRss', 'The tpl for the RSS feed. Duplicate this to override it.', '0', '7', '0', '<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<rss version=\"2.0\" xml:lang=\"en-US\">
<channel>
  <title>[[++site_name]]</title>
  <link>[[~[[*id]]?scheme=`full`]]</link>
  <description>[[*description:cdata]]</description>
  <language>en</language>
  <copyright>Copyright [[+year]] by [[++site_admin]]. All Rights Reserved.</copyright>
  <ttl>120</ttl>
  [[+content]]
</channel>
</rss>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '20', '0', '0', 'sample.ArticlesRssItem', 'The tpl row for each RSS feed item. Duplicate this to override it.', '0', '7', '0', '<item>
    <title>[[+pagetitle]]</title>
    <link>[[~[[+id]]?scheme=`full`]]</link>
    <description>[[+introtext:default=`[[+content:ellipsis=`400`]]`:cdata]]</description>
    <pubDate>[[+publishedon:strtotime:date=`%a, %d %b %Y %H:%M:%S %z`]]</pubDate>
    <guid>[[~[[+id]]?scheme=`full`]]</guid>
    <author>[[+createdby:userinfo=`email`]] ([[+createdby:userinfo=`fullname`]])</author>
    [[!ArticlesStringSplitter? &string=`[[+tv.articlestags]]` &tpl=`sample.ArticlesRssCategoryNode`]]
</item>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '21', '0', '0', 'sample.ArchiveGroupByYear', 'The tpl wrapper for archives when grouped by year.', '0', '7', '0', '<ul>
    <li><a href=\"[[+url]]\">[[+year]]</a>
    <ul>
        [[+row]]
    </ul>
    </li>
</ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '22', '0', '0', 'sample.ArticlesRssCategoryNode', 'The tpl for each RSS category node for tagging.', '0', '7', '0', '<category>[[+item]]</category>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '33', '0', '0', 'jako', '', '0', '0', '0', '[[+resource]]<li>[[+resource:ne=``:then=`<a href=\"[[~[[+resource:renderSecond]]]]\">[[getResourceField? &id=`[[+resource:renderSecond]]`]]</a>
`:else=`[[+zustaendigkeit]]
`]]</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '34', '0', '0', 'sbgetresources', '', '0', '11', '0', '<div class=\"sidewidget\">
[[getResources? &parents=`[[+parents]]`]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '35', '0', '0', 'sblinklist', '', '0', '11', '0', '<div class=\"sidewidget\">
[[getImageList? &value=`[[+linklist]]`]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '36', '0', '0', 'wfListBoxOuter', '', '0', '0', '0', '[[+wf.wrapper]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '37', '0', '0', 'wfListBoxRow', '', '0', '0', '0', '[[treelevel? &id=`[[+wf.docid]]`]][[+wf.pagetitle]]==[[+wf.id]]||[[+wf.wrapper]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '38', '0', '0', 'tplEventColumn', '', '0', '0', '0', '<a href=\"[[~[[+id]]? &scheme=`full`]]\" target=\"_blank\">View</a>

<div style=\"background-color:[[+published:is=`1`:then=`silver`:else=`yellow`]];\">
pagetitle:[[+pagetitle]]<br/>
published:[[+published:is=`1`:then=`Ja`:else=`Nein`]]<br/>
<ul class=\"actions\">

<li><a href=\"#\" class=\"controlBtn update this.update\">Bearbeiten</a></li>

</ul>
</div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '39', '0', '0', 'migxrenderchunk', '', '0', '0', '0', 'MIGX-id:[[+MIGX_id]]</br>
Titel:[[+title]]</br>
[[getImageList? &value=`[[+submigx]]` &tpl=`submigx`]]  
<ul class=\"actions\"><li>
<a class=\"controlBtn schalten this.remove\" href=\"#\">Remove Item</a>
</li></ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '40', '0', '0', 'submigx', '', '0', '0', '0', '[[+title]]<br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '41', '0', '0', 'detailChunk', '', '0', '0', '0', '[[!getImageList? &tvname=`migx1` &where=`{\"MIGX_id\":\"[[!+migx_id]]\"}` ]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '42', '0', '0', 'listingChunk', '', '0', '0', '0', '[[!getImageList? &tvname=`migx1` &processTVs=`0` &tpl=`migxalbumimage` ]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '43', '0', '0', 'switchDetail', '', '0', '0', '0', '[[!migxSwitchDetailChunk? &detailChunk=`detailChunk` &listingChunk=`listingChunk`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '44', '0', '0', 'checkUrl', '', '0', '0', '0', '[[+title]] : <a href=\"[[+title:checkUrl]]\">[[+title:checkUrl]]</a><br />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '45', '0', '0', 'renderUrl', '', '0', '0', '0', '[[~[[+resource_id]]]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '46', '0', '0', 'tplMigxGallery', '', '0', '0', '0', '[[!getImageList? &tpl=`galleryImage` &docid=`[[+id]]` &tvname=`migx1`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '47', '0', '0', 'galleryImage', '', '0', '0', '0', '[[+title]]<br/>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '48', '0', '0', 'fx.Migxtpl', '', '0', '0', '0', '<div class=\"three mobile-two columns customers\">
[[+idx]]
<img src=\"[[+image:phpthumbof=`w=150`]]\" alt=\"\" />
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '49', '0', '0', 'build.config.php', 'Chunk', '0', '15', '0', '<?php

  /* next line require only for operating outside of MODX
    Create a file outside of the MODX web root with this content:
     <?php
     $fields = array();
     $fields[\'username\'] = \'your_MODX_username\';
     $fields[\'password\'] = \'your_MODX_password\';
     $fields[\'login_context\'] = \'mgr\';
     $fields[\'add_contexts\'] = \'mgr\';

     Put the full path to the file in the next line
  */


/* Define the MODX path constants necessary for connecting to your core and other directories.
 * If you have not moved the core, the current values should work.
 * In some cases, you may have to hard-code the full paths */
if (!defined(\'MODX_CORE_PATH\')) {
    define(\'MODX_CORE_PATH\', dirname(dirname(dirname(dirname(dirname(__FILE__))))) . \'/core/\');
    define(\'MODX_BASE_PATH\', dirname(dirname(dirname(dirname(dirname(__FILE__))))) . \'/\');
    define(\'MODX_MANAGER_PATH\', MODX_BASE_PATH . \'manager/\');
    define(\'MODX_CONNECTORS_PATH\', MODX_BASE_PATH . \'connectors/\');
    define(\'MODX_ASSETS_PATH\', MODX_BASE_PATH . \'assets/\');
}

/* not used -- here to prevent E_NOTICE warnings */
if (!defined(\'MODX_BASE_URL\')) {
    define(\'MODX_BASE_URL\', \'http://localhost/addons/\');
    define(\'MODX_MANAGER_URL\', \'http://localhost/addons/manager/\');
    define(\'MODX_ASSETS_URL\', \'http://localhost/addons/assets/\');
    define(\'MODX_CONNECTORS_URL\', \'http://localhost/addons/connectors/\');
}

', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '50', '0', '0', 'build.transport.php', 'Chunk', '0', '15', '0', '<?php
/**
 * Important: You should almost never need to edit this file,
 * except to add components that it won\'t handle (e.g., permissions,
 * users, policies, policy templates, ACL entries, and Form
 * Customization rules), and most of those might better be handled
 * in a script resolver, which you can add without editing this file.
 *
 * Important note: MyComponent never updates this file, so any changes
 * you make will be permanent.
 *
 * Build Script for MyComponent extra
 *
 * Copyright 2012-2013 by Bob Ray <http://bobsguides.com>
 * Created on 10-23-2012
 *
 * MyComponent is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * MyComponent is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * MyComponent; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package mycomponent
 * @subpackage build
 */

/**
 * This is the template for the build script, which creates the
 * transport.zip file for your extra.
 *

 */
/* See the tutorial at http://http://bobsguides.com/mycomponent-tutorial.html
 * for more detailed information about using the package.
 */

/* config file must be retrieved in a class */
if (!class_exists(\'BuildHelper\')) {
    class BuildHelper {

        public function __construct(&$modx) {
            /* @var $modx modX */
            $this->modx =& $modx;

        }

        public function getProps($configPath) {
            $properties = @include $configPath;
            return $properties;
        }

        public function sendLog($level, $message) {

            $msg = \'\';
            if ($level == MODX::LOG_LEVEL_ERROR) {
                $msg .= $this->modx->lexicon(\'mc_error\')
                    . \' -- \';
            }
            $msg .= $message;
            $msg .= \"\\n\";
            if (php_sapi_name() != \'cli\') {
                $msg = nl2br($msg);
            }
            echo $msg;
        }
    }
}

/* set start time */
$mtime = microtime();
$mtime = explode(\" \", $mtime);
$mtime = $mtime[1] + $mtime[0];
$tstart = $mtime;
set_time_limit(0);


/* Instantiate MODx -- if this require fails, check your
 * _build/build.config.php file
 */
require_once dirname(dirname(__FILE__)) . \'/_build/build.config.php\';

if ( (! isset($modx)) || (! $modx instanceof modX) ) {
    require_once MODX_CORE_PATH . \'model/modx/modx.class.php\';
    $modx = new modX();
    $modx->initialize(\'mgr\');
    $modx->getService(\'error\', \'error.modError\', \'\', \'\');
}

$modx->setLogLevel(xPDO::LOG_LEVEL_INFO);
$modx->setLogTarget(XPDO_CLI_MODE
    ? \'ECHO\'
    : \'HTML\');

if (!defined(\'MODX_CORE_PATH\')) {
    session_write_close();
    die(\'build.config.php is not correct\');
}

@include dirname(__FILE__) . \'/config/current.project.php\';

if (!$currentProject) {
    session_write_close();
    die(\'Could not get current project\');
}

$helper = new BuildHelper($modx);

$modx->lexicon->load(\'mycomponent:default\');

$props = $helper->getProps(dirname(__FILE__) . \'/config/\' . $currentProject . \'.config.php\');

if (!is_array($props)) {
    session_write_close();
    die($modx->lexicon(\'mc_no_config_file\'));
}

$criticalSettings = array(
    \'packageNameLower\',
    \'packageName\',
    \'version\',
    \'release\'
);

foreach ($criticalSettings as $setting) {
    if (!isset($setting)) {
        session_write_close();
        die($modx->lexicon(\'mc_critical_setting_not_set\')
            . \': \' . $setting);
    }
}


if (strpos($props[\'packageNameLower\'], \'-\') || strpos($props[\'packageNameLower\'], \' \')) {
    die ($modx->lexicon(\"mc_space_hyphen_warning\"));
}
/* Set package info. These are initially set from the the the project config
 * but feel free to hard-code them for future versions */

define(\'PKG_NAME\', $props[\'packageName\']);
define(\'PKG_NAME_LOWER\', $props[\'packageNameLower\']);
define(\'PKG_VERSION\', $props[\'version\']);
define(\'PKG_RELEASE\', $props[\'release\']);


/* define sources */
$root = dirname(dirname(__FILE__)) . \'/\';
$sources = array(
    \'root\' => $root,
    \'build\' => $root . \'_build/\',
    \'config\' => $root . \'_build/config/\',
    \'utilities\' => $root . \'_build/utilities/\',
    /* note that the next two must not have a trailing slash */
    \'source_core\' => $root . \'core/components/\' . PKG_NAME_LOWER,
    \'source_assets\' => $root . \'assets/components/\' . PKG_NAME_LOWER,
    \'resolvers\' => $root . \'_build/resolvers/\',
    \'validators\' => $root . \'_build/validators/\',
    \'data\' => $root . \'_build/data/\',
    \'docs\' => $root . \'core/components/\' . PKG_NAME_LOWER . \'/docs/\',
    \'install_options\' => $root . \'_build/install.options/\',
    \'packages\' => $root . \'core/packages\',
    /* no trailing slash */

);
unset($root);


$categories = require_once $sources[\'build\'] . \'config/categories.php\';

if (empty ($categories)) {
    die ($modx->lexicon(\'no_categories\'));
}

/* Set package options - you can set these manually, but it\'s
 * recommended to let them be generated automatically
 */

$hasAssets = is_dir($sources[\'source_assets\']); /* Transfer the files in the assets dir. */
$hasCore = is_dir($sources[\'source_core\']); /* Transfer the files in the core dir. */

$hasContexts = file_exists($sources[\'data\'] . \'transport.contexts.php\');
$hasResources = file_exists($sources[\'data\'] . \'transport.resources.php\');
$hasValidators = is_dir($sources[\'build\'] . \'validators\'); /* Run a validators before installing anything */
$hasResolvers = is_dir($sources[\'build\'] . \'resolvers\');
$hasSetupOptions = is_dir($sources[\'data\'] . \'install.options\'); /* HTML/PHP script to interact with user */
$hasMenu = file_exists($sources[\'data\'] . \'transport.menus.php\'); /* Add items to the MODx Top Menu */
$hasSettings = file_exists($sources[\'data\'] . \'transport.settings.php\'); /* Add new MODx System Settings */
$hasContextSettings = file_exists($sources[\'data\'] . \'transport.contextsettings.php\');
$hasSubPackages = is_dir($sources[\'data\'] . \'subpackages\');
$minifyJS = $modx->getOption(\'minifyJS\', $props, false);

$helper->sendLog(MODX::LOG_LEVEL_INFO, \"\\n\" . $modx->lexicon(\'mc_project\')
    . \': \' . $currentProject);
$helper->sendLog(MODX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_action\')
    . \': \' . $modx->lexicon(\'mc_build\')
);
$helper->sendLog(MODX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_created_package\')
    . \': \' . PKG_NAME_LOWER . \'-\' . PKG_VERSION . \'-\' . PKG_RELEASE);
$helper->sendLog(MODX::LOG_LEVEL_INFO, \"\\n\" . $modx->lexicon(\'mc_created_namespace\')
    . \': \' . PKG_NAME_LOWER);
/* load builder */
$modx->setLogLevel(MODX::LOG_LEVEL_ERROR);
$modx->loadClass(\'transport.modPackageBuilder\', \'\', false, true);
$builder = new modPackageBuilder($modx);
$builder->createPackage(PKG_NAME_LOWER, PKG_VERSION, PKG_RELEASE);

$assetsPath = $hasAssets
    ? \'{assets_path}components/\' . PKG_NAME_LOWER . \'/\'
    : \'\';
$builder->registerNamespace(PKG_NAME_LOWER, false, true, \'{core_path}components/\' . PKG_NAME_LOWER . \'/\', $assetsPath);
$modx->setLogLevel(MODX::LOG_LEVEL_INFO);

/* Transport Contexts */

if ($hasContexts) {
    $contexts = include $sources[\'data\'] . \'transport.contexts.php\';
    if (!is_array($contexts)) {
        $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_contexts_not_an_array\'));
    } else {
        $attributes = array(
            xPDOTransport::UNIQUE_KEY => \'key\',
            xPDOTransport::PRESERVE_KEYS => true,
            xPDOTransport::UPDATE_OBJECT => false,
        );
        foreach ($contexts as $context) {
            $vehicle = $builder->createVehicle($context, $attributes);
            $builder->putVehicle($vehicle);
        }
        $helper->sendLog(modX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_packaged\')
            . \' \' .
            count($contexts) . \' \' . $modx->lexicon(\'mc_new_contexts\')
            . \'.\');
        unset($contexts, $context, $attributes);
    }
}


/* Transport Resources */

if ($hasResources) {
    $resources = include $sources[\'data\'] . \'transport.resources.php\';
    if (!is_array($resources)) {
        $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_resources_not_an_array\')
            . \'.\');
    } else {
        $attributes = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'pagetitle\',
            xPDOTransport::RELATED_OBJECTS => true,
            xPDOTransport::RELATED_OBJECT_ATTRIBUTES => array(
                \'ContentType\' => array(
                    xPDOTransport::PRESERVE_KEYS => false,
                    xPDOTransport::UPDATE_OBJECT => true,
                    xPDOTransport::UNIQUE_KEY => \'name\',
                ),
            ),
        );
        foreach ($resources as $resource) {
            $vehicle = $builder->createVehicle($resource, $attributes);
            $builder->putVehicle($vehicle);
        }
        $helper->sendLog(modX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_packaged\')
            . \' \' . count($resources) . \' \' . $modx->lexicon(\'mc_resources\')
            . \'.\');
    }
    unset($resources, $resource, $attributes);
}

/* load new system settings */
if ($hasSettings) {
    $settings = include $sources[\'data\'] . \'transport.settings.php\';
    if (!is_array($settings)) {
        $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_settings_not_an_array\')
            . \'.\');
    } else {
        $attributes = array(
            xPDOTransport::UNIQUE_KEY => \'key\',
            xPDOTransport::PRESERVE_KEYS => true,
            xPDOTransport::UPDATE_OBJECT => true,
        );
        foreach ($settings as $setting) {
            $vehicle = $builder->createVehicle($setting, $attributes);
            $builder->putVehicle($vehicle);
        }
        $helper->sendLog(modX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_packaged\')
            . \' \' . count($settings) .
            \' \' . $modx->lexicon(\'mc_new_system_settings\')
            . \'.\');
        unset($settings, $setting, $attributes);
    }
}

/* load new context settings */
if ($hasContextSettings) {
    $settings = include $sources[\'data\'] . \'transport.contextsettings.php\';
    if (!is_array($settings)) {
        $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_context_settings_not_an_array\')
            . \'.\');
    } else {
        $attributes = array(
            xPDOTransport::UNIQUE_KEY => \'key\',
            xPDOTransport::PRESERVE_KEYS => true,
            xPDOTransport::UPDATE_OBJECT => true,
        );
        foreach ($settings as $setting) {
            $vehicle = $builder->createVehicle($setting, $attributes);
            $builder->putVehicle($vehicle);
        }
        $helper->sendLog(modX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_packaged\')
            . \' \' . count($settings) .
            \' \' . $modx->lexicon(\'mc_context_settings\')
            . \'.\');
        unset($settings, $setting, $attributes);
    }
}

/* minify JS */

if ($minifyJS) {
    $helper->sendLog(modX::LOG_LEVEL_INFO, \'Creating js-min file(s)\');
    // require $sources[\'build\'] . \'utilities/jsmin.class.php\';
    require $sources[\'utilities\'] . \'jsmin.class.php\';

    $jsDir = $sources[\'source_assets\'] . \'/js\';

    if (is_dir($jsDir)) {
        $files = scandir($jsDir);
        foreach ($files as $file) {
            /* skip non-js and already minified files */
            if ((!stristr($file, \'.js\') || strstr($file, \'min\'))) {
                continue;
            }

            $jsmin = JSMin::minify(file_get_contents($sources[\'source_assets\'] . \'/js/\' . $file));
            if (!empty($jsmin)) {
                $outFile = $jsDir . \'/\' . str_ireplace(\'.js\', \'-min.js\', $file);
                $fp = fopen($outFile, \'w\');
                if ($fp) {
                    fwrite($fp, $jsmin);
                    fclose($fp);
                    $helper->sendLog(modX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_created\')
                        . \': \' . $outFile);
                } else {
                    $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_could_not_open\')
                        . \': \' . $outFile);
                }
            }
        }

    } else {
        $helper->sendLog(modX::LOG_LEVEL_ERROR, $modx->lexicon(\'mc_could_not_open_js_directory\')
            . \'.\');
    }
}

/* Create each Category and its Elements */

$i = 0;
$count = count($categories);

foreach ($categories as $k => $categoryName) {
    /* @var $categoryName string */
    $categoryNameLower = strtolower($categoryName);

    /* See what we have based on the files */
    $hasSnippets = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.snippets.php\');
    $hasChunks = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.chunks.php\');
    $hasTemplates = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.templates.php\');
    $hasTemplateVariables = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.tvs.php\');
    $hasPlugins = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.plugins.php\');
    $hasPropertySets = file_exists($sources[\'data\'] . $categoryNameLower . \'/transport.propertysets.php\');

    /* @var $category modCategory */
    $category = $modx->newObject(\'modCategory\');
    $i++; /* will be 1 for the first category */
    $category->set(\'id\', $i);
    $category->set(\'category\', $categoryName);
    $helper->sendLog(MODX::LOG_LEVEL_INFO,
        $modx->lexicon(\'mc_creating_category\')
            . \': \' . $categoryName);
    $helper->sendLog(MODX::LOG_LEVEL_INFO, $modx->lexicon(\'mc_processing_elements_in_category\')
        . \': \' . $categoryName);

    /* add snippets */
    if ($hasSnippets) {

        $snippets = include $sources[\'data\'] . $categoryNameLower  . \'/transport.snippets.php\';

        /* note: Snippets\' default properties are set in transport.snippets.php */
        if (is_array($snippets)) {
            if ($category->addMany($snippets, \'Snippets\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($snippets) . \' \' .
                    $modx->lexicon(\'mc_snippets\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' . $modx->lexicon(\'mc_adding_snippets_failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                $modx->lexicon(\'mc_non_array_in\')
                . \' transport.snippets.php\');
        }
    }

    if ($hasPropertySets) {
        $propertySets = include $sources[\'data\'] . $categoryNameLower .\'/transport.propertysets.php\';
        //  note: property set\' properties are set in transport.propertysets.php
        if (is_array($propertySets)) {
            if ($category->addMany($propertySets, \'PropertySets\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($propertySets) . \' \' .
                    $modx->lexicon(\'mc_property_sets\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                    $modx->lexicon(\'mc_adding_property_sets_failed~~Adding Property Sets
                failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' . $modx->lexicon(\'mc_non_array_in\')
                . \' transport.propertysets.php\');
        }
    }
    if ($hasChunks) { /* add chunks  */
        $helper->sendLog(modX::LOG_LEVEL_INFO, \'Adding Chunks.\');
        /* note: Chunks\' default properties are set in transport.chunks.php */
        $chunks = include $sources[\'data\'] . $categoryNameLower .\'/transport.chunks.php\';
        if (is_array($chunks)) {
            if ($category->addMany($chunks, \'Chunks\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($chunks) . \' \' .
                    $modx->lexicon(\'mc_chunks\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                    $modx->lexicon(\'mc_adding_chunks_failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                $modx->lexicon(\'mc_non_array_in\')
                . \' transport.chunks.php\');
        }
    }


    if ($hasTemplates) { /* add templates  */
        $helper->sendLog(modX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_adding_templates\')
                . \'.\');
        /* note: Templates\' default properties are set in transport.templates.php */
        $templates = include $sources[\'data\'] . $categoryNameLower .\'/transport.templates.php\';
        if (is_array($templates)) {
            if ($category->addMany($templates, \'Templates\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($templates) . \' \' .
                    $modx->lexicon(\'mc_templates\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                    $modx->lexicon(\'mc_adding_templates_failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                $modx->lexicon(\'mc_non_array_in\')
                . \' transport.templates.php\');
        }
    }

    if ($hasTemplateVariables) { /* add template variables  */
        $helper->sendLog(modX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_adding_template_variables\')
                . \'.\');
        /* note: Template Variables\' default properties are set in transport.tvs.php */
        $tvs = include $sources[\'data\'] . $categoryNameLower .\'/transport.tvs.php\';
        if (is_array($tvs)) {
            if ($category->addMany($tvs, \'TemplateVars\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($tvs) . \' \' .
                    $modx->lexicon(\'mc_tvs\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                    $modx->lexicon(\'mc_adding_tvs_failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                $modx->lexicon(\'mc_non_array_in\')
                . \' transport.tvs.php\');
        }
    }


    if ($hasPlugins) {
        /* Plugins\' default properties are set in transport.plugins.php */
        $plugins = include $sources[\'data\'] . $categoryNameLower . \'/transport.plugins.php\';
        if (is_array($plugins)) {
            if ($category->addMany($plugins, \'Plugins\')) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . count($plugins) . \' \' .
                    $modx->lexicon(\'mc_plugins\')
                    . \'.\');
            } else {
                $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                    $modx->lexicon(\'mc_adding_plugins_failed\')
                    . \'.\');
            }
        } else {
            $helper->sendLog(modX::LOG_LEVEL_FATAL, \'    \' .
                $modx->lexicon(\'mc_non_array_in\')
                . \' transport.plugins.php\');
        }
    }

    /* Create Category attributes array dynamically
     * based on which elements are present
     */

    $attr = array(
        xPDOTransport::UNIQUE_KEY => \'category\',
        xPDOTransport::PRESERVE_KEYS => false,
        xPDOTransport::UPDATE_OBJECT => true,
        xPDOTransport::RELATED_OBJECTS => true,
    );

    if ($hasValidators && $i == 1) { /* only install these on first pass */
        $attr[xPDOTransport::ABORT_INSTALL_ON_VEHICLE_FAIL] = true;
    }

    if ($hasSnippets) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'Snippets\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'name\',
        );
    }

    if ($hasPropertySets) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'PropertySets\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'name\',
        );
    }

    if ($hasChunks) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'Chunks\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'name\',
        );
    }

    if ($hasPlugins) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'Plugins\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'name\',
        );
    }

    if ($hasTemplates) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'Templates\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'templatename\',
        );
    }

    if ($hasTemplateVariables) {
        $attr[xPDOTransport::RELATED_OBJECT_ATTRIBUTES][\'TemplateVars\'] = array(
            xPDOTransport::PRESERVE_KEYS => false,
            xPDOTransport::UPDATE_OBJECT => true,
            xPDOTransport::UNIQUE_KEY => \'name\',
        );
    }

    /* create a vehicle for the category and all the things
     * we\'ve added to it.
     */
    $vehicle = $builder->createVehicle($category, $attr);

    if ($hasValidators && $i == 1) { /* only install these on first pass */
        $helper->sendLog(MODX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_processing_validators\'));
        $validators = empty($props[\'validators\'])
            ? array()
            : $props[\'validators\'];
        if (!empty($validators)) {
            foreach ($validators as $validator) {
                if ($validator == \'default\') {
                    $validator = PKG_NAME_LOWER;
                }
                $file = $sources[\'validators\'] . $validator . \'.validator.php\';
                if (file_exists($file)) {
                    $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' . $modx->lexicon(\'mc_packaging\')
                        . \' \' .
                        $validator . \' \' . $modx->lexicon(\'mc_validator\')
                        . \'.\');
                    $vehicle->validate(\'php\', array(
                                                   \'source\' => $file,
                                              ));
                } else {
                    $helper->sendLog(modX::LOG_LEVEL_ERROR,
                        $modx->lexicon(\'mc_could_not_find_validator_file~~Could not find Validator
                    file\')
                            . \': \' . $file);
                }
            }
        }
    }

    if ($hasCore && $i == 1) {
        $helper->sendLog(MODX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_packaged_core_files\'));
        $vehicle->resolve(\'file\', array(
                                       \'source\' => $sources[\'source_core\'],
                                       \'target\' => \"return MODX_CORE_PATH . \'components/\';\",
                                  ));
    }

    /* This section transfers every file in the local
       mycomponents/mycomponent/assets directory to the
       target site\'s assets/mycomponent directory on install.
     */

    if ($hasAssets && $i == 1) {
        $helper->sendLog(MODX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_packaged_assets_files\'));
        $vehicle->resolve(\'file\', array(
                                       \'source\' => $sources[\'source_assets\'],
                                       \'target\' => \"return MODX_ASSETS_PATH . \'components/\';\",
                                  ));
    }


    /* Package script resolvers, if any */
    if (($i == $count) && $hasResolvers) { /* add resolvers to last category only */
        $resolvers = empty($props[\'resolvers\'])
            ? array()
            : $props[\'resolvers\'];
        $resolvers = array_merge(array(
                                      \'category\',
                                      \'plugin\',
                                      \'tv\',
                                      \'resource\',
                                      \'propertyset\'
                                 ), $resolvers);
        $helper->sendLog(MODX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_processing_resolvers\'));

        foreach ($resolvers as $resolver) {
            if ($resolver == \'default\') {
                $resolver = PKG_NAME_LOWER;
            }

            $file = $sources[\'resolvers\'] . $resolver . \'.resolver.php\';
            if (file_exists($file)) {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_packaged\')
                    . \' \' . $resolver . \' \' .
                    $modx->lexicon(\'mc_resolver\')
                    . \'.\');
                $vehicle->resolve(\'php\', array(
                                              \'source\' => $sources[\'resolvers\'] . $resolver . \'.resolver.php\',
                                         ));
            } else {
                $helper->sendLog(modX::LOG_LEVEL_INFO, \'    \' .
                    $modx->lexicon(\'mc_no\')
                    . \' \' . $resolver . \' \' .
                    $modx->lexicon(\'mc_resolver\')
                    . \'.\');
            }
        }
    }

    /* Add subpackages */
    /* The transport.zip files will be copied to core/packages
     * but will have to be installed manually with \"Add New Package and
     *  \"Search Locally for Packages\" in Package Manager
     */

    if ($hasSubPackages && $i == 1) {
        $helper->sendLog(modX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_packaging_subpackages\')
                . \'.\');
        $vehicle->resolve(\'file\', array(
                                       \'source\' => $sources[\'packages\'],
                                       \'target\' => \"return MODX_CORE_PATH;\",
                                  ));
    }

    /* Put the category vehicle (with all the stuff we added to the
     * category) into the package
     */
    $builder->putVehicle($vehicle);
}
/* Transport Menus */
if ($hasMenu) {
    /* load menu */
    $helper->sendLog(modX::LOG_LEVEL_INFO,
        $modx->lexicon(\'mc_packaging_menu\')
            . \'.\');
    $menus = include $sources[\'data\'] . \'transport.menus.php\';
    foreach ($menus as $menu) {
        if (empty($menu)) {
            $helper->sendLog(modX::LOG_LEVEL_ERROR,
                $modx->lexicon(\'mc_could_not_package_menu\')
                    . \'.\');
        } else {
            $vehicle = $builder->createVehicle($menu, array(
                                                           xPDOTransport::PRESERVE_KEYS => true,
                                                           xPDOTransport::UPDATE_OBJECT => true,
                                                           xPDOTransport::UNIQUE_KEY => \'text\',
                                                           xPDOTransport::RELATED_OBJECTS => true,
                                                           xPDOTransport::RELATED_OBJECT_ATTRIBUTES => array(
                                                               \'Action\' => array(
                                                                   xPDOTransport::PRESERVE_KEYS => false,
                                                                   xPDOTransport::UPDATE_OBJECT => true,
                                                                   xPDOTransport::UNIQUE_KEY => array(
                                                                       \'namespace\',
                                                                       \'controller\'
                                                                   ),
                                                               ),
                                                           ),
                                                      ));
            $builder->putVehicle($vehicle);
            unset($vehicle, $menu);
        }
        $helper->sendLog(modX::LOG_LEVEL_INFO,
            $modx->lexicon(\'mc_packaged\')
                . \' \' . count($menus) . \' \' .
                $modx->lexicon(\'mc_menu_items\')
                . \'.\');
    }
}

/* Next-to-last step - pack in the license file, readme.txt, changelog,
 * and setup options 
 */
$attr = array(
    \'license\' => file_get_contents($sources[\'docs\'] . \'license.txt\'),
    \'readme\' => file_get_contents($sources[\'docs\'] . \'readme.txt\'),
    \'changelog\' => file_get_contents($sources[\'docs\'] . \'changelog.txt\'),
);

if ($hasSetupOptions && !empty($props[\'install.options\'])) {
    $attr[\'setup-options\'] = array(
        \'source\' => $sources[\'install_options\'] . \'user.input.php\',
    );
} else {
    $attr[\'setup-options\'] = array();
}
$builder->setPackageAttributes($attr);

/* Last step - zip up the package */
$builder->pack();

/* report how long it took */
$mtime = microtime();
$mtime = explode(\" \", $mtime);
$mtime = $mtime[1] + $mtime[0];
$tend = $mtime;
$totalTime = ($tend - $tstart);
$totalTime = sprintf(\"%2.4f s\", $totalTime);

$helper->sendLog(xPDO::LOG_LEVEL_INFO, $modx->lexicon(\'mc_package_built\')
    . \'.\');
$helper->sendLog(xPDO::LOG_LEVEL_INFO, $modx->lexicon(\'mc_execution_time\')
    . \': \' . $totalTime);

return \'\';', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '51', '0', '0', 'categoryresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
 * Category resolver  for [[+packageName]] extra.
 * Sets Category Parent
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 * @package [[+packageNameLower]]
 * @subpackage build
 */

/* @var $object xPDOObject */
/* @var $modx modX */
/* @var $parentObj modResource */
/* @var $templateObj modTemplate */

/* @var array $options */

if (!function_exists(\'checkFields\')) {
    function checkFields($required, $objectFields) {
        global $modx;
        $fields = explode(\',\', $required);
        foreach ($fields as $field) {
            if (!isset($objectFields[$field])) {
                $modx->log(MODX::LOG_LEVEL_ERROR, \'[Category Resolver] Missing field: \' . $field);
                return false;
            }
        }
        return true;
    }
}
if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:

            $intersects = \'[[+intersects]]\';

            if (is_array($intersects)) {
                foreach ($intersects as $k => $fields) {
                    /* make sure we have all fields */
                    if (!checkFields(\'category,parent\', $fields)) {
                        continue;
                    }
                    $categoryObj = $modx->getObject(\'modCategory\', array(\'category\' => $fields[\'category\']));
                    if (!$categoryObj) {
                        continue;
                    }
                    $parentObj = $modx->getObject(\'modCategory\', array(\'category\' => $fields[\'parent\']));
                        if ($parentObj) {
                            $categoryObj->set(\'parent\', $parentObj->get(\'id\'));
                        }
                    $categoryObj->save();
                }
            }
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '52', '0', '0', 'changelog.txt.tpl', 'Chunk', '0', '15', '0', 'Changelog for [[+packageName]]

[[+packageName]] 1.0.0
---------------------------------
Initial Version', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '53', '0', '0', 'classfile.php', 'Chunk', '0', '15', '0', '<?php
/**
 * [[+className]] class file for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 *
 * @package [[+packageNameLower]]
 */


 class MyClass {
    /** @var $modx modX */
    public $modx;
    /** @var $props array */
    public $props;

    function __construct(&$modx, &$config = array())
    {
        $this->modx =& $modx;
        $this->props =& $config;
    }


}', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '54', '0', '0', 'css.tpl', 'Chunk', '0', '15', '0', '/**
 * CSS file for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
 * @package [[+packageNameLower]]
 */', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '55', '0', '0', 'example.config.php', 'Chunk', '0', '15', '0', '<?php

$packageNameLower = \'example\'; /* No spaces, no dashes */

$components = array(
    /* These are used to define the package and set values for placeholders */
    \'packageName\' => \'Example\',  /* No spaces, no dashes */
    \'packageNameLower\' => $packageNameLower,
    \'packageDescription\' => \'Example project for MyComponent extra\',
    \'version\' => \'1.0.0\',
    \'release\' => \'beta1\',
    \'author\' => \'Bob Ray\',
    \'email\' => \'<http://bobsguides.com>\',
    \'authorUrl\' => \'http://bobsguides.com\',
    \'authorSiteName\' => \"Bob\'s Guides\",
    \'packageDocumentationUrl\' => \'http://bobsguides.com/example-tutorial.html\',
    \'copyright\' => \'2013\',

    /* no need to edit this except to change format */
    \'createdon\' => strftime(\'%m-%d-%Y\'),

    \'gitHubUsername\' => \'BobRay\',
    \'gitHubRepository\' => \'Example\',

    /* two-letter code of your primary language */
    \'primaryLanguage\' => \'en\',

    /* Set directory and file permissions for project directories */
    \'dirPermission\' => 0755,  /* No quotes!! */
    \'filePermission\' => 0644, /* No quotes!! */

    /* Define source and target directories (mycomponent root and core directories) */
    \'mycomponentRoot\' => $this->modx->getOption(\'mc.root\', null,
        MODX_CORE_PATH . \'components/mycomponent/\'),
    /* path to MyComponent source files */
    \'mycomponentCore\' => $this->modx->getOption(\'mc.core_path\', null,
        MODX_CORE_PATH . \'components/mycomponent/core/components/mycomponent/\'),
    /* path to new project root */
    \'targetRoot\' => MODX_ASSETS_PATH . \'mycomponents/\' . $packageNameLower . \'/\',


    /* *********************** NEW SYSTEM SETTINGS ************************ */

    /* If your extra needs new System Settings, set their field values here.
     * You can also create or edit them in the Manager (System -> System Settings),
     * and export them with exportObjects. If you do that, be sure to set
     * their namespace to the lowercase package name of your extra */

    \'newSystemSettings\' => array(
        \'example_system_setting1\' => array( // key
            \'key\' => \'example_system_setting1\',
            \'name\' => \'Example Setting One\',
            \'description\' => \'Description for setting one\',
            \'namespace\' => \'example\',
            \'xtype\' => \'textfield\',
            \'value\' => \'value1\',
            \'area\' => \'area1\',
        ),
        \'example_system_setting2\' => array( // key
            \'key\' => \'example_system_setting2\',
            \'name\' => \'Example Setting Two\',
            \'description\' => \'Description for setting two\',
            \'namespace\' => \'example\',
            \'xtype\' => \'combo-boolean\',
            \'value\' => true,
            \'area\' => \'area2\',
        ),
    ),

    /* ************************ NEW SYSTEM EVENTS ************************* */

    /* Array of your new System Events (not default
     * MODX System Events). Listed here so they can be created during
     * install and removed during uninstall.
     *
     * Warning: Do *not* list regular MODX System Events here !!! */

    \'newSystemEvents\' => array(
        \'OnMyEvent1\' => array(
            \'name\' => \'OnMyEvent1\',
        ),
        \'OnMyEvent2\' => array(
            \'name\' => \'OnMyEvent2\',
            \'groupname\' => \'Example\',
            \'service\' => 1,
        ),
    ),

    /* ************************ NAMESPACE(S) ************************* */
    /* (optional) Typically, there\'s only one namespace which is set
     * to the $packageNameLower value. Paths should end in a slash
    */

    \'namespaces\' => array(
        \'example\' => array(
            \'name\' => \'example\',
            \'path\' => \'{core_path}components/example/\',
            \'assets_path\' => \'{assets_path}components/example/\',
        ),

    ),

    /* ************************ CONTEXT(S) ************************* */
    /* (optional) List any contexts other than the \'web\' context here
    */

    \'contexts\' => array(
        \'example\' => array(
            \'key\' => \'example\',
            \'description\' => \'example context\',
            \'rank\' => 2,
        )
    ),

    /* *********************** CONTEXT SETTINGS ************************ */

    /* If your extra needs Context Settings, set their field values here.
     * You can also create or edit them in the Manager (Edit Context -> Context Settings),
     * and export them with exportObjects. If you do that, be sure to set
     * their namespace to the lowercase package name of your extra.
     * The context_key should be the name of an actual context.
     * */

    \'contextSettings\' => array(
        \'example_context_setting1\' => array(
            \'context_key\' => \'example\',
            \'key\' => \'example_context_setting1\',
            \'name\' => \'Example Setting One\',
            \'description\' => \'Description for setting one\',
            \'namespace\' => \'example\',
            \'xtype\' => \'textfield\',
            \'value\' => \'value1\',
            \'area\' => \'example\',
        ),
        \'example_context_setting2\' => array(
            \'context_key\' => \'example\',
            \'key\' => \'example_context_setting2\',
            \'name\' => \'Example Setting Two\',
            \'description\' => \'Description for setting two\',
            \'namespace\' => \'example\',
            \'xtype\' => \'combo-boolean\',
            \'value\' => true,
            \'area\' => \'example\',
        ),
    ),

    /* ************************* CATEGORIES *************************** */
    /* (optional) List of categories. This is only necessary if you
     * need to categories other than the one named for packageName
     * or want to nest categories.
    */

    \'categories\' => array(
        \'Example\' => array(
            \'category\' => \'Example\',
            \'parent\' => \'\',  /* top level category */
        ),
        \'category2\' => array(
            \'category\' => \'Category2\',
            \'parent\' => \'Example\', /* nested under Example */
        )
    ),

    /* *************************** MENUS ****************************** */

    /* If your extra needs Menus, you can create them here
     * or create them in the Manager, and export them with exportObjects.
     * Be sure to set their namespace to the lowercase package name
     * of your extra.
     *
     * Every menu should have exactly one action */

    \'menus\' => array(
        \'Example\' => array(
            \'text\' => \'Example\',
            \'parent\' => \'components\',
            \'description\' => \'ex_menu_desc\',
            \'icon\' => \'\',
            \'menuindex\' => 0,
            \'params\' => \'\',
            \'handler\' => \'\',
            \'permissions\' => \'\',

            \'action\' => array(
                \'id\' => \'\',
                \'namespace\' => \'example\',
                \'controller\' => \'index\',
                \'haslayout\' => true,
                \'lang_topics\' => \'example:default\',
                \'assets\' => \'\',
            ),
        ),
    ),


    /* ************************* ELEMENTS **************************** */

    /* Array containing elements for your extra. \'category\' is required
       for each element, all other fields are optional.
       Property Sets (if any) must come first!

       The standard file names are in this form:
           SnippetName.snippet.php
           PluginName.plugin.php
           ChunkName.chunk.html
           TemplateName.template.html

       If your file names are not standard, add this field:
          \'filename\' => \'actualFileName\',
    */


    \'elements\' => array(

        \'propertySets\' => array( /* all three fields are required */
            \'PropertySet1\' => array(
                \'name\' => \'PropertySet1\',
                \'description\' => \'Description for PropertySet1\',
                \'category\' => \'Example\',
            ),
            \'PropertySet2\' => array(
                \'name\' => \'PropertySet2\',
                \'description\' => \'Description for PropertySet2\',
                \'category\' => \'Example\',
            ),
        ),

        \'snippets\' => array(
            \'Snippet1\' => array(
                \'category\' => \'Example\',
                \'description\' => \'Description for Snippet one\',
                \'static\' => true,
            ),

            \'Snippet2\' => array( /* example with static and property set(s)  */
                \'category\' => \'Category2\',
                \'description\' => \'Description for Snippet two\',
                \'static\' => false,
                \'propertySets\' => array(
                    \'PropertySet1\',
                    \'PropertySet2\'
                ),
            ),

        ),
        \'plugins\' => array(
            \'Plugin1\' => array( /* minimal example */
                \'category\' => \'Example\',
            ),
            \'Plugin2\' => array( /* example with static, events, and property sets */
                \'category\' => \'Example\',
                \'description\' => \'Description for Plugin one\',
                \'static\' => false,
                \'propertySets\' => array( /* all property sets to be connected to element */
                    \'PropertySet1\',
                ),
                \'events\' => array(
                    /* minimal example - no fields */
                    \'OnUserFormSave\' => array(),
                    /* example with fields set */
                    \'OnMyEvent1\' => array(
                        \'priority\' => \'0\', /* priority of the event -- 0 is highest priority */
                        \'group\' => \'plugins\', /* should generally be set to \'plugins\' */
                        \'propertySet\' => \'PropertySet1\', /* property set to be used in this pluginEvent */
                    ),
                    \'OnMyEvent2\' => array(
                        \'priority\' => \'3\',
                        \'group\' => \'plugins\',
                        \'propertySet\' => \'\',
                    ),
                    \'OnDocFormSave\' => array(
                        \'priority\' => \'4\',
                        \'group\' => \'plugins\',
                        \'propertySet\' => \'\',
                    ),


                ),
            ),
        ),
        \'chunks\' => array(
            \'Chunk1\' => array(
                \'category\' => \'Example\',
            ),
            \'Chunk2\' => array(
                \'description\' => \'Description for Chunk two\',
                \'category\' => \'Example\',
                \'static\' => false,
                \'propertySets\' => array(
                    \'PropertySet2\',
                ),
            ),
        ),
        \'templates\' => array(
            \'Template1\' => array(
                \'category\' => \'Example\',
            ),
            \'Template2\' => array(
                \'category\' => \'Example\',
                \'description\' => \'Description for Template two\',
                \'static\' => false,
                \'propertySets\' => array(
                    \'PropertySet2\',
                ),
            ),
        ),
        \'templateVars\' => array(
            \'Tv1\' => array(
                \'category\' => \'Example\',
                \'description\' => \'Description for TV one\',
                \'caption\' => \'TV One\',
                \'propertySets\' => array(
                    \'PropertySet1\',
                    \'PropertySet2\',
                ),
                \'templates\' => array(
                    \'default\' => 1,
                    \'Template1\' => 4,
                    \'Template2\' => 4,


                ),
            ),
            \'Tv2\' => array( /* example with templates, default, and static specified */
                \'category\' => \'Example\',
                \'description\' => \'Description for TV two\',
                \'caption\' => \'TV Two\',
                \'static\' => false,
                \'default_text\' => \'@INHERIT\',
                \'templates\' => array(
                    \'default\' => 3, /* second value is rank -- for ordering TVs when editing resource */
                    \'Template1\' => 4,
                    \'Template2\' => 1,
                ),
            ),
        ),
    ),
    /* (optional) will make all element objects static - \'static\' field above will be ignored */
    \'allStatic\' => false,


    /* ************************* RESOURCES ****************************
     Important: This list only affects Bootstrap. There is another
     list of resources below that controls ExportObjects.
     * ************************************************************** */
    /* Array of Resource pagetitles for your Extra; All other fields optional.
       You can set any resource field here */
    \'resources\' => array(
        \'Resource1\' => array( /* minimal example */
            \'pagetitle\' => \'Resource1\',
            \'alias\' => \'resource1\',
            \'context_key\' => \'example\',
        ),
        \'Resource2\' => array( /* example with other fields */
            \'pagetitle\' => \'Resource2\',
            \'alias\' => \'resource2\',
            \'context_key\' => \'example\',
            \'parent\' => \'Resource1\',
            \'template\' => \'Template2\',
            \'richtext\' => false,
            \'published\' => true,
            \'tvValues\' => array(
                \'Tv1\' => \'SomeValue\',
                \'Tv2\' => \'SomeOtherValue\',
            ),
        )
    ),


    /* Array of languages for which you will have language files,
     *  and comma-separated list of topics
     *  (\'.inc.php\' will be added as a suffix). */
    \'languages\' => array(
        \'en\' => array(
            \'default\',
            \'properties\',
            \'forms\',
        ),
    ),
    /* ********************************************* */
    /* Define optional directories to create under assets.
     * Add your own as needed.
     * Set to true to create directory.
     * Set to hasAssets = false to skip.
     * Empty js and/or css files will be created.
     */
    \'hasAssets\' => true,
    \'minifyJS\' => true,
    /* minify any JS files */
    \'assetsDirs\' => array(
        \'css\' => true,
        /* If true, a default (empty) CSS file will be created */
        \'js\' => true,
        /* If true, a default (empty) JS file will be created */
        \'images\' => true,
        \'audio\' => true,
        \'video\' => true,
        \'themes\' => true,
    ),


    /* ********************************************* */
    /* Define basic directories and files to be created in project*/

    \'docs\' => array(
        \'readme.txt\',
        \'license.txt\',
        \'changelog.txt\',
        \'tutorial.html\'
    ),

    /* (optional) Description file for GitHub project home page */
    \'readme.md\' => true,
    /* assume every package has a core directory */
    \'hasCore\' => true,

    /* ********************************************* */
    /* (optional) Array of extra script resolver(s) to be run
     * during install. Note that resolvers to connect plugins to events,
     * property sets to elements, resources to templates, and TVs to
     * templates will be created automatically -- *don\'t* list those here!
     *
     * \'default\' creates a default resolver named after the package.
     * (other resolvers may be created above for TVs and plugins).
     * Suffix \'resolver.php\' will be added automatically */
    \'resolvers\' => array(
        \'default\',
        \'addUsers\'
    ),

    /* (optional) Validators can abort the install after checking
     * conditions. Array of validator names (no
     * prefix of suffix) or \'\' \'default\' creates a default resolver
     *  named after the package suffix \'validator.php\' will be added */

    \'validators\' => array(
        \'default\',
        \'hasGdLib\'
    ),

    /* (optional) install.options is needed if you will interact
     * with user during the install.
     * See the user.input.php file for more information.
     * Set this to \'install.options\' or \'\'
     * The file will be created as _build/install.options/user.input.php
     * Don\'t change the filename or directory name. */
    \'install.options\' => \'install.options\',


    /* Suffixes to use for resource and element code files (not implemented)  */
    \'suffixes\' => array(
        \'modPlugin\' => \'.php\',
        \'modSnippet\' => \'.php\',
        \'modChunk\' => \'.html\',
        \'modTemplate\' => \'.html\',
        \'modResource\' => \'.html\',
    ),


    /* ********************************************* */
    /* (optional) Only necessary if you will have class files.
     *
     * Array of class files to be created.
     *
     * Format is:
     *
     * \'ClassName\' => \'directory:filename\',
     *
     * or
     *
     *  \'ClassName\' => \'filename\',
     *
     * (\'.class.php\' will be appended automatically)
     *
     *  Class file will be created as:
     * yourcomponent/core/components/yourcomponent/model/[directory/]{filename}.class.php
     *
     * Set to array() if there are no classes. */
    \'classes\' => array(
        \'Example\' => \'example:example\',
    ),

    /* *******************************************
     * These settings control exportObjects.php  *
     ******************************************* */
    /* ExportObjects will update existing files. If you set dryRun
       to \'1\', ExportObjects will report what it would have done
       without changing anything. Note: On some platforms,
       dryRun is *very* slow  */

    \'dryRun\' => \'0\',

    /* Array of elements to export. All elements set below will be handled.
     *
     * To export resources, be sure to list pagetitles and/or IDs of parents
     * of desired resources
    */
    \'process\' => array(
        \'contexts\',
        \'snippets\',
        \'plugins\',
        \'templateVars\',
        \'templates\',
        \'chunks\',
        \'resources\',
        \'propertySets\',
        \'systemSettings\',
        \'contextSettings\',
        \'systemEvents\',
        \'menus\'
    ),
    /*  Array  of resources to process. You can specify specific resources
        or parent (container) resources, or both.

        They can be specified by pagetitle or ID, but you must use the same method
        for all settings and specify it here. Important: use IDs if you have
        duplicate pagetitles */
    \'getResourcesById\' => false,

    \'exportResources\' => array(
        \'Resource1\',
        \'Resource2\',
    ),
    /* Array of resource parent IDs to get children of. */
    \'parents\' => array(),
    /* Also export the listed parent resources
      (set to false to include just the children) */
    \'includeParents\' => false,


    /* ******************** LEXICON HELPER SETTINGS ***************** */
    /* These settings are used by LexiconHelper */
    \'rewriteCodeFiles\' => false,
    /*# remove ~~descriptions */
    \'rewriteLexiconFiles\' => true,
    /* automatically add missing strings to lexicon files */
    /* ******************************************* */

     /* Array of aliases used in code for the properties array.
     * Used by the checkproperties utility to check properties in code against
     * the properties in your properties transport files.
     * if you use something else, add it here (OK to remove ones you never use.
     * Search also checks with \'$this->\' prefix -- no need to add it here. */
    \'scriptPropertiesAliases\' => array(
        \'props\',
        \'sp\',
        \'config\',
\'scriptProperties\'
        ),
);

return $components;
', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '56', '0', '0', 'genericresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
 * Resolver for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 * @package [[+packageNameLower]]
 * @subpackage build
 */

/* @var $object xPDOObject */
/* @var $modx modX */

/* @var array $options */

if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:
            /* [[+code]] */
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '57', '0', '0', 'genericvalidator.php', 'Chunk', '0', '15', '0', '<?php
/**
 * Validator for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 * @package [[+packageNameLower]]
 * @subpackage build
 */

/* @var $object xPDOObject */
/* @var $modx modX */
/* @var array $options */

if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
            /* return false if conditions are not met */

            /* [[+code]] */
            break;
        case xPDOTransport::ACTION_UPGRADE:
            /* return false if conditions are not met */
            /* [[+code]] */
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '58', '0', '0', 'js.tpl', 'Chunk', '0', '15', '0', '/** 
 * JS file for [[+packageName]] extra
 * 
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 * @package [[+packageNameLower]]
 */', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '59', '0', '0', 'license.tpl', 'Chunk', '0', '15', '0', ' * [[+packageName]] is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * [[+packageName]] is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * [[+packageName]]; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '60', '0', '0', 'license.txt.tpl', 'Chunk', '0', '15', '0', 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The \"Program\", below,
refers to any such program or work, and a \"work based on the Program\"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term \"modification\".)  Each licensee is addressed as \"you\".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and \"any
later version\", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '61', '0', '0', 'modchunk.tpl', 'Chunk', '0', '15', '0', '<p>Chunk content goes here</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '62', '0', '0', 'modresource.tpl', 'Chunk', '0', '15', '0', '<p>Content goes here</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '63', '0', '0', 'modtemplate.tpl', 'Chunk', '0', '15', '0', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"/>
        <title>[[++site_name]] - [[*pagetitle]]</title>
        <base href=\"[[++site_url]]\"/>
    </head>
    <body>
        [[*content]]
    </body>
</html>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '64', '0', '0', 'phpfile.php', 'Chunk', '0', '15', '0', '<?php
/**
 * [[+elementName]] [[+elementType]] for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 *
 * @package [[+packageNameLower]]
 */

/**
 * Description
 * -----------
 * [[+description]]
 *
 * Variables
 * ---------
 * @var $modx modX
 * @var $scriptProperties array
 *
 * @package [[+packageNameLower]]
 **/

', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '65', '0', '0', 'pluginresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
* Resolver to connect plugins to system events for [[+packageName]] extra
*
* Copyright [[+copyright]] by [[+author]] [[+email]]
* Created on [[+createdon]]
*
[[+license]]
* @package [[+packageNameLower]]
* @subpackage build
*/
/* @var $object xPDOObject */
/* @var $pluginObj modPlugin */
/* @var $mpe modPluginEvent */
/* @var xPDOObject $object */
/* @var array $options */
/* @var $modx modX */
/* @var $pluginObj modPlugin */
/* @var $pluginEvent modPluginEvent */
/* @var $newEvents array */

if (!function_exists(\'checkFields\')) {
    function checkFields($required, $objectFields) {

        global $modx;
        $fields = explode(\',\', $required);
        foreach ($fields as $field) {
            if (!isset($objectFields[$field])) {
                $modx->log(MODX::LOG_LEVEL_ERROR, \'[Plugin Resolver] Missing field: \' . $field);
                return false;
            }
        }
        return true;
    }
}


$newEvents = \'[[+newEvents]]\';


if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:

            foreach($newEvents as $k => $fields) {

                $event = $modx->getObject(\'modEvent\', array(\'name\' => $fields[\'name\']));
                if (!$event) {
                    $event = $modx->newObject(\'modEvent\');
                    if ($event) {
                        $event->fromArray($fields, \"\", true, true);
                        $event->save();
                    }
                }
            }

            $intersects = \'[[+intersects]]\';

            if (is_array($intersects)) {
                foreach ($intersects as $k => $fields) {
                    /* make sure we have all fields */
                    if (!checkFields(\'pluginid,event,priority,propertyset\', $fields)) {
                        continue;
                    }
                    $event = $modx->getObject(\'modEvent\', array(\'name\' => $fields[\'event\']));

                    $plugin = $modx->getObject(\'modPlugin\', array(\'name\' => $fields[\'pluginid\']));
                    $propertySetObj = null;
                    if (!empty($fields[\'propertyset\'])) {
                        $propertySetObj = $modx->getObject(\'modPropertySet\',
                            array(\'name\' => $fields[\'propertyset\']));
                    }
                    if (!$plugin || !$event) {
                        $modx->log(xPDO::LOG_LEVEL_ERROR, \'Could not find Plugin and/or Event \' .
                            $fields[\'plugin\'] . \' - \' . $fields[\'event\']);
                        continue;
                    }
                    $pluginEvent = $modx->getObject(\'modPluginEvent\', array(\'pluginid\'=>$plugin->get(\'id\'),\'event\' => $fields[\'event\']) );
                    
                    if (!$pluginEvent) {
                        $pluginEvent = $modx->newObject(\'modPluginEvent\');
                    }
                    if ($pluginEvent) {
                        $pluginEvent->set(\'event\', $fields[\'event\']);
                        $pluginEvent->set(\'pluginid\', (integer) $plugin->get(\'id\'));
                        $pluginEvent->set(\'priority\', (integer) $fields[\'priority\']);
                        if ($propertySetObj) {
                            $pluginEvent->set(\'propertyset\', (integer) $propertySetObj->get(\'id\'));
                        } else {
                            $pluginEvent->set(\'propertyset\', 0);
                        }

                    }
                    if (! $pluginEvent->save()) {
                        $modx->log(xPDO::LOG_LEVEL_ERROR, \'Unknown error saving pluginEvent for \' .
                            $fields[\'plugin\'] . \' - \' . $fields[\'event\']);
                    }
                }
            }
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            foreach($newEvents as $k => $fields) {
                $event = $modx->getObject(\'modEvent\', array(\'name\' => $fields[\'name\']));
                if ($event) {
                    $event->remove();
                }
            }
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '66', '0', '0', 'propertiesfile.php', 'Chunk', '0', '15', '0', '<?php
/**
 * Properties file for [[+element]] [[+elementType]]
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
 * @package [[+packageNameLower]]
 * @subpackage build
 */


', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '67', '0', '0', 'propertysetresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
* Resolver to connect Property Sets to Elements for [[+packageName]] extra
*
* Copyright [[+copyright]] by [[+author]] [[+email]]
* Created on [[+createdon]]
*
[[+license]]
* @package [[+packageNameLower]]
* @subpackage build
*/

/* @var $object xPDOObject */
/* @var $propertySetObj modPropertySet */
/* @var $elementObj modElement */
/* @var $elementPropertySet modElementPropertySet */

/* @var array $options */
if (!function_exists(\'getNameAlias\')) {
    function getNameAlias($elementType)
    {
        switch ($elementType) {
            case \'modTemplate\':
                $nameAlias = \'templatename\';
                break;
            case \'modCategory\':
                $nameAlias = \'category\';
                break;
            case \'modResource\':
                $nameAlias = \'pagetitle\';
                break;
            default:
                $nameAlias = \'name\';
                break;
        }
        return $nameAlias;

    }
}

if (!function_exists(\'checkFields\')) {
    function checkFields($required, $objectFields) {
        global $modx;
        $fields = explode(\',\', $required);
        foreach ($fields as $field) {
            if (!isset($objectFields[$field])) {
                $modx->log(MODX::LOG_LEVEL_ERROR, \'[PropertySet Resolver] Missing field: \' . $field);
                return false;
            }
        }
        return true;
    }
}
if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:
        $intersects = \'[[+intersects]]\';

        if (is_array($intersects)) {
            foreach ($intersects as $k => $fields) {
                /* make sure we have all fields */
                if (!checkFields(\'element,element_class,property_set\', $fields)) {
                    continue;
                }
                $elementObj = $modx->getObject($fields[\'element_class\'],
                    array(getNameAlias($fields[\'element_class\']) => $fields[\'element\']));

                $propertySetObj = $modx->getObject(\'modPropertySet\', array(\'name\' => $fields[\'property_set\']));

                if (!$elementObj || !$propertySetObj) {
                    $modx->log(xPDO::LOG_LEVEL_ERROR, \'Could not find Element and/or Property Set \' .
                        $fields[\'element\'] . \' - \' . $fields[\'property_set\']);
                    continue;
                }
                $fields[\'element\'] = $elementObj->get(\'id\');
                $fields[\'property_set\'] = $propertySetObj->get(\'id\');

                $tvt = $modx->getObject(\'modElementPropertySet\', $fields);
                if (!$tvt) {
                    $tvt = $modx->newObject(\'modElementPropertySet\');
                }
                if ($tvt) {
                    foreach($fields as $key => $value) {
                        $tvt->set($key, $value);
                    }
                    if (!$tvt->save()) {
                        $modx->log(xPDO::LOG_LEVEL_ERROR, \'Unknown error creating elementPropertySet intersect for \' .
                            $fields[\'element\'] . \' - \' . $fields[\'property_set\']);
                    }

                } else {
                    $modx->log(xPDO::LOG_LEVEL_ERROR, \'Unknown error creating elementPropertySet intersect for \' .
                        $fields[\'element\'] . \' - \' . $fields[\'property_set\']);
                }
            }
        }
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '68', '0', '0', 'readme.md.tpl', 'Chunk', '0', '15', '0', '[[+packageName]] Extra for MODx Revolution
=======================================


**Author:** [[+author]] [[+email]] [[[+authorSiteName]]]([[+authorUrl]])

Documentation is available at [[[+authorSiteName]]]([[+packageUrl]])

[[+packageDescription]]
', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '69', '0', '0', 'readme.txt.tpl', 'Chunk', '0', '15', '0', '
[[+packageName]]


Author: [[+author]] [[+email]]
Copyright [[+copyright]]

Official Documentation: [[+packageUrl]]

Bugs and Feature Requests: https://github.com:[[+gitHubUsername]]/[[+gitHubRepository]]

Questions: http://forums.modx.com

Created by MyComponent
', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '70', '0', '0', 'removenewevents.php', 'Chunk', '0', '15', '0', '<?php
            /* Remove new System Events created during install */

            $events = \'[[+newEvents]]\';
            $events = empty($events)? array() : explode(\',\', $events);
            /* @var $e modEvent */
            foreach ($events as $event) {
                $e = $modx->getObject(\'modEvent\', array(\'name\' => $event));
                if ($e) {
                    $e->remove();
                }
            }', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '71', '0', '0', 'resourceresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
* Resource resolver  for [[+packageName]] extra.
* Sets template, parent, and (optionally) TV values
*
* Copyright [[+copyright]] by [[+author]] [[+email]]
* Created on [[+createdon]]
*
[[+license]]
* @package [[+packageNameLower]]
* @subpackage build
*/

/* @var $object xPDOObject */
/* @var $modx modX */
/* @var $parentObj modResource */
/* @var $templateObj modTemplate */

/* @var array $options */

if (!function_exists(\'checkFields\')) {
    function checkFields($required, $objectFields) {
        global $modx;
        $fields = explode(\',\', $required);
        foreach ($fields as $field) {
            if (! isset($objectFields[$field])) {
                $modx->log(MODX::LOG_LEVEL_ERROR, \'[Resource Resolver] Missing field: \' . $field);
                return false;
            }
        }
        return true;
    }
}
if($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:

            $intersects = \'[[+intersects]]\';

            if (is_array($intersects)) {
                foreach ($intersects as $k => $fields) {
                    /* make sure we have all fields */
                    if (! checkFields(\'pagetitle,parent,template\', $fields)) {
                        continue;
                    }
                    $resource = $modx->getObject(\'modResource\', array(\'pagetitle\' => $fields[\'pagetitle\']));
                    if (! $resource) {
                        continue;
                    }
                    if ($fields[\'template\'] == \'default\') {
                        $resource->set(\'template\', $modx->getOption(\'default_template\'));
                    } else {
                        $templateObj = $modx->getObject(\'modTemplate\', array(\'templatename\' => $fields[\'template\']));
                        if ($templateObj) {
                            $resource->set(\'template\', $templateObj->get(\'id\'));
                        } else {
                            $modx->log(MODX::LOG_LEVEL_ERROR, \'[Resource Resolver] Could not find template: \' . $fields[\'template\']);
                        }
                    }
                    if (!empty($fields[\'parent\'])) {
                        if ($fields[\'parent\'] != \'default\') {
                            $parentObj = $modx->getObject(\'modResource\', array(\'pagetitle\' => $fields[\'parent\']));
                            if ($parentObj) {
                                $resource->set(\'parent\', $parentObj->get(\'id\'));
                            } else {
                                $modx->log(MODX::LOG_LEVEL_ERROR, \'[Resource Resolver] Could not find parent: \' . $fields[\'parent\']);
                            }
                        }
                    }

                    if (isset($fields[\'tvValues\'])) {
                        foreach($fields[\'tvValues\'] as $tvName => $value) {
                            $resource->setTVValue($tvName, $value);
                        }

                    }
                    $resource->save();
                }

            }
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '72', '0', '0', 'transportfile.php', 'Chunk', '0', '15', '0', '<?php
/**
 * [[+elementType]] transport file for [[+packageName]] extra
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
 * @package [[+packageNameLower]]
 * @subpackage build
 */

if (! function_exists(\'stripPhpTags\')) {
    function stripPhpTags($filename) {
        $o = file_get_contents($filename);
        $o = str_replace(\'<\' . \'?\' . \'php\', \'\', $o);
        $o = str_replace(\'?>\', \'\', $o);
        $o = trim($o);
        return $o;
    }
}
/* @var $modx modX */
/* @var $sources array */
', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '73', '0', '0', 'tutorial.html.tpl', 'Chunk', '0', '15', '0', '<p>[[+packageDescription]]</p>

<p>(Jump to <a href=\"[[~[[*id]]]]#propertiesTable\">Properties Table</a>.)</p>

<h3>Installing [[+packageName]]</h3>

<p>
Go to System | Package Management on the main menu in the MODX Manager and click on the &quot;Download Extras&quot; button. That will take you to the
Revolution Repository (AKA Web Transport Facility). Put [[+packageName]] in the search box and press Enter. Click on the &quot;Download&quot; button, and once the package is downloaded,
 click on the &quot;Back to Package Manager&quot; button. That should bring you back to your Package Management grid. Click on the
&quot;Install&quot; button next to [[+packageName]] in the grid. The [[+packageName]] package should now be installed.</p>

<h3>Usage</h3>




<a name=\"propertiesTable\"></a>

<h3>[[+packageName]] Properties</h3>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '74', '0', '0', 'tvresolver.php', 'Chunk', '0', '15', '0', '<?php
/**
* Resolver to connect TVs to templates for [[+packageName]] extra
*
* Copyright [[+copyright]] by [[+author]] [[+email]]
* Created on [[+createdon]]
*
[[+license]]
* @package [[+packageNameLower]]
* @subpackage build
*/

/* @var $object xPDOObject */
/* @var $modx modX */
/* @var $parentObj modResource */
/* @var $templateObj modTemplate */

/* @var array $options */

if (!function_exists(\'checkFields\')) {
    function checkFields($required, $objectFields) {
        global $modx;
        $fields = explode(\',\', $required);
        foreach ($fields as $field) {
            if (!isset($objectFields[$field])) {
                $modx->log(MODX::LOG_LEVEL_ERROR, \'[TV Resolver] Missing field: \' . $field);
                return false;
            }
        }
        return true;
    }
}

if ($object->xpdo) {
    $modx =& $object->xpdo;
    switch ($options[xPDOTransport::PACKAGE_ACTION]) {
        case xPDOTransport::ACTION_INSTALL:
        case xPDOTransport::ACTION_UPGRADE:

            $intersects = \'[[+intersects]]\';

            if (is_array($intersects)) {
                foreach ($intersects as $k => $fields) {
                    /* make sure we have all fields */
                    if (!checkFields(\'tmplvarid,templateid\', $fields)) {
                        continue;
                    }
                    $tv = $modx->getObject(\'modTemplateVar\', array(\'name\' => $fields[\'tmplvarid\']));
                    if ($fields[\'templateid\'] == \'default\') {
                        $template = $modx->getObject(\'modTemplate\', $modx->getOption(\'default_template\'));
                    } else {
                        $template = $modx->getObject(\'modTemplate\', array(\'templatename\' => $fields[\'templateid\']));
                    }
                    if (!$tv || !$template) {
                        $modx->log(xPDO::LOG_LEVEL_ERROR, \'Could not find Template and/or TV \' .
                            $fields[\'templateid\'] . \' - \' . $fields[\'tmplvarid\']);
                        continue;
                    }
                    $tvt = $modx->getObject(\'modTemplateVarTemplate\', array(\'templateid\' => $template->get(\'id\'), \'tmplvarid\' => $tv->get(\'id\')));
                    if (! $tvt) {
                        $tvt = $modx->newObject(\'modTemplateVarTemplate\');
                    }
                    if ($tvt) {
                        $tvt->set(\'tmplvarid\', $tv->get(\'id\'));
                        $tvt->set(\'templateid\', $template->get(\'id\'));
                        if (isset($fields[\'rank\'])) {
                            $tvt->set(\'rank\', $fields[\'rank\']);
                        } else {
                            $tvt->set(\'rank\', 0);
                        }
                        if (!$tvt->save()) {
                            $modx->log(xPDO::LOG_LEVEL_ERROR, \'Unknown error creating templateVarTemplate for \' .
                                $fields[\'templateid\'] . \' - \' . $fields[\'tmplvarid\']);
                        }
                    } else {
                        $modx->log(xPDO::LOG_LEVEL_ERROR, \'Unknown error creating templateVarTemplate for \' .
                            $fields[\'templateid\'] . \' - \' . $fields[\'tmplvarid\']);
                    }


                }

            }
            break;

        case xPDOTransport::ACTION_UNINSTALL:
            break;
    }
}

return true;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '75', '0', '0', 'user.input.php', 'Chunk', '0', '15', '0', '<?php

/**
 * Script to interact with user during [[+packageName]] package install
 *
 * Copyright [[+copyright]] by [[+author]] [[+email]]
 * Created on [[+createdon]]
 *
[[+license]]
 *
 * @package [[+packageNameLower]]
 */

/**
 * Description: Script to interact with user during [[+packageName]] package install
 * @package [[+packageNameLower]]
 * @subpackage build
 */

/* The return value from this script should be an HTML form (minus the
 * <form> tags and submit button) in a single string.
 *
 * The form will be shown to the user during install
 *
 * This example presents an HTML form to the user with two input fields
 * (you can have as many as you like).
 *
 * The user\'s entries in the form\'s input field(s) will be available
 * in any php resolvers with $modx->getOption(\'field_name\', $options, \'default_value\').
 *
 * You can use the value(s) to set system settings, snippet properties,
 * chunk content, etc. based on the user\'s preferences.
 *
 * One common use is to use a checkbox and ask the
 * user if they would like to install a resource for your
 * component (usually used only on install, not upgrade).
 */

/* This is an example. Modify it to meet your needs.
 * The user\'s input would be available in a resolver like this:
 *
 * $changeSiteName = (! empty($modx->getOption(\'change_sitename\', $options, \'\'));
 * $siteName = $modx->getOption(\'sitename\', $options, \'\').
 *
 * */

$output = \'<p>&nbsp;</p>
<p>Setting this option will do nothing because there is no resolver that acts on it.</p>
<label for=\"sitename\">The value here could be used to set the site_name system setting on install.</label>
<p>&nbsp;</p>
<input type=\"text\" name=\"sitename\" id=\"sitename\" value=\"\" align=\"left\" size=\"40\" maxlength=\"60\" />
<p>&nbsp;</p>
<input type=\"checkbox\" name=\"change_sitename\" id=\"change_sitename\" checked=\"checked\" value=\"1\" align=\"left\" />&nbsp;&nbsp;
<label for=\"change_sitename\">Set site name on install</label>
<p>&nbsp;</p>\';


return $output;', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '76', '0', '0', 'mycomponentform.tpl', 'Chunk', '0', '15', '0', '<script type=\"text/javascript\">
    function getRadioValue(formName, groupName) {
        var radioGroup = document[formName][groupName];
        for (var i=0; i<radioGroup.length; i++)  {
           if (radioGroup[i].checked)  {
           return radioGroup[i].value;
           }
        }
        return null;
    }

    function confirmSubmit() {
        val = getRadioValue(\'mc_form\', \'doit\');
        if (val == \'removeobjects\') {
            return confirm(\"[[+confirm_remove_objects]]\");
        } else if (val == \'removeobjectsandfiles\') {
            return confirm(\"[[+confirm_remove_objects_and_files]]\");
        } else {
            return true;
        }

    }

</script>



    <h3>MyComponent Actions</h3>



    <form id=\"mc_form\" name=\"mc_form\" method=\"post\" action=\"[[~[[*id]]]]\">
        <p>&nbsp;<b>[[+message]]</b></p>
        <label for=\"bootstrap\">
        Current Project:
                    <input type=\"text\" name=\"currentproject\" value=\"[[+current_project]]\" id=\"currentproject\"/>

                </label><input type=\"submit\" name=\"newproject\" value=\"New Project\">
                <br/><br />

                <label for=\"selectproject\">

                   <select name=\"selectproject\">
                      [[+projects]]
                   </select></label> <input type=\"submit\" name=\"switchproject\" value=\"Switch Project\" id=\"selectproject\">
                   <br />
                   <br />

        <label for=\"bootstrap\">
            <input type=\"radio\" name=\"doit\" value=\"bootstrap\" id=\"bootstrap\"/>
            Bootstrap
        </label><br/><br />
        <label for=\"exportobjects\"> <input type=\"radio\" name=\"doit\" value=\"exportobjects\" id=\"exportobjects\"/>
            ExportObjects</label><br/><br/>
        <label for=\"importobjects\"> <input type=\"radio\" name=\"doit\" value=\"importobjects\" id=\"importobjects\"/>
                        ImportObjects</label><br/><br/>
        <label for=\"lexiconhelper\"> <input type=\"radio\" name=\"doit\" value=\"lexiconhelper\" id=\"lexiconhelper\"/>
            LexiconHelper</label><br/><br/>
        <label for=\"checkproperties\"> <input type=\"radio\" name=\"doit\" value=\"checkproperties\" id=\"checkproperties\"/>
            CheckProperties</label><br/><br/>
        <label for=\"build\"> <input type=\"radio\" name=\"doit\" value=\"build\" id=\"build\"/>
            Build</label><br/><br/><br/><br/>
        <label for=\"removeobjects\"> <input type=\"radio\" name=\"doit\" value=\"removeobjects\" id=\"removeobjects\"/>
            RemoveObjects</label><br/><br/>
            <label for=\"removeobjectsandfiles\"> <input type=\"radio\" name=\"doit\" value=\"removeobjectsandfiles\" id=\"removeobjectsandfiles\"/>
                        RemoveObjects and Files</label><br/><br/><br/>

        <input type=\"submit\" value=\"Submit\" onclick=\"return confirmSubmit();\">
    </form>
<br /><br/>


', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '82', '0', '0', 'rrRenderImageTVColumn', '', '0', '27', '0', '[[rrRenderImageTVColumn? &docid=`[[+Source_id]]` &tvname=`image`]]
<img src=\"[[+image:phpthumbof=`w=150`]]\" />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '83', '0', '0', 'visitenkarte', '', '0', '28', '0', '[[!bloX?
&configs=`visitenkarten` 
&task=`visitenkarte` 
&classname=`vkVisitenkarte` 
&debug=``
&component=`visitenkarten`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '84', '0', '0', 'tplVisitenkartenAktionenColumn', '', '0', '28', '0', 'aktiv: <a href=\"#\"><img title=\"aktiv\" alt=\"aktiv\" src=\"/assets/components/migx/style/images/[[+active:is=`1`:then=`tick.png`:else=`cross.png`]]\" class=\"controlBtn active this.handleColumnSwitch active\" /></a><br/>
<ul class=\"actions\">
<li>
<a class=\"controlBtn update this.update\" href=\"#\">Bearbeiten</a>
</li>

</ul>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '85', '0', '0', 'renderSwitchPublishedColumn', '', '0', '0', '0', '
[[+published:is=`1`:then=`
<a href=\"#\"><img title=\"unpublish\" alt=\"unpublish\" src=\"/assets/components/migx/style/images/tick.png\" class=\"controlBtn unpublish this.handleColumnSwitch published\"></a>
`:else=`
<a href=\"#\"><img title=\"unpublish\" alt=\"publish\" src=\"/assets/components/migx/style/images/cross.png\" class=\"controlBtn publish this.handleColumnSwitch published\"></a>
`]]

', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '86', '0', '0', 'productvalue', '', '0', '0', '0', '<li>[[+title]]: <input name=\"amount[[+MIGX_id]]\" type=\"text\" id=\"[[+title]]\" value=\"[[!+fi.amount[[+MIGX_id]]]]\" [[+fi.error.amount[[+MIGX_id]]:isnot=``:then=`class=\"fielderror\"`:else=`class=\"field\"`]]>[[+fi.error.amount[[+MIGX_id]]]]</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '87', '0', '0', 'ProduktEmailChunk', '', '0', '0', '0', 'Ein Test
[[getImageList? &tvname=`images` &tpl=`mail_product`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '88', '0', '0', 'mail_product', '', '0', '0', '0', '[[+amount[[+MIGX_id]]:notempty=`
<li>[[+title]]:[[+amount[[+MIGX_id]]]]</li>
`]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '89', '0', '0', 'productOrderForm', '', '0', '0', '0', '[[!FormIt?hooks=`email`&emailFrom=`b.perner@gmx.de`&emailTpl=`ProduktEmailChunk`&emailTo=`b.perner@gmx.de`&emailSubject=`ein Test`]]

Hallo, ein Test, Tralalaxxx
 
speichertest 
asdfkajsdkfjas fas df as df as df asdfasdfasdfasdfasd f asdf asdf asdf asdf asd f asdf


<form method=\"post\" action=\"[[~[[*id]]]]\">
<ul>
[[!getImageList? &tvname=`images` &tpl=`productvalue`]]
</ul>
<input type=\"submit\" />
</form>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '90', '0', '0', 'migxFormReportTpl', '', '0', '38', '0', '[[!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`buildmailreport`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '91', '0', '0', 'migxFormbuilder', '', '0', '38', '0', '[[[[+form_id:!empty=`!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`buildform`
&form_id=`[[+form_id]]`
&debug_formit=`[[+debug_formit:default=``]]`
`]]
]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '92', '0', '0', 'migxFormAutoRespondTpl', '', '0', '38', '0', '[[!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`buildautorespondreport`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '93', '0', '0', 'migxFormselector', '', '0', '38', '0', 'select Form==||[[migxLoopCollection? &packageName=`migxformbuilder` &classname=`mfbForm` &tpl=`@CODE:[[+name]]([[+id]])==[[+id]]` &outputSeparator=`||`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '94', '0', '0', 'migxFormThankyouselector', '', '0', '38', '0', 'select Thank You Page==||[[migxLoopCollection? &classname=`modResource` &tpl=`@CODE:[[+pagetitle]]([[+id]])==[[+id]]` &outputSeparator=`||` &where=`{\"parent\":\"[[++migxformbuilder.thankyou_parent]]\"}`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '95', '0', '0', 'test1_viewTpl', '', '0', '0', '0', 'Name: [[+name]]<br />
Label: [[+label]]<br />
Value: [[+value]]
<br /><br />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '96', '0', '0', 'migxFormbuilderMultipage', '', '0', '38', '0', '[[[[+form_ids:!empty=`!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`buildmultipageform`
&form_ids=`[[+form_ids]]`
&debug_formit=`[[+debug_formit:default=``]]`
`]]
]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '97', '0', '0', 'migxFormPreview', '', '0', '38', '0', '[[[[+form_ids:!empty=`!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`buildpreview`
&form_ids=`[[+form_ids]]`
&debug_formit=`[[+debug_formit]]`
`]]
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '98', '2', '0', 'miniCalendarDay', '', '0', '39', '0', '<li class=\"[[+today:default=``]] [[+hasevent:eq=`1`:then=`hasevent`]]\">
	[[+hasevent:notempty=`<a href=\"[[+link]]\" title=\"[[+title]]\">[[+day]]</a>`:default=`<span>[[+day]]</span>`]]
</li>', '0', NULL, '1', 'assets/elements/chunks/events migx/minicalendarday.tpl.html');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '99', '2', '0', 'miniCalendarHeader', '', '0', '39', '0', '<div id=\"eventscalendar\">
	[[+navigation]]
	<div class=\"calendar-body\">
		<ul class=\"weekdays-list\">
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Mo</li>
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Di</li>
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Mi</li>
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Do</li>
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Fr</li>
		  <li class=\"w-14pc flt-l txt-cnt ft-bld\">Sa</li>
		  <li class=\"w-14pc flt-l is_sunday txt-cnt ft-bld\">So</li>
		</ul>
		<ul class=\"days-list\">[[+items]]</ul>
	</div>
</div>', '0', NULL, '1', 'assets/elements/chunks/events migx/minicalendarheader.tpl.html');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '100', '2', '0', 'miniCalendarNavigation', '', '0', '39', '0', '<div class=\"navigation\">
  <ul>
    <li class=\"previous\"><a href=\"[[~[[++eventcalendar.ajax.id]]? &year=`[[+lastYear]]` &month=`[[+lastMonth]]`]]\"><img src=\"assets/css/images/icons/back.png\" alt=\"zurück\" /></a></li>
    <li class=\"month\"><span>[[+currentMonth]]</span></li>
    <li class=\"next\"><a href=\"[[~[[++eventcalendar.ajax.id]]? &year=`[[+nextYear]]` &month=`[[+nextMonth]]`]]\"><img src=\"assets/css/images/icons/next.png\" alt=\"weiter\" /></a></li>
  </ul>
</div>', '0', NULL, '1', 'assets/elements/chunks/events migx/minicalendarnavigation.tpl.html');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '101', '0', '0', 'migx_resource_options', '', '0', '0', '0', '[[migxLoopCollection? 
    &classname=`modResource`
    &selectfields=`id,pagetitle`
    &where=`{\"parent\":\"3\"}`
    &toJsonPlaceholder=`json` 
  ]]
[[+json]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '102', '0', '0', 'mb_init', '', '0', '41', '0', '[[!mbGetRelations? 
&packageName=`migxbanner` 
&classname=`mbResourceRelation`
&element=``
&inheritFromParents=`1`
&toPlaceholder=`banner_ids`
&idQueryParam=`vk_resid`
]]

[[!migxBanner? 
&where = `[{\"id:IN\":[ [[+banner_ids]] ],\"active\":\"1\",\"pub_date:<\":\"[[!now]]\"},{\"unpub_date:>\":\"[[!now]]\",\"OR:never_expire:=\":\"1\"}]`
&packageName=`migxbanner` 
&classname=`mbBanner`
&toJsonPlaceholders=`banners`
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '103', '0', '0', 'mb_position', '', '0', '41', '0', '<div id=\"mbposition_[[+pos_id]]\">
[[!getImageList?  
  &tpl=`@FIELD:tpl` 
  &value=`[[+banners_[[+pos_id]]]]`
]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '104', '0', '0', 'migxbanner1Tpl_html', '', '0', '41', '0', '[[+url:is=`--`:then=``:else=`<a href=\"[[+url]]\">`]]
[[+description]]
[[+url:is=`--`:then=``:else=`</a>`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '105', '0', '0', 'migxbanner1Tpl_image', '', '0', '41', '0', '<a href=\"[[+url]]\"><img src=\"assets/images/migxbanner/[[+image]]\" /></a>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '106', '0', '0', 'PositionCheckbox', '', '0', '41', '0', '[[migxLoopCollection? &packageName=`migxbanner` &classname=`mbPosition` &tpl=`@CODE:[[+name]]([[+id]])==[[+id]]` &outputSeparator=`||`]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '107', '0', '0', 'getAttributeOptions', '', '0', '0', '0', '[[getImageList? 
&tvname=`migx_attributes_builder`
&docid=`90`
&toJsonPlaceholder=`json`
]]
[[+json]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '108', '0', '0', 'renderImageColumn', '', '0', '42', '0', '
<img src=\"[[getmigxcartfilepath:phpthumbof=`w=150`? &filename=`[[+filename]]`]]\"/>  ', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '109', '1', '0', 'mod_contacts', '', '0', '45', '0', '<table cellpadding=\"5\">
    <tr><td>Name:</td><td>[[+fullname]]</td></tr>
    <tr><td>Address:</td><td>[[+address]]</td></tr>
    <tr><td>E-mail:</td><td>[[+email]]</td></tr>
    <tr><td>Phone:</td><td>[[+phone]]</td></tr>
    <tr><td>Delivery method:</td><td>[[+delivery]]</td></tr>
    <tr><td>Payment method:</td><td>[[+payment]]</td></tr>
</table>', '0', NULL, '1', 'core/components/shopkeeper/elements/chunks/[[++manager_language]]/mod_contacts.tpl');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '110', '1', '0', 'mod_contacts_small', '', '0', '45', '0', '[[+fullname]], [[+address]], [[+email]], [[+phone]], [[+delivery]], [[+payment]]', '0', NULL, '1', 'core/components/shopkeeper/elements/chunks/[[++manager_language]]/mod_contacts_small.tpl');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '111', '1', '0', 'shopOrderForm', '', '0', '45', '0', '<p class=\"error\">[[+fi.error.error_message]]</p>
<br />

<form method=\"post\" action=\"[[~[[*id]]]]\" id=\"shopOrderForm\">

<fieldset>

<input type=\"hidden\" name=\"nospam:blank\" value=\"\" /> 

<table cellpadding=\"3\">
<tr>
  <td>Address*:</td>
  <td>
      <input name=\"address\" size=\"30\" class=\"textfield\" type=\"text\" value=\"[[!+fi.address:default=`[[+modx.user.id:userinfo=`address`]]`:ne=`0`:show]]\" />
      <div>[[!+fi.error.address]]</div>
  </td>
</tr>
<tr>
  <td>Delivery method*:</td>
  <td>
    <select name=\"shk_delivery\">
        [[+shk_delivery]]
    </select>
  </td>
</tr>
<tr>
  <td>Payment method*:</td>
  <td>
    <select name=\"payment\">
        <option value=\"By receipt\" [[!+fi.payment:FormItIsSelected=`By receipt`]]>By receipt</option>
        <option value=\"Electronic money\" [[!+fi.payment:FormItIsSelected=`Electronic money`]]>Electronic money</option>
    </select>
  </td>
</tr>
<tr>
  <td>Name*:</td>
  <td>
      <input name=\"fullname\" size=\"30\" class=\"textfield\" type=\"text\" value=\"[[!+fi.fullname:default=`[[+modx.user.id:userinfo=`fullname`]]`:ne=`0`:show]]\" />
      <div>[[!+fi.error.fullname]]</div>
  </td>
</tr>
<tr>
  <td>E-mail*:</td>
  <td>
      <input name=\"email\" size=\"30\" class=\"textfield\" type=\"text\" value=\"[[!+fi.email:default=`[[+modx.user.id:userinfo=`email`]]`:ne=`0`:show]]\" />
      <div>[[!+fi.error.email]]</div>
  </td>
</tr>
<tr>
  <td>Phone*:</td>
  <td>
      <input name=\"phone\" size=\"30\" class=\"textfield\" type=\"text\" value=\"[[!+fi.phone:default=`[[+modx.user.id:userinfo=`phone`]]`:ne=`0`:show]]\" />
      <div>[[!+fi.error.phone]]</div>
  </td>
</tr>
<tr>
  <td>Comment:</td>
  <td>
      <textarea name=\"message\" class=\"textfield\" rows=\"4\" cols=\"30\">[[!+fi.message]]</textarea>
  </td>
</tr>
<tr>
  <td></td>
  <td><input type=\"submit\" name=\"submit_button\" class=\"button\" value=\"Submit\" /></td>
</tr>
</table>

</fieldset>

</form>', '0', NULL, '1', 'core/components/shopkeeper/elements/chunks/[[++manager_language]]/shopOrderForm.tpl');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '112', '1', '0', 'shopOrderReport', '', '0', '45', '0', '', '0', NULL, '1', 'core/components/shopkeeper/elements/chunks/[[++manager_language]]/shopOrderReport.tpl');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '113', '0', '0', 'ajaxGetPage', '', '0', '47', '0', '[[!ajaxGetPage? &ajaxpage=`98`]]
 
    <!-- Begin Pagination code -->
    <div id=\"pagination_controls\">
        <div id=\"pagination_control_wrapper\">
        </div>
        </div>   
    <div id=\"pagination_container\">
       <div id=\"pagination_content_wrapper\">
       </div>
    </div>
    <!-- End Pagination code -->', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '114', '0', '0', 'ajaxGetPage - ajax', '', '0', '47', '0', '[[!ajaxGetPage?
&ajax=`1`
&sortBy=`id`
   &elementClass=`modSnippet`
   &element=`getResources`
   &limit=`4`
   &pageVarKey=`page`
   &tpl=`@INLINE <h3>[[+pagetitle]]</h3>`
   &parents=`0`
   &includeTVs=`1`
   &processTVs=`1`
 
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '115', '0', '0', 'migxFormPrintSubmission', '', '0', '38', '0', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">
<html>
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
<title>[[*pagetitle]]</title><base href=\"[[++site_url]]\">
<link type=\"text/css\" rel=\"stylesheet\" href=\"assets/components/migxformbuilder/css/forms.css\">
</head>
<body>
[[!bloX? 
&packagename=`migxformbuilder`
&component=`migxformbuilder`
&project=`migxformbuilder`
&task=`printformsubmission`
]]
</body>
</html>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '116', '1', '0', 'ember_todomvc_router', '', '0', '0', '0', 'Todos.Router.map(function () {
  this.resource(\'todos\', { path: \'/\' }, function () {
    // additional child routes
    this.route(\'active\');
    this.route(\'completed\');
  });
});

Todos.TodosRoute = Ember.Route.extend({
  model: function () {
    return Todos.Todo.find();
  }
});

Todos.TodosIndexRoute = Ember.Route.extend({
  model: function () {
    return Todos.Todo.find();
  }
});

Todos.TodosActiveRoute = Ember.Route.extend({
  model: function(){
    return Todos.Todo.filter(function (todo) {
      if (!todo.get(\'isCompleted\')) { return true; }
    });
  },
  renderTemplate: function(controller){
    this.render(\'todos/index\', {controller: controller});
  }
});

Todos.TodosCompletedRoute = Ember.Route.extend({
  model: function(){
    return Todos.Todo.filter(function (todo) {
      if (todo.get(\'isCompleted\')) { return true; }
    });
  },
  renderTemplate: function(controller){
    this.render(\'todos/index\', {controller: controller});
  }
});', '0', 'a:0:{}', '1', 'assets/ember/todomvc/js/router.js');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '117', '0', '0', 'onupdatebuttonclick', '', '0', '53', '0', '    onUpdateButtonClick: function(){
        var _this= MigxFe.app;
        var config = this.data;
        var params = this.params;
        //console.log(params);
        params.object_id = Ext.get(\"booking_id\").getValue();
        params.btn_id = this.id;
        //data.win_id = \'win-migxfe-\'+data.btn_id;
        //console.log(data);
        var button = this.getEl();
        //var win = Ext.getCmp(data.win_id);
        var win = this.win;
        if (win && typeof(win.getEl())==\'undefined\'){
            win = false;
            this.win = false;
        }
        
        if (!win){
            win=_this.createWin(params,config,button);
            this.win = win;
        }
        button.dom.disabled = true;
        if (win.isVisible()) {
            //win.close();
        } else {
            win.show(this, function() {
                button.dom.disabled = false;
            });
        }        
    },', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '118', '0', '0', 'booking_livesearchTpl', '', '0', '53', '0', '<strong>[[+id]] - [[+fullname]]</strong><br />
[[+city]]|[[+address]]<br />
[[+booking_group:!empty=`Gruppe: [[+booking_group]]<br/>`]] 
[[+is_temp:is=`1`:then=`
<strong>Temporäre Buchung!</strong>
Ablaufdatum: [[+expireson:strtotime:date=`%d.%m.%Y %H:%M`]]<br/>
`:else=``]]
<hr />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '119', '0', '0', 'booking_group_selector', '', '0', '53', '0', 'Gruppe wählen==||Tennisschule', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '120', '0', '0', 'cr_customhandlers', '', '0', '53', '0', '    $scope.onBearbeitenClick = function(params) {
        var dialogOptions = {};
        params.object_id = $(\'#booking_id\')[0].value;  
        UiDialog.loadDialog($scope, Config, params, dialogOptions);
               
    }', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '121', '0', '0', 'login_sidebar_form', '', '0', '53', '0', '<h2>Login</h2>
[[!Login? &tplType=`modChunk` &loginTpl=`lgnLoginSidebarChunk` &contexts=`web`]]
<ul>
<li><a href=\"[[~67]]\">Passwort vergessen?</a></li>
<li><a href=\"[[~69]]\">noch nicht registriert?</a></li>
</ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '122', '0', '0', 'login_sidebar_kontomenu', '', '0', '53', '0', '<h2>Mein Konto</h2>
[[!Login? &tplType=`modChunk` &loginTpl=`lgnLoginSidebarChunk` &contexts=`web`]]
[[!Wayfinder? 
&startId=`66` 
&lastClass=`last` 
&level=`1` 
]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '123', '0', '0', 'lgnLoginTpl', '', '0', '52', '0', '<div class=\"loginForm\">
    <div class=\"loginMessage\">[[+errors]]</div>
    <div class=\"loginLogin\">
        <form class=\"loginLoginForm\" action=\"[[~[[*id]]]]\" method=\"post\">
            <fieldset class=\"loginLoginFieldset\">
                <legend class=\"loginLegend\">[[+actionMsg]]</legend>
                <label class=\"loginUsernameLabel\">[[%login.username]]
                    <input class=\"loginUsername\" type=\"text\" name=\"username\" />
                </label>
                
                <label class=\"loginPasswordLabel\">[[%login.password]]
                    <input class=\"loginPassword\" type=\"password\" name=\"password\" />
                </label>
                <input class=\"returnUrl\" type=\"hidden\" name=\"returnUrl\" value=\"[[+request_uri]]\" />

                [[+login.recaptcha_html]]
                
                <input class=\"loginLoginValue\" type=\"hidden\" name=\"service\" value=\"login\" />
                <span class=\"loginLoginButton\"><input type=\"submit\" name=\"Login\" value=\"[[+actionMsg]]\" /></span>
            </fieldset>
        </form>
    </div>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '124', '0', '0', 'lgnLogoutTpl', '', '0', '52', '0', '<div class=\"loginMessage\">[[+errors]]</div>
<br />
<div class=\"loginLogin\">
    <div class=\"loginRegister\">
        <a href=\"[[+logoutUrl]]\" title=\"[[+actionMsg]]\">[[+actionMsg]]</a>
    </div>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '125', '0', '0', 'lgnErrTpl', '', '0', '52', '0', '<p class=\"error\">[[+msg]]</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '126', '0', '0', 'lgnForgotPassEmail', '', '0', '52', '0', '<p>[[+username]],</p>

<p>To activate your new password, please click on the following link:</p>

<p><a href=\"[[+confirmUrl]]\">[[+confirmUrl]]</a></p>

<p>If successful you can use the following password to login:</p>

<p><strong>Password:</strong> [[+password]]</p>

<p>If you did not request this message, please ignore it.</p>

<p>Thanks,<br />
<em>Site Administrator</em></p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '127', '0', '0', 'lgnForgotPassSentTpl', '', '0', '52', '0', '<h2>Your Login Information Has Been Sent</h2>

<p>Your login information has been sent to the email address [[+email]].</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '128', '0', '0', 'lgnForgotPassTpl', '', '0', '52', '0', '<div class=\"loginFPErrors\">[[+loginfp.errors]]</div>
<div class=\"loginFP\">
    <form class=\"loginFPForm\" action=\"[[~[[*id]]]]\" method=\"post\">
        <fieldset class=\"loginFPFieldset\">
            <legend class=\"loginFPLegend\">[[%login.forgot_password]]</legend>
            <label class=\"loginFPUsernameLabel\">[[%login.username]]
                <input class=\"loginFPUsername\" type=\"text\" name=\"username\" value=\"[[+loginfp.post.username]]\" />
            </label>
            
            <p>[[%login.or_forgot_username]]</p>
            
            <label class=\"loginFPEmailLabel\">[[%login.email]]
                <input class=\"loginFPEmail\" type=\"text\" name=\"email\" value=\"[[+loginfp.post.email]]\" />
            </label>
            
            <input class=\"returnUrl\" type=\"hidden\" name=\"returnUrl\" value=\"[[+loginfp.request_uri]]\" />
            
            <input class=\"loginFPService\" type=\"hidden\" name=\"login_fp_service\" value=\"forgotpassword\" />
            <span class=\"loginFPButton\"><input type=\"submit\" name=\"login_fp\" value=\"[[%login.reset_password]]\" /></span>
        </fieldset>
    </form>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '129', '0', '0', 'lgnResetPassTpl', '', '0', '52', '0', '<div class=\"loginResetPass\">
<p class=\"loginResetPassHeader\">[[+username]],</p>

<p class=\"loginResetPassText\">Your password has been reset. Please return <a href=\"[[+loginUrl]]\">here</a> to log in.</p>  
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '130', '0', '0', 'lgnRegisterForm', '', '0', '52', '0', '<div class=\"register\">
    <div class=\"registerMessage\">[[+error.message]]</div>
    
    <form class=\"form\" action=\"[[~[[*id]]]]\" method=\"post\">
        <input type=\"hidden\" name=\"nospam:blank\" value=\"\" />
        
        <label for=\"username\">[[%register.username? &namespace=`login` &topic=`register`]]
            <span class=\"error\">[[+error.username]]</span>
        </label>
        <input type=\"text\" name=\"username:required:minLength=6\" id=\"username\" value=\"[[+username]]\" />
        
        <label for=\"password\">[[%register.password]]
            <span class=\"error\">[[+error.password]]</span>
        </label>
        <input type=\"password\" name=\"password:required:minLength=6\" id=\"password\" value=\"[[+password]]\" />
        
        <label for=\"password_confirm\">[[%register.password_confirm]]
            <span class=\"error\">[[+error.password_confirm]]</span>
        </label>
        <input type=\"password\" name=\"password_confirm:password_confirm=`password`\" id=\"password_confirm\" value=\"[[+password_confirm]]\" />
        
        <label for=\"fullname\">[[%register.fullname]]
            <span class=\"error\">[[+error.fullname]]</span>
        </label>
        <input type=\"text\" name=\"fullname:required\" id=\"fullname\" value=\"[[+fullname]]\" />
        
        <label for=\"email\">[[%register.email]]
            <span class=\"error\">[[+error.email]]</span>
        </label>
        <input type=\"text\" name=\"email:email\" id=\"email\" value=\"[[+email]]\" />
        
        <br class=\"clear\" />

        [[+register.recaptcha_html]]
        [[+error.recaptcha]]
        
        <div class=\"form-buttons\">
            <input type=\"submit\" name=\"login-register-btn\" value=\"Register\" />
        </div>
    </form>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '131', '0', '0', 'lgnActivateEmailTpl', '', '0', '52', '0', '<p>[[+username]],</p>

<p>Thanks for registering! To activate your new account, please click on the following link:</p>

<p><a href=\"[[+confirmUrl]]\">[[+confirmUrl]]</a></p>

<p>After activating, you may login with your password and username:</p>

<p>
Username: <strong>[[+username]]</strong><br />
Password: <strong>[[+password]]</strong></p>

<p>If you did not request this message, please ignore it.</p>

<p>Thanks,<br />
<em>Site Administrator</em></p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '132', '0', '0', 'lgnActiveUser', '', '0', '52', '0', '<li>[[+username]]</li>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '133', '0', '0', 'lgnLoginSidebarChunk', '', '0', '53', '0', '<div id=\"loginbox\" class=\"LoginRechts\">
    <div class=\"loginMessage\">[[+errors]]</div>
    <div class=\"loginLogin\">
        <form class=\"loginLoginForm\" action=\"[[~[[*id]]]]\" method=\"post\">
            <fieldset class=\"loginLoginFieldset\">
                <label class=\"loginUsernameLabel\">[[%login.username]]</label>
                <input class=\"loginUsername\" type=\"text\" name=\"username\" />
                
                <label class=\"loginPasswordLabel\">[[%login.password]]</label>
                <input class=\"loginPassword\" type=\"password\" name=\"password\" />
                
                <input class=\"returnUrl\" type=\"hidden\" name=\"returnUrl\" value=\"[[+request_uri]]\" />

                <input class=\"loginLoginValue\" type=\"hidden\" name=\"service\" value=\"login\" />
                <span class=\"loginLoginButton\"><button type=\"submit\" name=\"Login\" value=\"[[+actionMsg]]\" class=\"Button\" >[[+actionMsg]]</button></span>
            </fieldset>
        </form>
    </div>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '134', '0', '0', 'cr_bwdaten', '', '0', '49', '0', '[[!Login? &tplType=`modChunk` &loginTpl=`lgnLoginSidebarChunk` &contexts=`web,mgr`]]
<div  ng-controller=\"bwdataCtrl\" >

[[!MIGXangular? 
&buttons=`[
{\"text\":\"Nach Kunde filtern\",\"configs\":\"cr_userfilter\"}
]`
]] 

[[!bloX? 
&component=`courtreservation`
&configs=`courtreservation` 
&task=`bwdaten`
&debug=`0`
&parseFast=`1`
]]

</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '135', '0', '0', 'cr_rezeption', '', '0', '49', '0', '[[!Login? &tplType=`modChunk` &loginTpl=`lgnLoginSidebarChunk` &contexts=`web,mgr`]]
<div  ng-controller=\"bookingCtrl\" >
[[!MIGXangular? 
&buttons=`[
{\"text\":\"neue Buchung\",\"object_id\":\"new\",\"configs\":\"cr_bookings_rezeption\",\"permission\":\"create_booking\"},
{\"text\":\"Buchung bearbeiten\",\"handler\":\"onBearbeitenClick\",\"id\":\"btnupdatebooking\",\"configs\":\"cr_bookings_rezeption\",\"permission\":\"edit_booking_details\"},
{\"text\":\"Buchung laden\",\"configs\":\"cr_searchbooking\"},
{\"text\":\"Fixplätze erstellen\",\"handler\":\"onFixplatzerstellenClick\",\"configs\":\"cr_reservation_fixplatzcreate\"},
{\"text\":\"Listenansicht\",\"handler\":\"onListenansichtClick\",\"configs\":\"cr_reservation_listview\"}

]`
&customhandlers=`[[!bloX? 
&component=`courtreservation`
&configs=`courtreservation,rezeption` 
&task=`cr_customhandlers`
&debug=`0`
]]`
]] 

<div id=\"right-side\">

<br stye=\"clear:left;\" />
<div id=\"content\">

[[!bloX? 
&component=`courtreservation`
&configs=`courtreservation,rezeption` 
&task=`rezeption_angular`
&debug=`0`
&parseFast=`1`
]]
</div>

</div>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '136', '0', '0', 'contactMailChunk', '', '0', '0', '0', 'ein Test', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '137', '0', '0', 'eformcaptcha', '', '0', '54', '0', '    [[!+formit.eformcaptcha_html]]
    <br class=\"clear\" />

    <label for=\"eformcaptcha\">
        Bitte Sicherheitscode eingeben:<br />
[[!+fi.error.eformcaptcha:isnot=``:then=`
<span class=\"error\">Fehlerhafte Eingabe</span>
`:else=``]]
        
    </label>
    
    <input type=\"text\" class=\"eformcaptcha\" name=\"eformcaptcha\" />
 
    <br class=\"clear\" />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '157', '0', '0', 'testchunk', '', '0', '2', '0', '', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '139', '0', '0', 'SimpleSearchBp_Landing', '', '0', '56', '0', '[[!SimpleSearchForm? 
  &tpl=`SearchFormCustom_Landing`
]]

<h2>Your Results</h2>
<p>Here are the results from your search. You can use the left-side Navigation to filter the Results by Areas </p>

[[!bloX?
  &component=`simplesearchbp`
  &project=`simplesearchbp`
  &task=`simpleSearchCourses`
  &perPage=`10`
  &containerTpl=`SearchResultsContainer`
  &tpl=`SearchResultResource`
  &sisea.driver_class=`simplesearchdriverresourcescustom`
  &sisea.driver_db_specific=`0`
  &includeTVs=`1`
  &pageLimit=`5`
]]


', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '140', '0', '0', 'SearchFormCustom_Landing', '', '0', '56', '0', '<form class=\"sisea-search-form\" action=\"[[~[[+landing]]]]\" method=\"[[+method]]\">
  <fieldset>
    <label for=\"[[+searchIndex]]\">[[%sisea.search? &namespace=`sisea` &topic=`default`]]</label>

    <input type=\"text\" name=\"[[+searchIndex]]\" id=\"[[+searchIndex]]\" value=\"[[+searchValue]]\" />
    <input type=\"hidden\" name=\"id\" value=\"[[+landing]]\" /> 

    <input type=\"submit\" value=\"[[%sisea.search? &namespace=`sisea` &topic=`default`]]\" />
  </fieldset>

[[!bloXXXgetawhitscreenWithphpspellcheck?
  &project=`college`
  &task=`didyoumean`
  &searchValue=`[[+searchValue]]`
]]

</form>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '141', '0', '0', 'SearchResultCourse', '', '0', '56', '0', '<div class=\"sisea-result\">
    <h3>[[+idx]]. <a href=\"[[~[[+category_id]]]]courses/[[+Course_alias]]/\" title=\"[[+longtitle]]\">[[+Course_course_name]]</a></h3>
    [[+Course_image:outer=`/assets/images/|`:phpthumbof=`w=50`:outer=`<img class=\"result-image\" src=\"|\" alt=\"[[+Course_course_name]]\"/>`]]
    <div class=\"extract\"><p>[[+extract]]</p></div>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '142', '0', '0', 'SearchResultResource', '', '0', '56', '0', '<div class=\"sisea-result\">
    <h3>[[+idx]]. <a href=\"[[+link:is=``:then=`[[~[[+id]]]]`:else=`[[+link]]`]]\" title=\"[[+longtitle]]\">[[+pagetitle]]</a></h3>
[[+newsimage:outer=`/assets/images/|`:phpthumbof=`w=50`:outer=`<img class=\"result-image\" src=\"|\" alt=\"[[+pagetitle]]\"/>`]]
    <div class=\"extract\"><p>[[+extract]]</p></div>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '143', '0', '0', 'SearchResultsContainer', '', '0', '56', '0', '<p class=\"sisea-results\">[[+resultInfo]] in [[+resultArea]]</p>

<div class=\"sisea-paging\"><span class=\"sisea-result-pages\">[[%sisea.result_pages? &namespace=`sisea` &topic=`default`]]</span>[[+paging]]</div>

<div class=\"sisea-results-list\">
    [[+results]]
</div>

<div class=\"sisea-paging\"><span class=\"sisea-result-pages\">[[%sisea.result_pages? &namespace=`sisea` &topic=`default`]]</span>[[+paging]]</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '144', '0', '0', 'testchunk2', '', '0', '2', '0', '', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '145', '0', '0', 'AdvSearchForm', 'SearchForm for AdvSearch', '0', '59', '0', '<form id=\"[[+asId]]_advsea-form\" class=\"advsea-form\" action=\"[[~[[+landing]]]]\" method=\"[[+method]]\">
  <fieldset>
    <input type=\"hidden\" name=\"id\" value=\"[[+landing]]\" />
    <input type=\"hidden\" name=\"asId\" value=\"[[+asId]]\" />
    [[+helpLink]]<input type=\"text\" id=\"[[+asId]]_advsea-search\" name=\"[[+searchIndex]]\" value=\"[[+searchValue]]\" />
    [[+liveSearch:isnot=`1`:then=`<input type=\"submit\" id=\"[[+asId]]_advsea-submit\"  name=\"sub\" value=\"[[%advsearch.search? &namespace=`advsearch` &topic=`default`]]\" />`:else`=``]]
  </fieldset>
</form>
[[+resultsWindow]]', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '146', '0', '0', 'AdvSearchResults', 'Results for AdvSearch', '0', '59', '0', '<p class=\"advsea-results\">[[+resultInfo]] - [[%advsearch.elapsed_time? &namespace=`advsearch` &topic=`default`]] [[+etime]]</p>
<div class=\"advsea-paging[[+pagingType]]\">[[+paging]]</div>
<div class=\"advsea-results-list\">
    [[+results]]
</div>
<div class=\"advsea-paging[[+pagingType]]\">[[+paging]]</div>
[[+moreResults]]', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '147', '0', '0', 'AdvSearchResult', 'Result for AdvSearch', '0', '59', '0', '<div class=\"advsea-result\">
    <h3>[[+idx]]. <a href=\"[[+link:is=``:then=`[[~[[+id]]]]`:else=`[[+link]]`]]\" title=\"[[+longtitle]]\">[[+pagetitle]]</a></h3>
    <div>[[+extracts]]</div>
</div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '148', '0', '0', 'Extract', 'Extract for AdvSearch', '0', '59', '0', '<p class=\"advsea-extract\">[[+extract]]</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '149', '0', '0', 'Paging2', 'Paging type 2 for AdvSearch', '0', '59', '0', '<span class=\"advsea-result-pages\">[[%advsearch.result_pages? &namespace=`advsearch` &topic=`default`]]</span>[[+paging2]]', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '150', '0', '0', 'Paging1', 'Paging type 1 for AdvSearch', '0', '59', '0', '[[+previouslink:isnot=``:then=`<span class=\"advsea-previous\"><a href=\"[[+previouslink]]\">[[%advsearch.previous? &namespace=`advsearch` &topic=`default`]]</a></span>`]]<span class=\"advsea-current\"> [[+first]] - [[+last]] / [[+total]] </span>[[+nextlink:isnot=``:then=`<span class=\"advsea-next\"><a href=\"[[+nextlink]]\">[[%advsearch.next? &namespace=`advsearch` &topic=`default`]]</a></span>`]]', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '151', '0', '0', 'PageLink', 'Page Link for AdvSearch', '0', '59', '0', '<span class=\"advsea-page\"><a href=\"[[+link]]\" title=\"[[%advsearch.goto_page? &namespace=`advsearch` &topic=`default`]]\" > [[+text]] </a></span>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '152', '0', '0', 'CurrentPageLink', 'Current Page Link for AdvSearch', '0', '59', '0', '<span class=\"advsea-page advsea-current-page\"> [[+text]] </span>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '153', '0', '0', 'HelpLink', 'Link for AdvSearch Help', '0', '59', '0', '<a id=\"[[+asId]]_advsea-helplink\" title=\"[[%advsearch.help_title? &namespace=`advsearch` &topic=`default`]]\" href=\"[[+helpId]]\" class=\"advsea-helplink\"><span>help</span></a>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '154', '0', '0', 'ResultsWindow', 'Div section to set the ajax window of results', '0', '59', '0', '<div id=\"[[+asId]]_advsea-reswin\" class=\"advsea-reswin\"></div>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '155', '0', '0', 'MoreResults', 'More results link of the ajax window of results', '0', '59', '0', '<p class=\"advsea-morelink\"><a id=\"[[+asId]]_advsea-morelink\" title=\"[[%advsearch.more_results? &namespace=`advsearch` &topic=`default`]]\" href=\"[[+moreLink]]\">- [[%advsearch.more_results? &namespace=`advsearch` &topic=`default`]] -</p>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '156', '0', '0', 'TVGalThumb', '', '0', '0', '0', '||<img src=\"[[+image_absolute:phpthumbof=`&w=100&h=100`]]\"/>==[[+id]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '158', '0', '0', 'houseTpl', '', '0', '0', '0', '<h2>[[+object]]</h2>
Appartements:
<table>
[[getImageList? 
&value=`[[+appartements]]`
&placeholdersKeyField=``
&tpl=`appartementTpl`
 ]]
</table>


', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '159', '0', '0', 'appartementTpl', '', '0', '0', '0', '<tr>
<td>[[+Obj_ID]]</td>
<td>[[+Etage]]</td>
</tr>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '160', '0', '0', 'mml_LinkTpl', '', '0', '63', '0', '<li [[+class]]>
<a href=\"[[+link]]\">[[+language]]</a>
</li>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '161', '0', '0', 'mml_MenuRowTpl', '', '0', '63', '0', '<li[[+classes]]><a href=\"[[+link]]\" [[+attributes]]>[[+menutitle]]</a>[[+wrapper]]</li>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '162', '0', '0', 'mml_resourceTemplate', '', '0', '63', '0', '<!doctype html>
<html lang=\"[[++cultureKey]]\" dir=\"[[++lang_dir]]\">
<head>
<meta charset=\"[[++modx_charset]]\">
<title>[[++site_name]] - [[+mml_pagetitle]]</title>
<base href=\"[[++site_url]]\">
<link rel=\"icon\" href=\"/assets/images/favicon.gif\" type=\"image/x-icon\">
<!--[if lt IE 9]>
<script src=\"http://html5shiv.googlecode.com/svn/trunk/html5.js\"></script>
<![endif]-->
<link rel=\"shortcut icon\" href=\"/assets/images/favicon.gif\" type=\"image/x-icon\"> 
<link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/templates/css/minimalism.css\">
</head>
<body>
<div class=\"bg\">
<div id=\"container\">
<header>
    <a href=\"#\" id=\"logo\"><img src=\"/assets/images/logo.png\" width=\"180\" height=\"43\" alt=\"logo\"/></a>
    [[!mmlLangLinks]]    
    <nav>
        [[!pdoMenu? 
            &startId=`0` 
            &level=`1`
            &includeTVs=`mml_pagetitle,mml_menutitle`
            &prepareTVs=`1`
            &tvPrefix=`tv.`
            &loadModels=`migxmultilang`
            &prepareSnippet = `mmlTranslatePdoToolsRow`
            &tpl=`mml_MenuRowTpl`
        ]]
    </nav>
</header>
<section id=\"intro\">
    <hgroup>
        <h1>\"Simplicity is the ultimate sophistication\"<span>- Leonardo da Vinci</span></h1>
        <h2>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin.Vestibulum condimentum  facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy. Cras quis libero.</h2>
    </hgroup>
</section><!--end intro-->
<div class=\"holder_content\" id=\"maincontent\">


<h1>[[+mml_pagetitle]]</h1>
<p>
[[+mml_content:nl2br]]
</p>

[[*content]]
</div><!--end holder-->
<div class=\"holder_content\" id=\"bottomcontent\">
    <section class=\"group4\">
    [[$latestArticle_[[++cultureKey]]]]
    </section>
</div><!--end holder-->
</div><!--end container-->
<footer>
    <div class=\"container\">  
        <div id=\"FooterTwo\"> &copy; 2011 [[++site_name]] </div>
        <div id=\"FooterThree\"> Valid html5, design and code by <a href=\"http://www.marijazaric.com\">marija zaric - creative simplicity</a> </div> 
    </div>
</footer>
</div><!--end bg-->
<!-- Free template distributed by http://freehtml5templates.com -->
</body>
</html>', '0', '', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '163', '0', '0', 'alertTpl', '', '0', '0', '0', '<div class=\"alert alert-[[+type]] fade in\">
        <button aria-hidden=\"true\" data-dismiss=\"alert\" class=\"close\" type=\"button\">×</button>
        <h4>[[+title]]</h4>
        <p>[[+alert]]</p>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '164', '0', '0', 'migxrow_first', '', '0', '65', '0', '<ul>
[[$migxrow]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '165', '0', '0', 'migxrow', '', '0', '65', '0', '<li>[[+name]]</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '166', '0', '0', 'migxrow_last', '', '0', '65', '0', '[[$migxrow]]
</ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '167', '0', '0', 'migxrow_n', '', '0', '65', '0', '[[$migxrow]]
</ul>
<ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '168', '0', '0', 'angularreadmoreTemplate', '', '0', '0', '0', '<!doctype html>
<html xmlns:ng=\"http://angularjs.org\" ng-app=\"myApp\">
<head>
<base href=\"[[++site_url]]\"
</head>
<body >
 
<div ng-controller=\"ItemsCtrl\">
    <div ng-repeat=\"block in blocks\">
      <div ng-repeat=\"item in block.items\">
        <h3>{{item.pagetitle}}</h3>
      </div>
    </div>
    <div ng-repeat=\"morebutton in morebuttons\">
      <button ng-click = \"loadMore()\" >Load more</button>
    </div>  
</div>
 
<script src=\"http://code.angularjs.org/1.2.11/angular.min.js\"></script>
<script type=\"text/javascript\" >
    // declare a module
    var myApp = angular.module(\'myApp\',[]);
  
    myApp.controller(\'ItemsCtrl\', [\'$scope\',\'$http\', function($scope,$http) {
         
        $scope.loadMore = function(){
         
            $http({method: \'GET\', url: \'[[~[[*id]]]]?offset=\' + $scope.offset}).
              success(function(data, status, headers, config) {
                  if (data.blocks){
                     $scope.setItems(data);
                  }
                   
            }).
              error(function(data, status, headers, config) {
              // called asynchronously if an error occurs
              // or server returns response with an error status.
            });           
        }
         
        $scope.setItems = function(json){
            var offset = json.offset || 0;
            var limit = json.limit || 0;
            var last = json.last || 0;
            var blockindex = json.index || \'i0\';
            $scope.blocks = $scope.blocks || {};
            $scope.blocks[blockindex] = json.blocks[blockindex];
                            
            if (last == \'1\'){
                $scope.morebuttons = [];
            }else{
                $scope.morebuttons = [{\"text\":\"Load more\"}];
            }
             
            $scope.offset = offset+limit;              
        }
         
        $scope.setItems([[+resources_json]]) ;
         
    }]);    
</script>      
 
</body>
</html>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '169', '0', '0', 'tplListItem', 'The template that that holds the event detail properties.', '0', '71', '0', '<div class=\"event\">
    <h4><small>[[+startdate:date=`%a`]]</small> <span class=\"dayofmonth\">[[+startdate:date=`%e`]]</span> <a href=\"[[+detailURL]]\" class=\"[[+mxcmodalClass]]\">[[+title]]</a></h4>
    <div class=\"date\">
        [[+startdate:date=`%l:%M %p`]] - [[+enddate:date=`[[+durDay:notempty=`%b %e `]] %l:%M %p`]] :: [[+durYear:notempty=`[[+durYear]] Years `]][[+durMonth:notempty=`[[+durMonth]] Months `]][[+durDay:notempty=`[[+durDay]] Days `]][[+durHour:notempty=`[[+durHour]] Hours `]][[+durMin:notempty=`[[+durMin]] Minutes `]]
    </div>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '170', '0', '0', 'tplListHeading', 'This template is used to set a split between months in the event list. It returns the start date so you can apply the date output modifier to adjust. In order to remove this simply make this entry empty (null).', '0', '71', '0', '<h3 class=\"monthheading [[+altmonthheading]]\">[[+startdate:date=`%b`]]</h3>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '171', '0', '0', 'tplListWrap', 'The template to use as the outter most wrapper of the events list.', '0', '71', '0', '<div id=\"calbodylist\" class=\"list\">
    <h6>Upcoming Events</h6>
	[[+eventList]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '172', '0', '0', 'tplEvent', 'The inner most template to use for the individual event details.', '0', '71', '0', '<div id=\"[[+id]][[+rid]]\" class=\"[[+eventClass]]\" style=\"[[+foregroundcss]][[+backgroundcss]][[+inlinecss]]\">
    <span class=\"\">[[+startdate]]</span>
    <span class=\"title [[+eventCategoryInlineCss]]\">
       <a href=\"[[+detailURL]]\" class=\"[[+mxcmodalClass]]\">[[+title]]</a>
    </span>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '173', '0', '0', 'tplDay', 'The template to use as the day of the month wrapper. Containes the tplEvent combined output.', '0', '71', '0', '<td id=\"[[+dayOfMonthID]]\" class=\"[[+class]]\">
    <!-- day of month label -->
    <div class=\"datestamp\">[[+dayOfMonth]]</div>
    <!-- event listing container -->
    <div id=\"\" class=\"event\">
        [[+events]]    
    </div>
</td>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '174', '0', '0', 'tplWeek', 'The template to use for the wrapper of all the days in a given week. Contains all the tplDay results.', '0', '71', '0', '<tr id=\"[[+weekId]]\" class=\"[[+weekClass]]\">
[[+days]]    
</tr>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '175', '0', '0', 'tplMonth', 'The template to use as the outter most wrapper of the weeks results.', '0', '71', '0', '<div id=\"calbody\" style=\"\">

    <a href=\"[[+todayLink]]\" class=\"mxcnav sm\" id=\"mxctodaylnk\">[[+todayLabel]]</a>
    <span class=\"nomargins\">
        <a href=\"[[+prevLink]]\" class=\"mxcnav\" id=\"mxcprevlnk\">&lt;</a>
        <a href=\"[[+nextLink]]\" class=\"mxcnav\" id=\"mxcnextlnk\">&gt;</a>
    </span>
    <span class=\"label\">[[+headingLabel:date=`%B %Y`]]</span>

    <table id=\"[[+containerID]]\" class=\"[[+containerClass]]\">
    [[+weeks]]    
    </table>
    [[+categories]]
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '176', '0', '0', 'tplHeading', 'The template to use as the calendar heading and navigation controls. This could set to empty in order to return a fixed calendar whereby the user would not have direct navigation of other months.', '0', '71', '0', '<td id=\"[[+dayOfWeekId]]\" class=\"[[+dayOfWeekClass]]\">
        [[+dayOfWeek]]    
</td>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '177', '0', '0', 'tplDetail', 'The template to use as the event detail view.', '0', '71', '0', '<h2 style=\"font-size: 100%;\">[[+title]]</h2>

<p>[[+startdate_fstamp:date=`%b %e %l:%M %p`]] - [[+enddate_fstamp:date=`[[+durDay:notempty=`%b %e `]] %l:%M %p`]]</p>

[[+startdate_fstamp]] <<>> [[+enddate_fstamp]]

<p>Duration: [[+durYear:notempty=`[[+durYear]] Years `]][[+durMonth:notempty=`[[+durMonth]] Months `]][[+durDay:notempty=`[[+durDay]] Days `]][[+durHour:notempty=`[[+durHour]] Hours `]][[+durMin:notempty=`[[+durMin]] Minutes `]]

<p>[[+description]]</p>

[[+imagesTotal:gt=`0`:then=`
    <h3>[[+imagesTotal]] Images Attached</h3>
    <div>[[+images]]</div>
`:else=``]]

[[+videosTotal:gt=`0`:then=`
    <h3>[[+videosTotal]] Videos Attached</h3>
    <div>[[+videos]]</div>
`:else=``]]

<p>Type: <span style=\"[[+foregroundcss:notempty=`color:[[+foregroundcss]];`]][[+backgroundcss:notempty=`background-color:[[+backgroundcss]];`]]\">[[+category]]</span></p>


<h4>[[+location_name]]</h4>
[[+map]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '178', '0', '0', 'tplListItemTraditional', 'This is a carry over from the traditional mxCalendar Evo version of the fields in the list view.', '0', '71', '0', '<hr />
<div class=\"event\" [[+inlinecss:notempty=`style=\"[[+inlinecss]]\"`]] >
    
    <div class=\"date\">
        <div class=\"month\"><p>[[+startdate:date=`%h`]]<span>[[+startdate:date=`%Y`]]</span></p></div>
        <p class=\"[[+durDay:notempty=`multi`]]\">[[+startdate:date=`%e`]][[+durDay:notempty=`[[+dateseperator]][[+enddate:date=`%e`]]`]]</p>
        [[+repeating:is=`1`:then=`<span class=\"repeating\" title=\"repeating event\"></span>`]]
    </div>
    <h6 style=\"font-size: 100%;\"><a href=\"[[+detailURL]]\">[[+title]]</a></h6>
        <p>[[+startdate:date=`%b %e %l:%M %p`]] - [[+enddate:date=`[[+durDay:notempty=`%b %e `]] %b %e %l:%M %p`]]</p>

        <p>Duration: [[+durYear:notempty=`[[+durYear]] Years `]][[+durMonth:notempty=`[[+durMonth]] Months `]][[+durDay:notempty=`[[+durDay]] Days `]][[+durHour:notempty=`[[+durHour]] Hours `]][[+durMin:notempty=`[[+durMin]] Minutes `]]
	<p>[[+description]]</p>
        <p><span style=\"[[+foregroundcss:notempty=`color:[[+foregroundcss]];`]][[+backgroundcss:notempty=`background-color:[[+backgroundcss]];`]]\">[[+category]]</span></p>

        [[+images]]
        
        [[+videos]]
        
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '179', '0', '0', 'tplEventTraditional', 'This is a carry over from the traditional mxCalendar Evo version of the fields in the calendar view.', '0', '71', '0', '<div id=\"[[+id]][[+rid]]\" [[+eventClass:notempty=`class=\"[[+eventClass]]\"`]] style=\"[[+foregroundcss:notempty=`color:[[+foregroundcss]];`]][[+backgroundcss:notempty=`background-color:[[+backgroundcss]];`]][[+inlinecss]]\">
    <span class=\"title [[+eventCategoryInlineCss]]\">
       <a href=\"[[+link:ne=``:then=`[[~[[+link]]]]`:else=`[[+detailURL]]`]]\">[[+title]]</a> ([[+durYear:notempty=`[[+durYear]] Years `]][[+durMonth:notempty=`[[+durMonth]] Months `]][[+durDay:notempty=`[[+durDay]] Days `]][[+durHour:notempty=`[[+durHour]] Hours `]][[+durMin:notempty=`[[+durMin]] Minutes `]])
    </span>
    <span class=\"\">[[+startdate:date=`%l:%M %p`]] - [[+enddate:date=`%l:%M %p`]]</span>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '180', '0', '0', 'tplCategoryWrap', 'The outer container for the cateogry listing when enabled for the calendar display.', '0', '71', '0', '<div id=\"mxccategories\">
    <h3>[[+heading]]</h3>
    <ul>
        [[+categories]]
    </ul>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '181', '0', '0', 'tplCategoryItem', 'The inside container that holds the category output.', '0', '71', '0', '<li class=\"[[+class]]\"><a href=\"[[+link]]\" style=\"[[+foregroundcss:notempty=`color:[[+foregroundcss]];`]][[+backgroundcss:notempty=`background-color:[[+backgroundcss]];`]]\">[[+name]]</a></li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '182', '0', '0', 'tplDetailModal', 'The template file for use with the AJAX modal detail view.', '0', '71', '0', '<h2 style=\"font-size: 100%;\">[[+title]]</h2>

<p>[[+startdate:date=`%b %e %l:%M %p`]] - [[+enddate:date=`[[+durDay:notempty=`%b %e `]] %b %e %l:%M %p`]]</p>

<p>Duration: [[+durYear:notempty=`[[+durYear]] Years `]][[+durMonth:notempty=`[[+durMonth]] Months `]][[+durDay:notempty=`[[+durDay]] Days `]][[+durHour:notempty=`[[+durHour]] Hours `]][[+durMin:notempty=`[[+durMin]] Minutes `]]

<p>[[+description]]</p>

<p>Images ([[+imagesTotal]]):<br>[[+images]]</p>
[[+images_1:ne=``:then=`
<p>Single Image: [[+images_1]]</p>
`:else=``]]

<p>Videos ([[+videosTotal]]):<br>[[+videos]]</p>
[[+videos_1:ne=``:then=`
<p>Single Video: [[+video_1]]</p>
`:else=``]]

<p>Type: <span style=\"[[+foregroundcss:notempty=`color:[[+foregroundcss]];`]][[+backgroundcss:notempty=`background-color:[[+backgroundcss]];`]]\">[[+category]]</span></p>

<h4>[[+location_name]]</h4>
[[+map]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '183', '0', '0', 'tplImageItem', 'Image item default chunk used in both the List and Detail views.', '0', '71', '0', '<div class=\"image-item img-idx-[[+image_idx]]\">
    <h3>[[+title]] </h3>
    <img src=\"[[+filepath]]\" alt=\"[[+title]]\" />
    <p>[[+description]]</p>
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '184', '0', '0', 'tplNoEvents', 'No events chunk to display in list display mode.', '0', '71', '0', 'No events found.', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '185', '0', '0', 'tplSearch', 'Default search form template.', '0', '71', '0', '<form name=\"mxsearch\" post=\"[[~[[+resourceId]]]]\">
    <div><input type=\"text\" name=\"mxterm\" value=\"[[+mxterm]]\" /></div>
    <div><button type=\"submit\">Search</button></div>
</form>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '186', '0', '0', 'contentlogin', '', '0', '0', '0', '
<div class=\"loginForm\">
    <div class=\"loginLogin\">
        <form class=\"loginLoginForm\" action=\"[[~[[*id]]]]\" method=\"post\">
            <fieldset class=\"loginLoginFieldset\">
                <legend class=\"loginLegend\">Login für [[+name]]</legend>
                <input class=\"loginUsername\" type=\"hidden\" name=\"username\" value=\"[[+name]]\" />
                              
                <label class=\"loginPasswordLabel\">[[%login.password]]
                    <input class=\"loginPassword\" type=\"password\" name=\"password\" />
                </label>
                <input class=\"loginLoginValue\" type=\"hidden\" name=\"service\" value=\"login\" />
                <span class=\"loginLoginButton\"><input type=\"submit\" name=\"Login\" value=\"Login\" /></span>
            </fieldset>
        </form>
    </div>
</div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '187', '0', '0', 'migxcal_categoryTpl', '', '0', '73', '0', ' <li class=\"migxcal_category\" data-id=\"[[+id]]\" style=\"color:[[+textColor:default=`#FFFFFF`]];background-color:[[+backgroundColor:default=`#3A87AD`]];\">[[+name]]</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '188', '0', '0', 'contentTpl_book', '', '0', '74', '0', '<h3>Book Tpl</h3>
pagetitle: {{title}}<br />
Book Id: {{params.bookId}}<br />

Chapters:
<ul>
<li ng-repeat=\"item in items\">
{{item.pagetitle}}
</li>
</ul>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '189', '0', '0', 'contentTpl_chapter', '', '0', '74', '0', '<h3>Chapter Tpl</h3>
pagetitle: {{title}}<br />
Book Id: {{params.bookId}}<br />
Chapter Id: {{params.chapterId}}
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '190', '0', '0', 'migxcal_controller', '', '0', '73', '0', 'var migxcalController = null;
var migxcal_dragstart_day = null;

jQuery(document).ready(function() {
   migxcalController = $(\'#migxcalCtrl\').scope();
   
    $(\'.migxcal_category\').draggable({
        zIndex: 999,
        revert: true,      // immediately snap back to original position
        revertDuration: 0  //
    });   

});

function migxcalCtrl($scope, $http, Config, UiDialog) {
    $scope.config = Config;
    $scope.eventResize = function(event,revertFunc){
        /*
        if (!confirm(\"is this okay?\")) {
            revertFunc();
            return;
        } 
        */
        $scope.revertFunc = revertFunc;
        event.allDay = event.allDay ? \'1\' : \'0\';       
        $scope.changeEventDates(event,\'update\');
    }
    $scope.eventDrop = function(event,revertFunc,jsEvent, ui, view){
        
        var day = event.start.dayOfYear();
        var week = event.start.isoWeek();
        /*                
        if (event.Event_repeating == \'1\' && migxcal_dragstart_day != day && !confirm(\"[[%migxcal.warn_move_repeat_2other_day]]\")) {
            //move to other day
            revertFunc();
            return;
        }
        */
        if (event.Event_repeating == \'1\' && migxcal_dragstart_week != week ) {
            //move to other week
            alert(\"[[%migxcal.warn_move_repeat_2other_week]]\");
            revertFunc();
            return;
        }          
        
        $scope.revertFunc = revertFunc;       
        event.allDay = event.allDay ? \'1\' : \'0\'; 
        $scope.changeEventDates(event,\'update\');
    }
    
    $scope.eventEdit = function(data){
        
        var event_id = data.id || 0; 
        $scope.revertFunc = function(){};        
        $scope.editEvent(event_id);        
    } 
    
    $scope.eventPublish = function(data){
        
        var event_id = data.id || 0;        
        var cfg = Config;
        cfg.method = \'POST\';
        var dialogOptions = {};
        var params = {};

        params.configs = \'migxcalendar_dragdropdate\';
        params.action = \'mgr/migxdb/process\';
        params.processaction = \'publishdate\';
        params.object_id = event_id;
        //params.original_request_uri = request_uri;
        params.data = data;        
        
        var ajaxConfig = UiDialog.preparePostParams(cfg, params);
        ajaxConfig.data = {
            //data: data
        };

        $http(ajaxConfig).success(function(response, status, header, config) {
           
            if (response){
            var success = response.success || false;
            var message = response.message || \'\';
            
            if (success) {

            } else {
                alert(message);
            }                
            }
            $scope.refresh();

        }).error(function(data, status, header, config) {
            //UiDialog.error(data, status, header, config);
        });        
               
    }        
    
    $scope.eventDropNew = function(event,el){
        
        /*
        if (!confirm(\"is this okay?\")) {
            revertFunc();
            return;
        } 
        */
        if (el.scope){
            var datecontainer = el.scope().date_container;
            if (datecontainer && datecontainer.repeating == \'1\'){
                alert(\"[[%migxcal.warn_dragnew_repeatingdate]]\");
                return;    
            } 
        }
        
        $scope.revertFunc = function(){
            return;
        };       
        $scope.changeEventDates(event);
    }    
    
    $scope.changeEventDates = function(event,action){
        var end = \'\';
        var start = \'\';
        var action = action || \'edit\';
        
        if (event.end){
            end =  event.end.format();   
        }
        if (event.start){
            start =  event.start.format();   
        }
        var data = {
            enddate : end,
            startdate : start
        };
        if (event.allDay){
            data.allday = event.allDay;
        }        
        if (event.data){
            if (event.data.id){
               data.Event_categoryid = event.data.id; 
            }            
            if (event.data.catid){
               data.Event_categoryid = event.data.catid; 
            }
            if (event.data.eventid){
               data.event_id = event.data.eventid; 
            }            
            
        }
        
        var event_id = event.id || \'new\';
        
        if (action == \'edit\'){
            $scope.editEvent(event_id , angular.toJson(data));  
        }
        if (action == \'update\'){
            $scope.updateEvent(event_id , angular.toJson(data));  
        }        
                  
    }
    
    $scope.hidePleaseWait = function(){
        if ($scope.waiting){
            UiDialog.hidePleaseWait(); 
            $scope.waiting = false;     
        }
    }
    
    $scope.updateEvent = function(event_id,data) {
        var cfg = Config;
        cfg.method = \'POST\';
        
        var params = {
            \'configs\':\'migxcalendar_dragdropdate\',
            \'object_id\':event_id,
            \'action\':\'mgr/migxdb/update\'
        };
        
        var ajaxConfig = UiDialog.preparePostParams(cfg, params);
        ajaxConfig.data = {
            data : data 
        };
        UiDialog.showPleaseWait();
        $http(ajaxConfig).success(function(response, status, header, config) {
            $scope.refresh();
            //UiDialog.hidePleaseWait();
            $scope.waiting = true;
        }).error(function(data, status, header, config) {
            UiDialog.error(data, status, header, config);
        });        
    }
    
    $scope.editEvent = function(event_id,data) {
        var cfg = Config;
        cfg.method = \'POST\';

        var dialogOptions = {};

        var params = {};

        params.configs = \'migxcalendar_dragdropdate\';
        //params.action = \'mgr/migxdb/process\';
        params.action = \'web/migxdb/fields\';
        //params.processaction = \'updateevent\';
        params.object_id = event_id;
        //params.original_request_uri = request_uri;
        params.data = data;
        
        UiDialog.loadModal($scope, Config, params, dialogOptions);
        
        return; 
        
    } 
    
    $scope.refresh = function(){
        $(\'#calendar\').fullCalendar(\'refetchEvents\');
        $scope.relaodDateContainers();    
    }
    
    $scope.closecontainer = function(datecontainer){
        console.log($scope.date_containers[\'dc_\'+datecontainer.id]);
        console.log($scope.date_containers);
        
        if (datecontainer.id){
            delete $scope.date_containers[\'dc_\'+datecontainer.id];
        }
        
        
        

        
        
    }
    
    $scope.relaodDateContainers = function(){
        $(\'.datecontainer\').each(function(){
            var data = $(this).data();
            if (data.eventid){
                $scope.loadDatesContainer(data.eventid);    
            }
        })
        
        
                    
    }
    
    $scope.loadDatesContainer = function(event_id){
       
            var cfg = Config;
            cfg.method = \'POST\';
            var dialogOptions = {};
            var params = {};

            params.configs = \'migxcalendar_loadcontainer\';
            params.action = \'mgr/migxdb/process\';
            params.processaction = \'loadcontainer\';
            params.object_id = event_id;
            //params.original_request_uri = request_uri;
            //params.data = data;        
        
            var ajaxConfig = UiDialog.preparePostParams(cfg, params);
            ajaxConfig.data = {
                //data: data
            };

            $http(ajaxConfig).success(function(response, status, header, config) {
           
                if (response){
                    var success = response.success || false;
                    var message = response.message || \'\';
            
                    if (success && response.object) {
                        data = {};
                        data.item = response.object;
                        $scope.setDatesContainer(data);
                    } else {
                        alert(message);
                        return;
                    }                
                }
                //$(\'#calendar\').fullCalendar( \'refetchEvents\' );

            }).error(function(data, status, header, config) {
                //UiDialog.error(data, status, header, config);
            });                   
    }
    
    $scope.setDatesContainer = function(data){
        $scope.date_containers = $scope.date_containers || {};
        if (typeof(data.item) != \'undefined\'){
            $scope.date_containers[\'dc_\' + data.item.id] = data.item;
            
            setTimeout(function(){
                $scope.$apply();
                //style=\"color:[[+textColor:default=``]];background-color:[[+backgroundColor:default=``]];\"
                var color = data.item.Category_textColor && data.item.Category_textColor != \'\' ? data.item.Category_textColor : \'#FFFFFF\';
                var background_color = data.item.Category_backgroundColor && data.item.Category_backgroundColor != \'\' ? data.item.Category_backgroundColor : \'#3A87AD\';
            
                $(\'#datecontainer\'+data.item.id).css({
                    \'color\' : color,
                    \'background-color\' : background_color
                }).draggable({
                    zIndex: 999,
                    revert: true,      // immediately snap back to original position
                    revertDuration: 0  //                
                });                
            },100);
        }
        return;
    }   
        
}   

', '0', 'a:0:{}', '0', 'core/components/migxcalendars/elements/chunks/migxcal_controller.js');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '191', '0', '0', 'migxcalEditableOptions', '', '0', '73', '0', '   eventResize: function(event, revertFunc) {
        migxcalController.eventResize(event,revertFunc);
    },
    eventDrop: function(event, revertFunc,jsEvent, ui, view) {
        migxcalController.eventDrop(event,revertFunc,jsEvent, ui, view);
    },
    eventDragStart: function(event, jsEvent, ui, view) {
       migxcal_dragstart_day = event.start.dayOfYear();
       migxcal_dragstart_week = event.start.isoWeek();
    },    
    droppable: true,
    drop: function(moment, e ) {
        var el =  $(e.target);
        var event = {
            start : moment,
            data : el.data()
        }
        migxcalController.eventDropNew(event,el);   
    },
    eventAfterAllRender: function(view){
        migxcalController.hidePleaseWait();    
    },
    eventRender: function(event, element) {
        
        element.popover({
            content: event.popupmenu,
            html: true,
            placement: \'top\'
        });
        
        element.on(\'show.bs.popover\',function(){
            //hide all other popovers
            $(\'.popover\').css({display:\'none\'}); 
            $(\'.fc-event\').popover(\'hide\');
        });
        element.on(\'shown.bs.popover\',function(){
            $(\'.event-button\').click(function() {
                var data = $(this).data();
                var action = data.action;
                if (action == \'edit\'){
                    migxcalController.eventEdit(data);    
                }
                if (action == \'publish\'){
                    migxcalController.eventPublish(data);    
                } 
                if (action == \'unpublish\'){
                    migxcalController.eventPublish(data);     
                }
                if (action == \'loadcontainer\'){
                    if (data.eventid){
                        migxcalController.loadDatesContainer(data.eventid);     
                    }
                }                                                     
                
            
            });              
        });        
    },    
    viewRender: function(view, element) {
        migxcal_history(view,element,\'[[+currentUrl]]\');
    }   ', '0', 'a:0:{}', '0', 'core/components/migxcalendars/elements/chunks/migxcalEditableOptions.js');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '196', '0', '0', 'migx_input_float', '', '0', '0', '0', '[[migxJsonToPlaceholders? &prefix=`tv.` &value=`[[+tv_json]]`]]

<div style=\"float:left;\">
<label for=\"tv[[+tv.id]]\" class=\"x-form-item-label modx-tv-label\" style=\"width: auto;margin-bottom: 10px;\">
<div class=\"modx-tv-label-title\"> 
<span class=\"modx-tv-caption\" id=\"tv[[+tv.id]]-caption\">[[+tv.caption]]</span>
</div>    
</label>
<div class=\"x-form-clear-left\"></div>
[[+tv_formElement]]
</div>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '197', '0', '0', 'mml_articleTemplate', '', '0', '7', '0', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<title>Articles - [[*pagetitle]]</title>
<meta charset=\"utf-8\">
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
<link rel=\"stylesheet\" type=\"text/css\" href=\"[[++articles.assets_url:default=`[[++base_url]]assets/components/articles/`]]themes/default/style.css\" />
<base href=\"[[++site_url]]\" />
</head>
<body>

<div id=\"header-wrap\">
  <div id=\"header\" class=\"container_16\">
    <h1 id=\"logo-text\"><a href=\"[[~[[*parent]]]]\" title=\"\">Articles</a></h1>
    <p id=\"intro\">Articles By Me</p>
    <!-- navigation -->
    <div id=\"nav\">
      <ul><li class=\"first\"><a href=\"[[~[[*id]]]]\" title=\"Home\" >Home</a></li>
    </div>
    <div id=\"header-image\"></div>
      <div id=\"search\">

<form id=\"quick-search\" action=\"search-results.html\" method=\"get\">
<p>
  <label for=\"qsearch\">Search:</label>
  <input class=\"tbox\" id=\"qsearch\" type=\"text\" name=\"search\" value=\"\" title=\"Start typing and hit ENTER\" />
  <input class=\"btn\" alt=\"Search\" type=\"image\" title=\"Search\" src=\"[[++articles.assets_url:default=`assets/components/articles/`]]themes/default/images/search.gif\" />
</p>
</form>
</div>
      <!-- header ends here -->
  </div>
</div>
<!-- content starts -->
<div id=\"content-outer\"><div id=\"content-wrapper\" class=\"container_16\">

<!-- main -->
<div id=\"main\" class=\"grid_12\">
    <h2 class=\"title\"><a href=\"[[~[[*id]]]]\">[[*pagetitle]]</a></h2>
    <p class=\"post-info\">
        <span class=\"left\">Posted on [[*publishedon:strtotime:date=`%b %d, %Y`]] by <a href=\"[[~[[*parent]]]]author/[[*publishedby:userinfo=`username`]]\">[[*publishedby:userinfo=`username`]]</a></span>
[[*articlestags:notempty=`
        <span class=\"tags left\">&nbsp;| Tags: [[+article_tags]]</span>
`]]
        [[+comments_enabled:is=`1`:then=`&nbsp;| <a href=\"[[~[[*id]]]]#comments\" class=\"comments\">Comments ([[+comments_count]])</a>`]]
    </p>
    <div class=\"entry\">
        <p>[[*introtext]]</p>
        <hr />
        [[*content]]
    </div>

    <hr />

    <div class=\"post-comments\" id=\"comments\">
        [[!+comments]]
        <br />
        <h3>Kommentar erstellen</h3>
        [[!+comments_form]]
    </div>
</div>

<div id=\"left-columns\" class=\"grid_4\">
  <div class=\"grid_4 alpha\">

    <div class=\"sidemenu\">
      <h3>Latest Posts</h3>
      <ul>
      [[+latest_posts]]
      </ul>
    </div>

    [[+comments_enabled:is=`1`:then=`
    <div class=\"sidemenu\">
      <h3>Latest Comments</h3>
      <ul>
      [[+latest_comments]]
      </ul>
    </div>
    `]]
  </div>
  <!-- end left-columns -->
</div>
<!-- contents end here -->


</div></div>

<!-- footer starts here -->
<div id=\"footer-wrapper\" class=\"container_12\">

  <div id=\"footer-content\">
    <div class=\"grid_4\">
<h3>Tags</h3>
[[+tags]]
    </div>
    <div class=\"grid_4\">
  <h3>Archives</h3>
  [[+archives]]
    </div>
  </div>
  <div id=\"footer-bottom\">
   <p class=\"bottom-left\">
&nbsp; &copy; 2010-2012 Articles. all rights reserved.
      &nbsp; &nbsp; powered by <a href=\"http://modx.com/\">modx revolution</a>
      &nbsp; &nbsp; <a href=\"http://www.bluewebtemplates.com/\" title=\"Website Templates\">website templates</a> by <a href=\"http://www.styleshout.com/\">styleshout</a>
      </p>

      <p class=\"bottom-right\" >
        <a href=\"[[~1]]\">Home</a> |
        <a href=\"[[~1]]\">Sitemap</a> |
        <a href=\"http://jigsaw.w3.org/css-validator/check/referer\">CSS</a> |
             <a href=\"http://validator.w3.org/check/referer\">XHTML</a>
      </p>

  </div>
</div>

</body>
</html>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '192', '0', '0', 'migxcal_eventbuttons', '', '0', '73', '0', '    <div class=\"btn-group event-buttons\">
    [[+published:is=`1`:then=`
    <button type=\"button\" data-id=\"[[+id]]\" data-action=\"unpublish\" class=\"btn btn-default event-button btn-sm\">
        <span  class=\"glyphicon glyphicon-ban-circle\"></span> 
    </button> 
    `:else=`
    <button type=\"button\" data-id=\"[[+id]]\" data-action=\"publish\" class=\"btn btn-default event-button btn-sm\">    
        <span class=\"glyphicon glyphicon-ok-circle\"></span> 
    </button>         
    `]]
    <button type=\"button\" data-eventid=\"[[+Event_id]]\" data-action=\"loadcontainer\" class=\"btn btn-default event-button btn-sm\">
    <span class=\"glyphicon glyphicon-open\"></span> 
    </button>     
    <button type=\"button\" data-id=\"[[+id]]\" data-action=\"edit\" class=\"btn btn-default event-button btn-sm\">
    <span class=\"glyphicon glyphicon-pencil\"></span> 
    </button> 
       
   
    </div>', '0', 'a:0:{}', '0', 'core/components/migxcalendars/elements/chunks/migxcal_eventbuttons.html');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '193', '0', '0', 'migxcalExtraOptions', '', '0', '73', '0', '    eventRender: function(event, element) {
        
        element.on(\'click\', function(){
            $(\'#event-detail-title\').html(event.title);
            $(\'#event-detail-body\').html(event.modalBody);
            $(\'#event-detail\').modal(\'show\');
        });
    },
    viewRender: function(view, element) {
        migxcal_history(view,element,\'[[+currentUrl]]\');
    }
       ', '0', 'a:0:{}', '0', 'core/components/migxcalendars/elements/chunks/migxcalEditableOptions.js');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '194', '0', '0', 'migxcal_modalBodyTpl', '', '0', '73', '0', '<strong>[[%migxcal.start]]:</strong> [[+startdate:strtotime:date=`%d.%m.%Y %H:%M`]] <br />
<strong>[[%migxcal.end]]:</strong> [[+enddate:strtotime:date=`%d.%m.%Y %H:%M`]] <br />
<br /><br />
[[+Event_description]] 
<br /><br />
[[+description]]
<br /><br />
[[+detail_id:isnot=``:then=`
<a href=\"[[[[+detail_id:isnot=``:then=`~[[+detail_id]]? &date_id=`[[+id]]``:else=``]]]]\">Details</a>
`:else=``]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '195', '0', '0', 'migxcal_detailTpl', '', '0', '73', '0', '
<h2>[[+Event_title]]</h2>

[[+Event_description]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '198', '0', '0', 'getAttributeOptionValues', '', '0', '0', '0', 'select one==||
[[getImageList? 
&tvname=`migx_attributes_builder`
&docid=`90`
&tpl=`@CODE:[[+attribute]]`
&outputSeparator=`||`
]]
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '199', '0', '0', 'inlineedit_simple', '', '0', '0', '0', '<div id=\"[[+field]]_editable\" data-wctx=\"[[+wctx]]\" data-resource_id=\"[[+resource_id]]\" data-configs=\"[[+configs]]\" data-field=\"[[+field]]\" data-object_id=\"[[+object_id]]\" class=\"angular_editable\" contenteditable=\"true\">
  [[+value]]
</div>

<script type=\"text/javascript\">

CKEDITOR.inline( \'[[+field]]_editable\', {
    on: {
        focus: function() {
            this.originalData = this.getData();    
        },
        blur: function() {

            
            if (this.checkDirty()){

                if (confirm(\'save modifications\')){
                    //this.resetUndo();  
                    ma_mainController.updateInline($(\'#\' + this.name).data(),this.getData());
                    this.resetDirty();                      
                }else{
                //this.setData(this.originalData);
                                  
                }
            }
 
        }
    },
    autoParagraph : false,
    enterMode: 2,       
    toolbarGroups : [
    { name: \'clipboard\',   groups: [ \'undo\' ] },
    { name: \'about\' }
]    
} );
</script>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '200', '1', '0', 'galleriffic', '', '0', '0', '0', '<div class=\"galleriffic\"> 
<div id=\"gal-gaff-gallery\" class=\"gal_main\">
    <div id=\"gal-gaff-controls\" class=\"controls\"></div>
    <div class=\"slideshow-container\">
        <div id=\"gal-gaff-loading\" class=\"loader\"></div>
        <div id=\"gal-gaff-slideshow\" class=\"slideshow\"></div>
    </div>
    <div id=\"gal-gaff-caption\" class=\"caption-container\"></div>
</div>
<div id=\"gal-gaff-thumbs\" class=\"navigation\">
    <ul class=\"thumbs noscript\">
        [[+thumbnails]]
    </ul>
</div>
<div style=\"clear: both;\"></div>
</div>', '0', 'a:0:{}', '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '201', '0', '0', 'gallerifficTpl', '', '0', '0', '0', '<li>
    <a class=\"thumb\" name=\"[[+title]]\" href=\"[[+services_icon]]\" title=\"[[+title]]\">
        <img src=\"[[+services_icon:phpthumbof=`w=150`]]\" alt=\"[[+title]]\" />
    </a>
    <div class=\"caption\">
        <div class=\"download\">
            <a href=\"[[+services_icon]]\">[[%gallery.download_original? &namespace=`gallery` &topic=`galleriffic`]]</a>
        </div>
        <div class=\"image-title\">[[+title]]</div>
        <div class=\"image-desc\">
            [[+description]]
            [[+tags:notempty=`<br /><em>[[%gallery.tags]]:</em> [[+tags]]`]]
        </div>
    </div>
</li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '202', '0', '0', 'psTopMenu', '', '0', '78', '0', '<li><a href=\"[[~200?scheme=`full`]]\" title=\"Blog\">Blog</a></li>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '203', '0', '0', 'migxcal_modalBodyTpl_custom', '', '0', '79', '0', '<strong>[[%migxcal.start]]:</strong> [[+startdate:strtotime:date=`%d.%m.%Y %H:%M`]] <br />
<strong>[[%migxcal.end]]:</strong> [[+enddate:strtotime:date=`%d.%m.%Y %H:%M`]] <br />
<br /><br />
[[+Event_description]] 
<br /><br />
[[+description]]
<br /><br />
[[!getImageList? &value=`[[+images]]` &tpl=`modalimageTpl` &limit=`1`]]

<br /><br />
[[+detail_id:isnot=``:then=`
<a href=\"[[[[+detail_id:isnot=``:then=`~[[+detail_id]]? &date_id=`[[+id]]``:else=``]]]]\">Details</a>
`:else=``]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '204', '0', '0', 'migxcal_detailTpl_custom', '', '0', '79', '0', '
<h2>[[+Event_title]]</h2>

[[+description]]
<br />
<ul>
[[!getImageList? &value=`[[+images]]` &tpl=`@CODE:<li> <img src=\"[[+image]]\" /></li>` ]]
</ul>
', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '205', '0', '0', 'modalimageTpl', '', '0', '79', '0', '<img src=\"[[+image:phpthumbof=`w=200`]]\" />', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '206', '0', '0', 'mgctResourceTree', '', '0', '0', '0', '<li class=\"[[+_activelabel]] [[+_currentlabel]]\" ><a href=\"[[~[[+id]]]]\">[[+pagetitle]]([[+id]])</a></li>
[[+_active:is=`1`:then=`
[[+innercounts.children:gt=`0`:then=`
<ul>[[+innerrows.children]]</ul>
`:else=``]]
`:else=``]]

', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '207', '0', '0', 'ckInlineedit', '', '0', '83', '0', '<!DOCTYPE html>

<html>

<head>

<title>[[++site_name]] | [[*pagetitle]]</title>
    
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />

<base href=\"[[++site_url]]\" /> 
  
<link href=\"[[++site_url]]layout/css/reset.css\" rel=\"stylesheet\" type=\"text/css\">
<link href=\"[[++site_url]]layout/css/morgenpost_pdf.css\" rel=\"stylesheet\" type=\"text/css\">  

<style type=\"text/css\">
body {
    font-size: 42px;
    height: inherit;
    line-height: 46px;
    overflow: hidden;
    position: inherit;
    width: inherit;
}

#wrapper{
    height: calc(100% - 40px);
    overflow: auto;
    position: absolute;
    top: 40px;
    width: 100%;
}

#content { 
    position: absolute;
    top: 50px;
    transform: scale([[*longtitle]]);
}

#toolbar{
    width: 100%;
    position: fixed;
    height: 40px;
    background-color:silver;
    z-index:100;
}

.cke_toolbar_break {
    clear: none !important;
}

</style>

<script src=\"[[++site_url]]js/ckeditor/ckeditor.js\"></script>
<script src=\"[[++site_url]]js/jquery-1.4.4.min.js\"></script>


  
</head>

<body> 
<div id=\"toolbar\"></div>
<div id=\"wrapper\">
<div id=\"content\">
    
  [[getResourceField:is=`1`:then=`<div id=\"bg\"><img src=\"layout/images/bg_morgenpost_300dpi.jpg\" alt=\"bg\"/></div>`:else=`` ? &id=`[[*parent]]` &field=`vorschau` &processTV=`1`]]
  
  <div contenteditable=\"true\" class=\"textbox\" id=\"wetterfrosch\">[[getResourceField? &id=`[[*parent]]` &field=`wetterfrosch` &processTV=`1`]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"guten_morgen\">[[getResourceField? &id=`[[*parent]]` &field=`guten_morgen` &processTV=`1`]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"geburtstage\">[[getResourceField? &id=`[[*parent]]` &field=`geburtstage` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"aktiv_column1\">[[getResourceField? &id=`[[*parent]]` &field=`aktiv_column1` &processTV=`1`]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"aktiv_column2\">[[getResourceField? &id=`[[*parent]]` &field=`aktiv_column2` &processTV=`1`]]</div>   
  <div contenteditable=\"true\" class=\"textbox\" id=\"renchtalhuette\">[[getResourceField? &id=`[[*parent]]` &field=`renchtalhuette` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"koch\">[[getResourceField? &id=`[[*parent]]` &field=`koch` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"lePavillon\">[[getResourceField? &id=`[[*parent]]` &field=`lePavillon` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"drink\">[[getResourceField? &id=`[[*parent]]` &field=`drink` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"vormerken\">[[getResourceField? &id=`[[*parent]]` &field=`vormerken` &processTV=`1`]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"dollina\">[[getResourceField? &id=`[[*parent]]` &field=`dollina` &processTV=`1`]]</div>
</div>
</div> 
<script>
function savepage(){
    var pagecontent = {};
    $( \".textbox\" ).each(function( index ) {
        var id = $( this ).attr(\'id\');
        pagecontent[id] = $(this).html();
    }); 
    //console.log(pagecontent);
    $.ajax({
        type: \"POST\",
        url: \'[[~691]]\',
        data: pagecontent,
        success: function(data){alert(data);},
        error: function(){alert(\'Fehler: Inhalt konnte nicht gespeichert werden!\');}
    });
}

var button = \'<span class=\"cke_toolgroup speichern_toolgroup\" role=\"presentation\">\';
button += \'<a id=\"cke_82\" class=\"cke_button cke_button__about  cke_button_off\" title=\"Inhalt speichern\" tabindex=\"-1\" hidefocus=\"true\" role=\"button\" aria-labelledby=\"cke_82_label\" aria-haspopup=\"false\" onclick=\"savepage()\" onblur=\"this.style.cssText = this.style.cssText;\" >\';
button += \'Inhalt speichern\';
button += \'</a>\';
button += \'</span>\';

$( \".textbox\" ).each(function( index ) {
    var id = $( this ).attr(\'id\');
    CKEDITOR.disableAutoInline = true;
    var editor = CKEDITOR.inline( id, { 
        sharedSpaces: { 
            top: \'toolbar\' 
        } 
    } );
    editor.on( \'contentDom\', function() {
        var toolbox = $(\'#\' + editor.id + \'_toolbox\');
        $( button ).appendTo( toolbox );

    });    
});    


</script>  
</body>
</html>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '208', '0', '0', 'ckfe_examplecontent', '', '0', '84', '0', '<form id=\"layout-switch\">
<select id=\"layout\" data-tvname=\"mp_bg\" name=\"layout\">[[!getTvOptions? &activeValue=`[[!getPdfLayout]]` &tpl=`mp_bg_option` &tvname=`mp_bg` &name=`layout` &mode=`elements`]]</select>
</form>

<div id=\"content\">
    
  <div id=\"bg\"><img src=\"files/morgenpost/morgenpost_v[[!getPdfLayout]]_1.jpg\" /></div>
  
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_01\">[[!#407.tv.mp_text_01]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_02\">[[!#407.tv.mp_text_02]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_03\">[[!#407.tv.mp_text_03]]</div>  
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_04\">[[!#407.tv.mp_text_04]]</div>      
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_05\">[[!#407.tv.mp_text_05]]</div>
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_06\">[[!#407.tv.mp_text_06]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_07\">[[!#407.tv.mp_text_07]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_08\">[[!#407.tv.mp_text_08]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_09\">[[!#407.tv.mp_text_09]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_10\">[[!#407.tv.mp_text_10]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_11\">[[!#407.tv.mp_text_11]]</div>    
  <div contenteditable=\"true\" class=\"textbox\" id=\"mp_text_12\">[[!#407.tv.mp_text_12]]</div>    

<script>


function savepage(){
    var pagecontent = {};
    $( \".textbox\" ).each(function( index ) {
        var id = $( this ).attr(\'id\');
        pagecontent[id] = $(this).html();
    }); 
    //console.log(pagecontent);
    $.ajax({
        type: \"POST\",
        url: \'[[~691]]\',
        data: pagecontent,
        success: function(data){
            alert(data);
		},
        error: function(){alert(\'Fehler: Inhalt konnte nicht gespeichert werden!\');}
    });    
}



var button = \'<span class=\"cke_toolgroup speichern_toolgroup\" role=\"presentation\">\';
button += \'<a id=\"cke_82\" class=\"cke_button cke_button__about  cke_button_off\" title=\"Inhalt speichern\" tabindex=\"-1\" hidefocus=\"true\" role=\"button\" aria-labelledby=\"cke_82_label\" aria-haspopup=\"false\" onclick=\"savepage()\" onblur=\"this.style.cssText = this.style.cssText;\" >\';
button += \'Speichern\';
button += \'</a>\';
button += \'</span>\';

var button2  = \'<span class=\"cke_toolgroup switchpage_toolgroup\" role=\"presentation\">\';
button2 += \'<a href=\"[[~692? &layout=`[[!getPdfLayout]]`]]\" id=\"cke_83\" class=\"cke_button cke_button__about  cke_button_off\" title=\"Seite 2 laden\" tabindex=\"-1\" hidefocus=\"true\" role=\"button\" aria-labelledby=\"cke_83_label\" aria-haspopup=\"false\" onblur=\"this.style.cssText = this.style.cssText;\" >\';
button2 += \'Seite 2\';
button2 += \'</a>\';
button2 += \'</span>\';

var button3  = \'<span class=\"cke_toolgroup switchpage_toolgroup\" role=\"presentation\">\';
button3 += \'<a target=\"_blank\" href=\"http://www.dollenberg.de/de/assets/components/getPDF/getPDF.php?url=[[++site_url]][[~425]]&filename=morgenpost_seite1.pdf&configcontent=--page-size A2 --margin-top 0 --margin-right 0 --margin-bottom 0 --margin-left 0 --enable-smart-shrinking --no-print-media-type --no-background --page-height 0\" id=\"cke_84\" class=\"cke_button cke_button__about  cke_button_off\" title=\"Abmelden\" tabindex=\"-1\" hidefocus=\"true\" role=\"button\" aria-labelledby=\"cke_84_label\" aria-haspopup=\"false\" onblur=\"this.style.cssText = this.style.cssText;\" >\';
button3 += \'PDF\';
button3 += \'</a>\';
button3 += \'</span>\';

var button4  = \'<span class=\"cke_toolgroup switchpage_toolgroup\" role=\"presentation\">\';
button4 += \'<a href=\"[[~[[*id]]? &service=`logout`]]\" id=\"cke_85\" class=\"cke_button cke_button__about  cke_button_off\" title=\"Abmelden\" tabindex=\"-1\" hidefocus=\"true\" role=\"button\" aria-labelledby=\"cke_85_label\" aria-haspopup=\"false\" onblur=\"this.style.cssText = this.style.cssText;\" >\';
button4 += \'Anmelden\';
button4 += \'</a>\';
button4 += \'</span>\';

$(\'#layout\').change(function(){
    var _this = this;
	var tvname = $(this).data(\'tvname\');
    var tvvalue = $(this).val();
	var pagecontent = {};
    pagecontent[tvname] = tvvalue;

    $.ajax({
        type: \"POST\",
        url: \'[[~691]]\',
        data: pagecontent,
        success: function(data){
            _this.form.submit();
		},
        error: function(){alert(\'Fehler: Inhalt konnte nicht gespeichert werden!\');}
    }); 


});

$( \".textbox\" ).each(function( index ) {
    var id = $( this ).attr(\'id\');
    CKEDITOR.disableAutoInline = true;
	CKEDITOR.config.linkShowTargetTab = false;
    var editor = CKEDITOR.inline( id, { 
        sharedSpaces: { 
            top: \'toolbar\' 
        } 
    } );
    editor.on( \'contentDom\', function() {
        var toolbox = $(\'#\' + editor.id + \'_toolbox\');
        $( button ).appendTo( toolbox );
        $( button2 ).appendTo( toolbox );
		$( button3 ).appendTo( toolbox );
		$( button4 ).appendTo( toolbox );

    });    
});    


</script> 
</div>', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '209', '0', '0', 'ckfe_ajax', '', '0', '84', '0', '[[!ckfe_save]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '210', '0', '0', 'nowdate', '', '0', '0', '0', '[[!nowdate]]', '0', NULL, '0', '');
INSERT INTO `modx_site_htmlsnippets` VALUES ( '211', '0', '0', 'nowdate_snippet', '', '0', '0', '0', '[[!nowdate]]', '0', NULL, '0', '');
--  THE END

